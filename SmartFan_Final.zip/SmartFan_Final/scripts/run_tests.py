#!/usr/bin/env python3
"""Run production host tests; does not connect to hardware."""
import argparse
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

root = Path(__file__).resolve().parents[1]
p = argparse.ArgumentParser()
p.add_argument("--cxx", default=os.environ.get("CXX", "clang++"))
p.add_argument("--node", default=os.environ.get("NODE", "node"))
p.add_argument("--sdk", default=os.environ.get("SDKROOT"))
p.add_argument("--sht-dir", type=Path, default=Path.home() / "Documents/Arduino/libraries/arduino-sht")
args = p.parse_args()
errors = []
if not shutil.which(args.cxx):
    errors.append("C++ compiler not found: " + args.cxx)
if not shutil.which(args.node):
    errors.append("Node.js not found: use --node /absolute/path/to/node")
if not (args.sht_dir / "SHTSensor.cpp").is_file():
    errors.append("arduino-sht source missing: use --sht-dir PATH")
if errors:
    print("\n".join(errors), file=sys.stderr)
    sys.exit(2)
tests = root / "SmartFan_Advanced/tests"
flags = ["-std=c++17", "-I" + str(tests / "fakes"), "-I" + str(tests.parent)]
if args.sdk:
    flags += ["-isysroot", args.sdk]
passed = []
failed = []
with tempfile.TemporaryDirectory(prefix="smartfan-tests-") as temp:
    for name in ["environment", "status", "buttons", "temperature_control", "provisioning", "rpm_control"]:
        try:
            cmd = [args.cxx] + flags + [str(tests / (name + "_test.cpp"))]
            if name == "environment":
                cmd += ["-I" + str(args.sht_dir), str(args.sht_dir / "SHTSensor.cpp")]
            exe = str(Path(temp) / name)
            subprocess.run(cmd + ["-o", exe], check=True, cwd=root)
            subprocess.run([exe], check=True, cwd=root, timeout=60)
            passed.append(name)
        except (subprocess.SubprocessError, OSError) as exc:
            failed.append(name)
            print("FAIL", name, str(exc), file=sys.stderr)
    for name in ["dashboard", "setup_page"]:
        try:
            subprocess.run([args.node, str(tests / (name + "_test.mjs"))], check=True, cwd=root, timeout=60)
            passed.append(name)
        except (subprocess.SubprocessError, OSError) as exc:
            failed.append(name)
            print("FAIL", name, str(exc), file=sys.stderr)
print("PASS:", ", ".join(passed))
print("FAIL:", ", ".join(failed) if failed else "none")
sys.exit(1 if failed else 0)
