# Start here

Open [SmartFan_Advanced/SmartFan_Advanced.ino](SmartFan_Advanced/SmartFan_Advanced.ino) with all headers in the same directory. See the [README](README.md) for build and Wi-Fi setup instructions and the [test plan](TEST_PLAN.md) for verification.

Expected boot marker: `smartfan-advanced-pid-idle-4`.
