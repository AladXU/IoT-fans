# SmartFan wiring

Match the module labels and GPIO numbers to the working build. Breadboard positions can change when the assembly is rearranged.

| Module or signal | Connection |
|---|---|
| ESP32 power and upload | Computer USB-C data cable |
| Fan supply | Power bank and verified 12 V boost cable (USB-A to barrel plug) to V1534 |
| Fan red | V1534 +12 V |
| Fan black | V1534 GND |
| ESP32 GND | Common ground with V1534 GND |
| GPIO4 | Through the existing base resistor to 2N3904 base |
| 2N3904 emitter | Common ground |
| 2N3904 collector | Blue fan PWM lead |
| Yellow fan TACH lead | GPIO5 |
| TACH pull-up | Approximately 10 kΩ between the yellow lead/GPIO5 node and ESP32 3V3 |
| OLED VCC / GND | ESP32 3V3 / GND |
| OLED SDA / SCL | GPIO12 / GPIO13 |
| Onboard RGB | GPIO21, internally connected |
| OLED K1 | GPIO7, increase duty |
| OLED K2 | GPIO8, decrease duty |
| OLED K3 | GPIO9, hold for fine steps |
| OLED K4 | GPIO10, change display page |
| SHT30 / SHT3x VCC / GND | ESP32 3V3 / GND |
| SHT30 / SHT3x SDA / SCL | GPIO12 / GPIO13, on the OLED's I2C bus. SHT30 address 0x44. |
| W25Qxx | Unused in this build |

The NPN stage inverts PWM. The firmware compensates using 100 − duty. Identify base, collector and emitter from the verified physical pinout. The 12 V supply powers only the fan branch. Keep the V1534 5 V output separate from the ESP32 USB supply.

## Power and signals

```mermaid
flowchart TB
    PC["Computer USB"] --> ESP["ESP32-S3-Zero"]
    PB["Power bank and verified 12 V boost cable"] --> PSU["V1534"]
    PSU -->|"Red +12 V"| FAN["Four-wire fan"]
    FAN ---|"Black"| GND["Common ground"]
    PSU --- GND
    ESP --- GND
    ESP -->|"GPIO4 via base resistor"| NPN["2N3904"]
    NPN -->|"Collector to blue PWM"| FAN
    NPN ---|"Emitter"| GND
    FAN -->|"Yellow TACH to GPIO5"| ESP
    ESP -->|"3V3, GND, SDA12, SCL13"| OLED["OLED 0x3C"]
    OLED -->|"K1 to K4 on GPIO7 to GPIO10"| ESP
    ESP -->|"Shared I2C, 3V3 and GND"| SHT["SHT30 0x44"]
```

The TACH pull-up is specified in the pin table. Starting beside SDA, the OLED header reads K4, K3, K2, K1. The user verified the key order on this assembly. Key roles can be reassigned in LocalButtons.h.
