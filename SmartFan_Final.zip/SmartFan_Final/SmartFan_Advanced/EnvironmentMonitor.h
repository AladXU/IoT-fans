#pragma once

#include <SHTSensor.h>
#include "EnvironmentReading.h"

// Explicit SHT3x at 0x44 avoids probing other sensor types on the shared bus.
SHTSensor environmentSensor(SHTSensor::SHT3X);
portMUX_TYPE environmentMux = portMUX_INITIALIZER_UNLOCKED;
EnvironmentReading environmentReading;
bool environmentInitialized = false;  // Owned by the I2C task only.
bool environmentAttempted = false;
uint32_t environmentLastAttempt = 0;

EnvironmentReading readEnvironmentSnapshot() {
  portENTER_CRITICAL(&environmentMux);
  EnvironmentReading result = environmentReading;
  portEXIT_CRITICAL(&environmentMux);
  return result;
}

void setEnvironmentFailure(EnvironmentStatus status) {
  portENTER_CRITICAL(&environmentMux);
  environmentReading.status = status;
  // Retain the last-success timestamp for diagnostics, never display old values as current.
  portEXIT_CRITICAL(&environmentMux);
}

void serviceEnvironment(bool busReady) {
  if (!busReady) return;
  uint32_t now = millis();
  uint32_t interval = environmentInitialized ? ENVIRONMENT_SAMPLE_MS : ENVIRONMENT_RETRY_MS;
  if (environmentAttempted && (uint32_t)(now - environmentLastAttempt) < interval) return;
  environmentAttempted = true;
  environmentLastAttempt = now;

  Wire.beginTransmission(0x44);
  if (Wire.endTransmission() != 0) {
    environmentInitialized = false;
    setEnvironmentFailure(EnvironmentStatus::Missing);
    Serial.println("SHT30: missing/no ACK at 0x44; retry in 5s. Fan control continues.");
    return;
  }

  // arduino-sht 1.2.6 init() already performs a CRC-checked sample.
  // Its 15ms conversion delay is isolated in this I2C task, not the control loop.
  bool success = environmentInitialized ? environmentSensor.readSample() : environmentSensor.init(Wire);
  float temperature = environmentSensor.getTemperature();
  float humidity = environmentSensor.getHumidity();
  if (!success || !environmentValuesValid(temperature, humidity)) {
    environmentInitialized = false;
    setEnvironmentFailure(EnvironmentStatus::ReadError);
    Serial.println("SHT30: read/CRC error; retry in 5s. Fan control continues.");
    return;
  }

  environmentInitialized = true;
  EnvironmentReading next;
  next.temperature = temperature;
  next.humidity = humidity;
  next.sampledAt = millis();
  next.hasSample = true;
  next.status = EnvironmentStatus::Ready;
  portENTER_CRITICAL(&environmentMux);
  environmentReading = next;
  portEXIT_CRITICAL(&environmentMux);
  Serial.printf("SHT30: Temperature: %.2f C | Humidity: %.2f %%RH\n", temperature, humidity);
}
