# Firmware validation history

These entries describe the build named in each section. Consult the [current acceptance checklist](../TEST_PLAN.md) for outstanding checks. The work below was recorded on November 16, 2026. The basic firmware passed a user-observed 15-minute run.

## Environmental readings

| Check | Result and evidence |
|---|---|
| Build | The button-stage build used 996,744 bytes flash and 48,828 bytes global RAM on Waveshare ESP32-S3-Zero with core 3.3.10. |
| Sensor driver and cache | environment_test.cpp used the installed SHTSensor.cpp with fake Wire and clock. Passed missing device, CRC failure, short read, recovery, sample/retry intervals, stale data, timer rollover, finite values and range checks. Failed samples invalidate cached readings. |
| HTTP status | status_test.cpp exercised sendDashboardStatus() with valid readings, null output on failure, null age before first success and expired snapshots. |
| Embedded dashboard | dashboard_test.mjs passed valid, missing, failed, stale, disconnected and recovered states, invalid input and 24% command confirmation. At most one network request was in flight. |
| Physical readings | The screenshot showed 25.4°C, 65.0% RH, 50% duty and 1980 RPM. The user confirmed OLED readings and a response to warming the sensor. |
| Concurrent control | The user applied 25% from the web, then 75% over serial, and confirmed working controls and synchronized readings during sampling. |

For the original sht-1 check, upload the sketch, confirm `smartfan-advanced-sht-1`, and watch temperature and RH on serial, OLED and dashboard. Leave the sensor undisturbed for about 20 seconds, then gently warm the area near it for 10–20 seconds. Observe the measured change. This build used manual speed control. Record the readings or take a photo.

The separate cold-start fault test removes SHT30 with both USB and fan power disconnected, leaving the OLED connected. On restart expect missing status and blank readings while local control continues. Power down, reconnect the sensor and restart to recover. Host simulation also covered retries. Cold-start observations do not establish hot-plug behavior.

## Four physical buttons

buttons_test.cpp exercised ButtonLogic and LocalButtons for debounce, one action per press, held-at-boot suppression, fine steps, conflicting directions, limits, rollover, remapping, page switching, reuse of external duty updates and PWM failure. status_test.cpp passed after the snapshot was extended.

The button build used marker smartfan-advanced-buttons-1. Starting from serial duty 50, the four buttons from top to bottom should give 55, 50, no duty change, then a page change. Use the Button Kx (GPIOx) log to identify the key. Hold the third button to step 50 → 51 → 50. Set 24 externally and increment to 29. Test clamping from 99 to 100 and 1 to 0, with no autorepeat. The fourth key toggles both OLED pages while readings continue. The user confirmed the button order, coarse/fine steps, page change and synchronization. No separate instrument log was recorded.

## Three-point temperature control

The auto-1 build added automatic mode. Host tests passed strict temperature and whole-profile validation, rejection of equal, reversed, out-of-range and non-finite inputs, endpoint/intermediate interpolation, monotonicity for closely spaced points, stale/missing/recovered samples, 100% fallback, manual takeover, PWM failure/retry, mode changes, full queues, headers and missing/duplicate parameters. Status serialization included curve, mode and fallback. The browser retained edits, confirmed mode from the device, reported faults and busy requests and serialized polling. Button and HTTP regressions passed.

Compilation with core 3.3.10, default partitions, CDC enabled and erase disabled used 1,006,284 bytes flash (76%) and 48,916 bytes global RAM (14%).

Bench sequence: boot in Manual at 50%, verify temperature and RPM, save the 26/28/30°C curve at 25/50/100%, check the active revision and select Auto. Expected duties are 25% at or below 26°C, about 38% at 27°C, 50% at 28°C, 75% at 29°C and 100% at or above 30°C. Use a curve near room temperature if necessary. Apply serial 24 to take over, increment to 29 with a button, then return to Auto. Page selection should preserve mode. Reject T2=T1 as a complete edit. This early build restored its default mode and curve at boot.

Physical evidence included 100% near 30°C and about 32% at 26.5°C. Serial 24 selected Manual at 24%. T1=T2 was rejected, retaining revision 0. Changing the first point to 26°C → 30% produced revision 1 and 31% at 26.1°C. With the sensor removed, readings were blank, status reported missing and fallback applied 100% at 4440 RPM. After powered-down reconnection, live readings returned at 25.0°C and 66.5% RH, with Auto at 25%.

## Provisioning, NVS and connection feedback

The portal-1 tests used production Provisioning, ConfigStorage and HTTP handlers with fake Wi-Fi, Preferences, DNS, RTOS and clock. Cases covered record length/version/checksum/fields, corruption, write/readback failure, cold profile restore, setup on missing configuration or 15-second timeout, 30-second retries, closure of AP and DNS after reconnect, offline operation, restart two seconds after a verified save, no restart on error, revision-aware acknowledgements, rollover, AP/DNS failures, duplicate/missing/NUL fields, missing headers and password suppression. Temperature and status regressions passed.

The actual setup JavaScript passed form validation, queuing during polling, save confirmation, retry after write failure and disconnect feedback during restart. The dashboard passed manual, automatic and curve editing checks. Physical AP visibility, OS popups, real flash persistence and RF reconnect require bench checks. The suggested sequence in [PROVISIONING.md](PROVISIONING.md) includes initial connection, AP closure, automatic reconnect after boot, profile retention after power loss, wrong-password timeout and credential recovery while local controls continue. PID, Hub and history were outside the portal-1 build. It booted in Manual at 50%. Build size was 1,027,356 bytes flash (78%) and 49,468 bytes global RAM (15%).

The user showed the original setup page stalled on an ambiguous restart message while the live dashboard at 10.157.215.137 reported Connected, 50%, 2040 RPM, 24.6°C and 51.5% RH. This established successful initial setup. The feedback revision clears stale hotspot text, separates saving from joining, reports connecting/timeout states, links the assigned IP and clears success on disconnect. Embedded-page tests passed these cases, single-flight polling and resubmission. HTTP status added stationIp and setupApActive without returning passwords. AP disappearance, full power-cycle reconnect, curve retention and wrong-password fallback were still pending individual hardware checks at that stage.

## Dashboard layout and mode controls

The square-corner dashboard and setup page passed regression for manual/automatic control, curve validation, single-request polling, offline/recovery, invalid readings, submission, save and Wi-Fi feedback. Headless Chrome showed no horizontal overflow at 1440 and 390 px. Layout fixtures were used only for preview. The firmware compiled with core 3.3.10, CDC enabled and flash erase disabled. Manual remained the boot mode.

Mode-panel tests verified switching only after GET confirmed the device mode, exclusive Manual/Auto panels, preserved hidden edits, externally triggered Manual mode, the automatic panel during fallback, hidden controls while disconnected and restoration on reconnect. The firmware compiled at 1,045,420 bytes flash (79%) and 49,468 bytes global RAM (15%). The user later confirmed this mode-linked UI on the board before PID work began.

## Initial PID build

The previous UI checkpoint was SmartFan_UI_verified_before_PID_20261116. Production RpmPid tests covered input validation, 0–100% bounds, a 10-point/s slew limit, bounded integral during ten simulated minutes of saturation, target reversal, timer rollover, non-finite input and nine software plants (response times 0.5/1.5/3 s and speed multipliers 0.9/1.0/1.1, targets 2500 → 3500 → 1500). The scheduler used new samples only and retained state on PWM failure. Tests included stale RPM, three zero-pulse windows, recovery, mutually exclusive modes and real HTTP handlers/queue/snapshots.

Dashboard tests covered the third mode, RPM validation, confirmed targets, retained edits, saturation/fault status, serialized requests and recovery. Temperature, buttons, status, NVS and setup-page regressions passed. Chrome checks at 1440/390/320 px found no horizontal overflow. The initial PID build compiled at 1,052,116 bytes flash (80%) and 49,524 bytes global RAM (15%). Physical response was assessed separately.

## PID response tuning

A physical screenshot showed a 2500 RPM target, 2490 RPM measured and 56% duty. At a 3500 target, 15 one-second windows showed 2520 → 3300 RPM and duty 56 → 69%. The last PID line was truncated. See the [3500 RPM record](../docs/measurements/pid_3500_20261116.csv). The old checkpoint was SmartFan_PID_before_response_tuning_20261116.

At 980 RPM error the original Ki=0.002 added only 1.96 duty points per second. The output did not reach its 10-point/s slew limit. Response-2 changed Kp from 0.006 to 0.012 and Ki from 0.002 to 0.006, retaining Kd=0.001 and protections. New model checks required sustained error below 120 RPM after 30 seconds and directional overshoot below 150 RPM. Production PID/scheduling/API/mode/fault tests passed.

In the nine models the old and new builds entered and stayed within ±120 RPM in 30–42 s and 11–17 s respectively. Maximum directional overshoot was below 30 RPM. These are model results. The response-2 build used 1,052,136 bytes flash (80%) and 49,524 bytes global RAM (15%), with marker smartfan-advanced-pid-response-2. The next planned bench run recorded the first 30 seconds after upward and downward steps.

## Near-target stability

At a 4000 RPM target, physical response-2 readings ranged from 3900 to 4110 RPM with duty corrections between 82% and 85%. The [4000 RPM record](../docs/measurements/pid_4000_response2_20261116.csv) retains 35 rows in pasted order, including a flagged possible duplicate. The development checkpoint was SmartFan_PID_response_before_near_target_20261116.

Stable-3 introduced scheduled gains. At ≥600 RPM error, Kp=0.012, Ki=0.006 and slew=10 points/s. At ≤150 RPM, Kp=0.004, Ki=0.0015 and slew=1 point/s. Intermediate settings are interpolated. The controller holds duty within ±45 RPM, tracks the integral and exposes holding while continuing to show raw RPM. Production PID, API, modes, faults, nine models, temperature, status, NVS and embedded-page tests passed. New checks covered near-region slew, holding, leaving the band and showing a real 4020 RPM when the target was 4000.

Fixed-input replay yielded 14 output changes and 23 points of travel (82–86%) for the old controller, versus five changes and five points of travel (84–85%) for the new controller. In noise-free models, sustained entry into ±120 RPM took 14–30 s. The planned smartfan-advanced-pid-stable-3 bench comparison was a fixed 4000 RPM target with 30 seconds of near-target duty, RPM and zone data.

## Main-loop idle time and heating

The user observed stable-3 for over 20 seconds without an obvious PID problem. A black component on the USB-powered ESP32 board felt hot. The touch estimate of about 50°C was unmeasured. A later photo identified the main chip. The cause and temperature rise remained unverified.

In Arduino core 3.3.10, the dual-core loopTask does not automatically run the single-core yieldIfNecessary branch. With the default 240 MHz CPU and 1000 Hz RTOS tick, the previous loop could continually copy state. Idle-4 added vTaskDelay(1) per iteration (about 1 ms) and limited snapshot publication to once per 20 ms. PWM, tachometer interrupts, elapsed-time sampling, PID gains and the separate network/I2C/LED tasks were retained. The change reduces idle work without enabling deep sleep or lowering CPU frequency.

The historical smartfan-advanced-pid-idle-4 build compiled at 1,052,996 bytes flash (80%) and 49,524 bytes global RAM (15%). That compile included no hardware upload. Board temperature, power and long-duration behavior still need measurement. Let the board cool before a short instrumented comparison and check power and wiring separately.
