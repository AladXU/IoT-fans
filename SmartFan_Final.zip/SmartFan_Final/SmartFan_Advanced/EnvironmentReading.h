#pragma once

#include <stdint.h>
#include <math.h>

constexpr uint32_t ENVIRONMENT_SAMPLE_MS = 2000;
constexpr uint32_t ENVIRONMENT_RETRY_MS = 5000;
constexpr uint32_t ENVIRONMENT_STALE_MS = 5000;

enum class EnvironmentStatus { Starting, Ready, Missing, ReadError, Stale, Unavailable };

struct EnvironmentReading {
  float temperature = 0;
  float humidity = 0;
  uint32_t sampledAt = 0;
  bool hasSample = false;
  EnvironmentStatus status = EnvironmentStatus::Starting;
};

inline bool environmentValuesValid(float temperature, float humidity) {
  return isfinite(temperature) && isfinite(humidity) &&
         temperature >= -40 && temperature <= 125 && humidity >= 0 && humidity <= 100;
}

inline EnvironmentStatus environmentStatusAt(const EnvironmentReading &reading, uint32_t now) {
  if (reading.status != EnvironmentStatus::Ready) return reading.status;
  if (!reading.hasSample || !environmentValuesValid(reading.temperature, reading.humidity))
    return EnvironmentStatus::ReadError;
  if ((uint32_t)(now - reading.sampledAt) >= ENVIRONMENT_STALE_MS)
    return EnvironmentStatus::Stale;
  return EnvironmentStatus::Ready;
}

inline const char *environmentStatusCode(EnvironmentStatus status) {
  switch (status) {
    case EnvironmentStatus::Starting: return "starting";
    case EnvironmentStatus::Ready: return "ok";
    case EnvironmentStatus::Missing: return "missing";
    case EnvironmentStatus::ReadError: return "read_error";
    case EnvironmentStatus::Stale: return "stale";
    default: return "unavailable";
  }
}

inline const char *environmentStatusLabel(EnvironmentStatus status) {
  switch (status) {
    case EnvironmentStatus::Starting: return "starting";
    case EnvironmentStatus::Ready: return "ready";
    case EnvironmentStatus::Missing: return "missing";
    case EnvironmentStatus::ReadError: return "read error";
    case EnvironmentStatus::Stale: return "stale";
    default: return "unavailable";
  }
}
