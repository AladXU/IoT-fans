# Closed-loop RPM control

Build `smartfan-advanced-pid-idle-4` retains the stable-3 control law. Large errors permit faster changes. Near the target the controller reduces gain and slew. Inside ±45 RPM it holds the applied duty. The dashboard displays the measured tachometer RPM throughout. The fan uses the existing GPIO4 PWM, GPIO5 TACH and 12 V supply.

## First bench run

1. Upload SmartFan_Advanced.ino with flash erase disabled to preserve compatible Wi-Fi and NVS records.
2. Open the current OLED IP and hard-refresh the page (Command-Shift-R on Mac). Section 02 should offer Manual, Auto temp and PID RPM.
3. Select PID RPM, enter 4000 in section 03 and apply. Check the device-reported mode and **Active target**.
4. Allow the fan to approach the target, then record 30 consecutive seconds of PID output. Compare measured RPM, duty and zone. Retain transient and settled readings separately.
5. If large oscillations persist, send 50 over serial or switch to Manual and apply 50%.

The serial monitor accepts integer duty commands from 0 to 100. Set RPM through the dashboard or HTTP API. Keep the fan clear during the run.

## Modes and reachable speeds

Manual holds the requested duty. Auto temp uses the SHT30 and its three-point profile, with 100% fallback when temperature is invalid. PID uses tachometer feedback independently of environmental readings. A successful manual duty command from the page, serial or buttons takes over immediately. Selecting Auto temp restores curve control.

Entering PID or changing its target initializes the integral from the actual output for a smooth transition. The mode button uses the previous RAM target, initially 2500 RPM. A restart restores Manual at 50% and the initial RPM target. Network settings and the temperature curve persist.

The API accepts targets from 0 to 20000 RPM. Previous physical readings covered roughly 780–4440 RPM. Actual limits depend on supply and load. An unreachable target eventually drives the output to a limit. Even a 0 RPM request or 0% duty may leave the fan spinning.

## Algorithm

RpmPid.h implements the hardware-independent discrete controller. RpmControl.h handles samples, mode, faults and PWM. Runtime control uses physical measurements.

| Parameter | Value | Units or interpretation |
|---|---:|---|
| Far-region Kp | 0.012 | duty percentage points per RPM |
| Far-region Ki | 0.006 | duty points per RPM-second |
| Kd | 0.001 | duty point-seconds per RPM |
| Control interval | 1000 ms | Once per fresh tachometer window |
| Far-region slew limit | 10 | duty points per second |
| Stale sample age | 2500 ms | Invalid at or beyond the limit |
| Derivative filter time constant | 1 s | First-order filter on the measurement derivative |

For error e = target − measured RPM, P = Kp × e. Filter the measured speed derivative and calculate D = −Kd × filtered derivative. The candidate integral is I′ = I + Ki × e × dt and raw output is u = P + I′ + D. Limit u by both 0–100% and the allowed rate of change. Track the limited output with I = I′ + (limited output − u). Duty is rounded to whole percentage points. The integral retains fractional precision.

Commit the candidate state only after PWM succeeds. On failure retain the actual duty and integral, then retry on a new window. Long gaps reinitialize the controller instead of integrating across stale data. Unsigned elapsed-time arithmetic handles millis rollover. The one-second control interval is separate from the configured 25 kHz PWM carrier. RPM assumes two pulses per revolution and has not been independently calibrated. Network, I2C and LED tasks run independently of the main loop.

The project implements its own controller. Background on back-calculation is available in the [MathWorks anti-windup example](https://www.mathworks.com/help/simulink/slref/anti-windup-control-using-a-pid-controller.html). No MATLAB or external PID library is required.

## Error zones

| Absolute error | Kp | Ki | Maximum duty change |
|---|---:|---:|---|
| ≥600 RPM | 0.012 | 0.006 | 10 points/s |
| 150–600 RPM | Interpolated | Interpolated | Interpolated between 1 and 10 points/s |
| ≤150 RPM, outside hold | 0.004 | 0.0015 | 1 point/s |
| ≤45 RPM | Hold output | Track applied output | 0 |

Interpolation uses r = clamp((absolute error − 150)/450, 0, 1). In the hold zone, update the filtered derivative, timestamp and last measurement and track the applied duty with the integral. Resume adjustment when the absolute error exceeds 45 RPM. The band defines a control policy, with no guarantee that physical speed always stays inside it.

## Fault handling

Missing, stale, non-finite or negative feedback triggers a feedback fault. Three consecutive fresh windows with zero pulses at a duty of at least 25% also trigger the fault. Clear the integral and request 100% ventilation, bypassing normal slew limits. If the PWM write fails, report the actual applied duty and retry the fallback at most once per 250 ms.

Zero pulses alone cannot distinguish a stopped fan, a disconnected tachometer or a supply fault. Below 25% duty, a zero-pulse window does not immediately declare a fault. Positive speed error can raise output until the detection condition is met. Recovery requires a fresh positive valid sample. Reinitialize from actual duty before resuming control.

## HTTP interface and status

POSTs require X-Fan-Control: 1 and form-urlencoded data. A 202 acknowledges queueing.

| Request | Behavior |
|---|---|
| POST /api/mode | Accepts manual, automatic or pid. PID uses the current RAM target. |
| POST /api/rpm | Accepts exactly one rpm field with a complete unsigned decimal integer from 0 to 20000. Sets target and mode atomically. |
| POST /api/duty | Accepts whole duty from 0 to 100. Successful application selects Manual. |
| GET /api/status | Returns confirmed mode, applied duty, measured RPM and PID details. |

The pid object includes targetRpm, status, feedbackFault, intervalMs, staleAfterMs, kp, ki, kd and slewPercentPerSecond. Near-target settings are nearKp, nearKi, nearErrorRpm, farErrorRpm, nearSlewPercentPerSecond and holdBandRpm. Status values include inactive, waiting, tracking, holding, limited_high, limited_low, feedback_fault and output_error. Tracking identifies active control. Serial logs identify zone=far/blend/near/hold.

Top-level duty is the applied value. In PID, calculatedDuty is the most recent request. Stale or invalid RPM is null. A valid zero-pulse window gives 0. The API rejects negative, fractional, exponential and nonnumeric targets and missing, extra or repeated fields. Rejection preserves target and mode. Local control continues offline.

## Suggested follow-up tests

After verifying 2500 RPM, run 2500 → 3500 → 1500 RPM, capturing 30–60 seconds per target. Compare settling time, maximum deviation and duty variation. Request 6000 and 0 separately to observe saturation, then return to 2500 and check recovery. Test serial duty 24, Auto temp, return to PID, network loss and restart. Change wiring only after disconnecting power. Record hardware observations separately from host tests and browser previews.

## Tuning history and evidence

With the original Kp=0.006, Ki=0.002 and Kd=0.001, the 3500 RPM step began at 2520 RPM. At 980 RPM error, integral growth was 1.96 duty points/s, consistent with the recorded integral values 51.900 and 53.800. Output usually rose by 1–2 points per second, below the 10-point slew limit. Response-2 increased Kp to 0.012 and Ki to 0.006. The corresponding integral increment at 980 RPM error is 5.88 points/s. The actual output also depends on P, D, limits and subsequent feedback.

In nine declared software models, the old controller took 30–42 s to enter and stay within ±120 RPM after upward and downward steps to 3500 and 1500. Response-2 took 11–17 s. Maximum directional overshoot was below 30 RPM in those models. Reproduce with tests/pid_response_benchmark.cpp and the appropriate RpmPid.h. The development checkpoint was SmartFan_PID_before_response_tuning_20261116.

[3500 RPM log](../docs/measurements/pid_3500_20261116.csv) uses sample_index for pasted sequence order. The final truncated PID fields are blank. A Duty line records the output before the measurement. The PID line records the subsequent output. These transient readings are unsuitable as steady-state calibration points.

In the [4000 RPM response-2 log](../docs/measurements/pid_4000_response2_20261116.csv), the near-target readings ranged from 3900 to 4110 RPM at 82–85% duty. At 4110 the controller commanded 82%, followed by 85% at 3900. Strong gains and integer output can cause repeated corrections. At two pulses/revolution and a one-second window, one pulse changes the reading by 30 RPM. This record alone cannot separate measurement granularity from physical speed changes. The repeated PID sample at row 23 was retained and flagged. No timestamps were inferred.

The current controller passed the nine model cases, mode, input, HTTP, output-limit, anti-windup, fault and recovery tests. New tests verify hold entry/exit, the near-region slew limit and preservation of actual RPM. On the same fixed input replay, duty changed 14 times across 82–86% with the old controller and five times across 84–85% with the new one (tests/pid_ripple_benchmark.cpp). In the nine noise-free models the current policy took 14–30 s to enter and stay within ±120 RPM. The conservative final approach can take longer. Replay and model figures describe software behavior only.

## Main-loop scheduling

Idle-4 adds a one-tick wait per main-loop iteration and publishes snapshots at most every 20 ms. PWM hardware, tachometer interrupts and elapsed-time RPM calculation are unchanged. The user observed stable-3 for just over 20 seconds. The later photo identified the hot component as the ESP32 itself. Board temperature and power draw on idle-4 still require instrumented measurements.
