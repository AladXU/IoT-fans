# SmartFan firmware

The single-device build integrates manual fan control, temperature control, closed-loop RPM, Wi-Fi provisioning, an OLED, an RGB indicator and physical buttons. The basic controls, environment readings, buttons, temperature curve, mode-specific dashboard and initial Wi-Fi setup have physical evidence. PID was tuned on the fan and observed briefly. Temperature rise and extended operation on idle-4 remain open. See [validation history](TEST_STATUS.md) and the [PID guide](PID.md). No external W25Qxx or SD card is required.

## Build and upload

Open SmartFan_Advanced.ino with all sibling headers. Select Waveshare ESP32-S3-Zero, ESP32 core 3.3.10, default partitions, USB CDC On Boot enabled, flash erase disabled and 115200 baud. Install arduino-sht 1.2.6, Adafruit SSD1306 2.5.17, Adafruit GFX 1.12.6 and Adafruit BusIO 1.17.4. Wire, WiFi, WebServer, RTOS and RMT come from the core. FastLED is not required.

Follow [first-time provisioning](PROVISIONING.md) to enter Wi-Fi settings on the device hotspot. Then connect the computer to the same network as the ESP32. If the uploader cannot connect, hold BOOT, tap RESET, release BOOT, select the port again and retry.

Expected serial marker: `Boot: smartfan-advanced-pid-idle-4`. The device boots in Manual at 50%. It loads the last valid curve from NVS or uses the default 26°C → 25%, 28°C → 50%, 30°C → 100%.

## Operating modes

| Action | Device behavior |
|---|---|
| Manual | Hold the applied duty on entry. |
| Auto temp | Calculate duty from the latest valid reading. Request 100% on a temperature fault. |
| PID RPM | Use the current in-memory target, initially 2500 RPM. |
| Apply RPM | Validate an integer from 0 to 20000, set the target and enter PID as one operation. |
| Save profile | Validate and replace the entire curve. Keep the active mode. In Auto, use the new curve at the next evaluation. |
| Apply duty, send 0–100 over serial, or adjust with K1/K2 | Enter Manual after PWM succeeds. On failure, retain the previous mode and applied duty. |
| Press K3 alone or change page with K4 | Keep the current mode and fan speed setting. |

The three modes are mutually exclusive. Serial, dashboard and button commands share fanDuty and applyDuty(). The main loop services serial, HTTP commands, buttons, temperature control, the one-second RPM sample and PID. Manual takeover prevents automatic updates from overriding the command. The interface reports PWM failure and distinguishes calculated duty from the last successfully applied duty.

## Temperature profile and sensor

The editor takes three finite decimal temperatures from −40 to 125°C and three integer duties from 0 to 100%. T1 < T2 < T3 and D1 ≤ D2 ≤ D3. Browser and firmware validate the full set. The parser rejects NaN, infinity, exponents and trailing characters and checks ordering after float conversion. Invalid edits leave the active curve intact.

The controller linearly interpolates between adjacent points, rounds to whole percent and clamps to the endpoint duties outside the range. The default curve gives about 38% at 27°C and 75% at 29°C. Temperature input comes from the physical SHT30. The dashboard shows confirmed mode, temperature, calculated duty, applied duty, RPM and the active curve revision. Polling preserves unfinished edits. HTTP 202 acknowledges the queue. Check the next device snapshot for application.

The SHT30 at 0x44 is sampled about every two seconds. A reading requires driver CRC validation and finite temperature (−40 to 125°C) and humidity (0–100% RH). A failed read, missing ACK, unavailable service or age of at least five seconds invalidates the temperature.

- Manual retains the requested duty during a sensor fault. Auto requests 100% ventilation, shows a fault/fallback on the dashboard and FAIL on the OLED. A fresh valid sample restores curve control.
- A failed PWM application is reported on the dashboard and serial monitor. The controller retries about every 250 ms while retaining the applied value.
- Missing or failed readings are hidden immediately. Recovery is retried about every five seconds. The API returns null for invalid readings and distinguishes starting, unavailable and stale states. A disconnected page clears sensor data and marks the mode unconfirmed.

## Physical buttons

| Key | GPIO | Verified role, top to bottom |
|---|---:|---|
| K1 | 7 | Increase by 5 percentage points |
| K2 | 8 | Decrease by 5 percentage points |
| K3 | 9 | Hold for 1-point K1/K2 steps |
| K4 | 10 | Toggle overview and large temperature/humidity pages |

Inputs use INPUT_PULLUP, active LOW, about 5 ms polling and 30 ms debounce. Each press acts once. Release a key held at startup before using it. Opposing directions together leave duty unchanged. Duty is bounded to 0–100%. Roles can be remapped in LocalButtons.h. See [wiring](WIRING.md) for connector labels. A zero command can leave the fan spinning. Two pulses per revolution are assumed. The configured 25 kHz PWM has not been verified with an oscilloscope.

## Tasks and source files

The main loop handles commands, temperature control, RPM and protected snapshots. A dedicated network task owns Wi-Fi, DNS and runtime NVS writes. One I2C task owns the OLED and SHT30, including the driver's roughly 15 ms conversion wait. Wire timeout is 20 ms. The OLED refreshes about every 500 ms and retries a missing display every five seconds. HTTP and RGB use separate tasks. HTTP reads snapshots. Each browser page serializes its network requests.

TemperatureProfile.h parses, validates and interpolates profiles. TemperatureControl.h handles modes and fallback. EnvironmentReading.h and EnvironmentMonitor.h manage sensor validity. ButtonLogic.h and LocalButtons.h handle keys. WebDashboard.h and DashboardPage.h provide the control API and page. I2cPeripherals.h drives the display. NetworkConfig.h, ConfigStorage.h, NetworkState.h, Provisioning.h and SetupPage.h cover record validation, readback, snapshots, network tasks and setup UI.

## HTTP API

POST requests use form-urlencoded data and the X-Fan-Control: 1 header. Invalid fields return 400, a missing control header returns 403, and unavailable output or a full queue returns 503. A 202 response queues a request. Read the subsequent state to confirm the result.

| Request | Payload or result |
|---|---|
| GET / | Embedded page, with no external resources |
| GET /api/status | Current snapshot without triggering a measurement |
| POST /api/duty | duty, integer 0–100. Successful application selects Manual. |
| POST /api/mode | mode=manual, automatic or pid |
| POST /api/rpm | rpm, integer 0–20000. Sets the target and selects PID. |
| POST /api/profile | Exactly t1, t2, t3, d1, d2 and d3. Replaces the full curve and retains the mode. |

Status includes duty, rpm (null when unavailable), wifi, sampleAgeMs, temperatureC, humidityPercent, sensorStatus, sensorAgeMs (null until the first success), sensorStaleAfterMs (5000), mode, fallback, outputFailed, calculatedDuty (null in Manual), profileRevision and profile.temperatures/duties. Sensor status can be starting, ok, missing, read_error, stale or unavailable.

Profiles apply in RAM and save asynchronously. Check profileSave before cycling power. A restored curve starts at revision 1. Default settings start at revision 0. See [provisioning and setup API](PROVISIONING.md) for successful connection, timeout, AP closure and storage feedback.

## Dashboard and PID

Select Manual, Auto temp or PID RPM in section 02. Section 03 shows the device-confirmed mode and preserves hidden edits. PID uses fresh tachometer samples, faster adjustment far from the target and lower gain and slew near it. Inside ±45 RPM it holds the applied duty and continues to show the measured RPM. See [PID.md](PID.md) for settings and limits.

The idle-4 main loop waits one RTOS tick per iteration and publishes snapshots at most once every 20 ms. PID parameters match stable-3. Any change in chip temperature or power consumption still needs measurement. See the [final acceptance checklist](../TEST_PLAN.md).
