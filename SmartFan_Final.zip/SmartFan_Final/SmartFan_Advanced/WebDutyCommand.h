#pragma once

#include "DutyCommandParser.h"

// HTTP values must contain exactly one command, never an embedded line break.
inline CommandResult parseWebDuty(const char *text, size_t length, int &output) {
  if (length > 32) return CommandResult::TooLong;
  DutyCommandParser parser;
  int value = 0;
  for (size_t i = 0; i < length; ++i) {
    if (text[i] == '\r' || text[i] == '\n' || text[i] == '\0')
      return CommandResult::Invalid;
    parser.feed(text[i], value);
  }
  CommandResult result = parser.feed('\n', value);
  if (result == CommandResult::Valid) output = value;
  return result;
}
