#pragma once

const char SETUP_HTML[] PROGMEM = R"SETUP(<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><link rel="icon" href="data:,"><title>SmartFan · Network</title><style>
:root{color-scheme:light;--ink:#202a29;--muted:#65706d;--line:#d9dfdc;--accent:#185e50;--canvas:#f4f5f2;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;color:var(--ink);background:var(--canvas)}*{box-sizing:border-box;border-radius:0!important}[hidden]{display:none!important}body{margin:0;padding:0 28px}main{max-width:1080px;margin:auto}button,input{font:inherit}a{color:var(--accent);text-underline-offset:4px}button:focus-visible,a:focus-visible,input:focus-visible,summary:focus-visible{outline:2px solid var(--accent);outline-offset:3px}.topbar{height:76px;border-bottom:1px solid var(--line);display:flex;align-items:center;justify-content:space-between;gap:16px}.brand{display:flex;align-items:center;gap:10px;font-size:17px;font-weight:750;letter-spacing:-.5px}.brand-mark{display:grid;place-items:center;width:29px;height:29px;font-size:11px;background:var(--ink);color:#fff;letter-spacing:0}.topbar a{font-size:13px;font-weight:600;text-decoration:none}.page-heading{padding:28px 0 25px}.eyebrow{font-size:10px;font-weight:700;letter-spacing:1.8px;color:var(--muted);margin:0 0 9px}h1{font-size:34px;letter-spacing:-1.2px;line-height:1.1;font-weight:650;margin:0}h2{font-size:19px;letter-spacing:-.4px;font-weight:650;margin:0}.subtitle{font-size:14px;color:var(--muted);line-height:1.6;margin:10px 0 0}.setup-grid{display:grid;grid-template-columns:minmax(0,.9fr) minmax(0,1.15fr);gap:22px;align-items:start}.panel{background:white;border:1px solid var(--line);padding:25px}.panel-header{border-bottom:1px solid var(--line);padding-bottom:20px;margin-bottom:20px}.panel-header .eyebrow{margin-bottom:6px}#network-state{font-size:16px;line-height:1.6;font-weight:600;margin:0;padding-left:12px;border-left:3px solid #a46b15;overflow-wrap:anywhere}#network-state[data-kind=success]{border-color:var(--accent);color:var(--accent)}#network-state[data-kind=error]{border-color:#a22f26;color:#a22f26}#connection-next{font-size:13px;line-height:1.8;color:var(--muted);margin:13px 0 18px}button{min-height:42px;padding:11px 16px;background:var(--accent);color:white;font-size:13px;font-weight:600;border:1px solid var(--accent);cursor:pointer;line-height:1.3}button:hover{background:#12483e}button:disabled{opacity:.45;cursor:wait}#check-connection{background:white;color:var(--accent);border:1px solid #bcc6c0;margin-top:10px}#connected-dashboard{display:block;font-size:13px;font-weight:600;line-height:1.6;margin:12px 0 0}label{display:block;font-size:12px;font-weight:650;margin:20px 0 8px;color:#4d5b53}label:first-of-type{margin-top:0}.optional{font-weight:400;color:var(--muted);margin-left:6px}input{width:100%;min-height:44px;padding:10px 12px;font-size:16px;background:white;border:1px solid #bcc6c0;color:var(--ink)}input:hover{border-color:#8f9f95}.note{font-size:12px;line-height:1.7;color:var(--muted);margin:9px 0 0}.tip{border-left:2px solid var(--line);padding-left:10px}.form-actions{border-top:1px solid var(--line);padding-top:20px;margin-top:24px;display:flex;align-items:center;justify-content:space-between;gap:15px}.form-actions .note{margin:0;max-width:180px;font-size:11px}#message{font-size:13px;line-height:1.7;margin:16px 0 0;border-left:2px solid var(--line);padding-left:12px;overflow-wrap:anywhere}#message:empty{display:none}#message[data-error=true]{color:#a22f26;border-color:#a22f26}.steps{border-top:1px solid var(--line);padding-top:18px;margin-top:22px}.steps h3{font-size:12px;margin:0 0 12px}.steps ol{padding-left:18px;margin:0;color:var(--muted);font-size:12px;line-height:1.8}.steps li+li{margin-top:9px}.help{background:#f5f6f3;padding:12px 14px;margin-top:18px;font-size:12px;line-height:1.7;color:var(--muted)}.help summary{cursor:pointer;font-weight:600;color:#4d5b53}.help p{margin:8px 0 0}footer{border-top:1px solid var(--line);margin-top:25px;padding:18px 0 24px;color:var(--muted);font-size:11px;line-height:1.6}
@media(max-width:760px){.setup-grid{grid-template-columns:1fr}.page-heading{padding:24px 0}.panel{padding:22px}}@media(max-width:480px){body{padding:0 16px}.topbar{height:65px}h1{font-size:29px}.panel{padding:20px}.form-actions{align-items:stretch;flex-direction:column}.form-actions .note{max-width:none}.form-actions button{width:100%}}
</style></head><body><main>
<header class="topbar"><div class="brand"><span class="brand-mark" aria-hidden="true">SF</span>SmartFan</div><a href="/dashboard">Fan control ↗</a></header>
<div class="page-heading"><p class="eyebrow">DEVICE / NETWORK SETTINGS</p><h1>Wi-Fi setup</h1><p class="subtitle">Connect your device. Keep its settings.</p></div>
<div class="setup-grid">
<section class="panel" aria-labelledby="connection-title"><div class="panel-header"><p class="eyebrow">01 / CONNECTION</p><h2 id="connection-title">Connection status</h2></div>
<p id="network-state" role="status" aria-live="polite">Checking the device connection…</p>
<p id="connection-next">This page shows when settings are saved and when the device joins Wi-Fi.</p>
<a id="connected-dashboard" hidden>Open fan controls</a><button id="check-connection" type="button">Check connection again</button>
<div class="steps"><h3>After saving</h3><ol><li>Wait for the device to confirm the save and restart.</li><li>Reconnect your computer to the target Wi-Fi.</li><li>Open the new IP shown on the OLED.</li></ol></div>
<details class="help"><summary>If the device cannot connect</summary><p>After a 15-second connection timeout, join SmartFan-Setup-… and open http://192.168.4.1/setup to configure again. The device keeps local fan control running.</p></details></section>
<form id="setup-form" class="panel" novalidate aria-labelledby="network-title"><div class="panel-header"><p class="eyebrow">02 / CONFIGURATION</p><h2 id="network-title">Network details</h2></div>
<label for="ssid">Wi-Fi name · SSID</label><input id="ssid" name="ssid" autocomplete="off" required>
<p class="note tip">Use a 2.4 GHz network.</p>
<label for="password">Wi-Fi password</label><input id="password" name="password" type="password" autocomplete="new-password">
<p class="note">8–63 characters, or a 64-digit hexadecimal key. Leave empty only for an open network.</p>
<label for="server-url">Server URL<span class="optional">Optional</span></label><input id="server-url" name="serverUrl" type="url" placeholder="http://192.168.1.10:8080" autocomplete="off">
<p class="note">May be left empty. The address is stored for a future Hub; no data is sent to it.</p>
<div class="form-actions"><p class="note">Settings are stored on the device. Saving restarts it.</p><button id="save-network" type="submit">Save and restart</button></div>
<p id="message" role="status" aria-live="polite"></p>
</form></div><footer>Local device setup · no internet connection required</footer>
</main>
<script>
const field=id=>document.getElementById(id);
let setupBusy=false,setupSubmitted=false,setupNext=0,pendingNetwork=null;
let saveConfirmed=false,recheckRequested=false;
function connectionFeedback(kind,title,next) {field('network-state').dataset.kind=kind;field('network-state').textContent=title;field('connection-next').textContent=next;}
async function setupRequest(path,options={}) {
 const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),4000);
 try{const response=await fetch(path,{...options,cache:'no-store',signal:controller.signal});const data=await response.json();if(!response.ok)throw new Error(data.error||'Request failed');return data;}finally{clearTimeout(timer);}
}
function setupMessage(message,error=false){field('message').textContent=message;field('message').dataset.error=String(error);}
async function setupPoll(){
 if(setupBusy)return;setupBusy=true;
 try{
  if(pendingNetwork!==null) {
   const body=pendingNetwork;pendingNetwork=null;
   try{await setupRequest('/api/network',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded','X-Fan-Control':'1'},body});field('password').value='';setupMessage('Settings submitted. Waiting for the device to confirm the save.');}
   catch(error){setupSubmitted=false;field('save-network').disabled=false;setupMessage(error.message+' Check device state before retrying.',true);}
  }
  const s=await setupRequest('/api/setup-state');

  field('connected-dashboard').hidden=true;
  if(s.online) {
   connectionFeedback('success','Wi-Fi connected · '+s.stationIp,s.apActive?'The device has an IP address. The setup hotspot is closing.':'The setup hotspot is closed. You can open the fan controls.');
   if(/^\d{1,3}(?:\.\d{1,3}){3}$/.test(s.stationIp)) {field('connected-dashboard').href='http://'+s.stationIp+'/';field('connected-dashboard').hidden=false;}
  } else if(s.phase==='setup' && s.hasSavedNetwork && s.save!=='pending' && s.save!=='saved_restart') {
   connectionFeedback('error','Connection timed out. Setup hotspot is available.','The device could not join within 15 seconds. Check the network name and password, and make sure the 2.4 GHz network is on. Then try again.');
   setupSubmitted=false;saveConfirmed=false;field('save-network').disabled=false;field('save-network').textContent='Save and restart';
  } else if(s.phase==='connecting') {
   connectionFeedback('pending','Connecting to the saved network…','Waiting for an IP address. The setup hotspot will reopen if the connection times out after 15 seconds.');
  } else if(s.apActive) {
   connectionFeedback('pending','Setup hotspot: '+s.setupSsid,'Enter the network details and save. The device will restart and try to join.');
  } else {
   connectionFeedback('pending','Device network state: '+s.phase,'Waiting for the device to confirm the Wi-Fi connection.');
  }
  if(s.save==='error'){setupSubmitted=false;field('save-network').disabled=false;setupMessage('Storage save failed. Settings were not confirmed; retry.',true);}
  else if(s.save==='saved_restart'){saveConfirmed=true;field('save-network').textContent='Saved. Restarting…';connectionFeedback('pending','Settings saved and verified. Restarting…','Reconnect your computer to the target network. Check the OLED for the new IP and open the fan controls.');setupMessage('Settings saved. Wi-Fi status will be available after restart.');}
  else if(s.save==='pending'){connectionFeedback('pending','Saving settings…','Waiting for the device to confirm the save.');setupMessage('The device is writing and verifying the settings.');}
 
 }catch(error){
  field('connected-dashboard').hidden=true;
  if(setupSubmitted) {
   connectionFeedback('pending','Connection unconfirmed. The setup page lost contact with the device.','Reconnect to the target network and open the IP shown on the OLED. If the device fails to join, reconnect to SmartFan-Setup-… to see the timeout status.');
   field('save-network').textContent='Submitted. Check connection status';
   setupMessage(saveConfirmed?'Save confirmed. Check the OLED or dashboard for the Wi-Fi connection result.':'Connection lost after submission. Reconnect to check whether the settings were saved and Wi-Fi connected.');
  } else connectionFeedback('error','Device status unavailable','Check which Wi-Fi network your computer is using, then select Check connection again.');
 }
 finally{setupBusy=false;const soon=pendingNetwork!==null||recheckRequested;recheckRequested=false;setupNext=setTimeout(setupPoll,soon?0:1000);}
}
field('setup-form').addEventListener('submit',event=>{
 event.preventDefault();if(field('save-network').disabled)return;
 const ssid=field('ssid').value,password=field('password').value,url=field('server-url').value.trim();
 const bytes=text=>new TextEncoder().encode(text).length;
 const passwordSize=bytes(password);
 if(!ssid||bytes(ssid)>32||/[\x00-\x1f\x7f]/.test(ssid+password)||passwordSize>64||(passwordSize>0&&passwordSize<8)||(passwordSize===64&&!/^[0-9a-fA-F]{64}$/.test(password))||bytes(url)>192||(url&&!/^https?:\/\/[^\s]+$/.test(url))){setupMessage('Check SSID (1–32 bytes), password and HTTP/HTTPS URL.',true);return;}
 pendingNetwork=new URLSearchParams({ssid,password,serverUrl:url}).toString();
 setupSubmitted=true;saveConfirmed=false;field('save-network').disabled=true;field('save-network').textContent='Submitting…';connectionFeedback('pending','Submitting network settings…','Waiting for save confirmation. The device will then restart and try to connect.');setupMessage('Sending settings…');
 if(!setupBusy){clearTimeout(setupNext);setupNext=setTimeout(setupPoll,0);}
});
field('check-connection').addEventListener('click',()=>{if(setupBusy){recheckRequested=true;return;}clearTimeout(setupNext);setupNext=setTimeout(setupPoll,0);});
setupPoll();
</script></body></html>)SETUP";
