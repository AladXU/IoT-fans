#pragma once
#include <WiFi.h>
#include <DNSServer.h>
#include <freertos/FreeRTOS.h>
#include <freertos/queue.h>
#include <freertos/task.h>
#include "ConfigStorage.h"
#include "NetworkState.h"

constexpr uint32_t PROVISION_CONNECT_MS=15000;
constexpr uint32_t PROVISION_RETRY_MS=30000;
portMUX_TYPE networkMux=portMUX_INITIALIZER_UNLOCKED;
NetworkSnapshot networkSnapshot;
NetworkSnapshot networkOwned; // Network task's private state; never contains a password.
NetworkConfig stationConfig={}; // Private; never returned in HTTP or serial logs.
bool savedNetworkValid=false,networkConnecting=false,networkRestartPending=false;
uint32_t networkAttemptSince=0,networkRetrySince=0,networkRestartSince=0;
uint32_t requestedProfileRevision=0;
DNSServer setupDns;
TaskHandle_t networkTaskHandle=nullptr;
enum class NetworkRequestType {Configure,Profile};
struct NetworkRequest {
  NetworkRequestType type;
  NetworkConfig config;
  TemperatureProfile profile;
  uint32_t revision;
};
QueueHandle_t networkRequestQueue=nullptr;

NetworkSnapshot readNetworkSnapshot() {
  portENTER_CRITICAL(&networkMux);NetworkSnapshot result=networkSnapshot;portEXIT_CRITICAL(&networkMux);return result;
}
void publishNetworkState() {
  portENTER_CRITICAL(&networkMux);
  auto save=networkSnapshot.profileSave;auto revision=networkSnapshot.profileSavedRevision;
  auto configSave=networkSnapshot.networkSave;
  networkSnapshot=networkOwned;
  networkSnapshot.profileSave=save;networkSnapshot.profileSavedRevision=revision;
  networkSnapshot.networkSave=configSave;
  portEXIT_CRITICAL(&networkMux);
}
bool queueNetworkConfiguration(const NetworkConfig &config) {
  if(!validNetworkConfig(config)||!networkRequestQueue)return false;
  portENTER_CRITICAL(&networkMux);
  bool busy=networkSnapshot.networkSave==NetworkSaveState::Pending || networkSnapshot.networkSave==NetworkSaveState::SavedRestart;
  if(!busy)networkSnapshot.networkSave=NetworkSaveState::Pending;
  portEXIT_CRITICAL(&networkMux);
  if(busy)return false;
  NetworkRequest command={};command.type=NetworkRequestType::Configure;command.config=config;
  if(xQueueSend(networkRequestQueue,&command,0)==pdTRUE)return true;
  portENTER_CRITICAL(&networkMux);networkSnapshot.networkSave=NetworkSaveState::Error;portEXIT_CRITICAL(&networkMux);return false;
}
bool queueProfilePersistence(const TemperatureProfile &profile,uint32_t revision) {
  NetworkRequest command={};command.type=NetworkRequestType::Profile;command.profile=profile;command.revision=revision;
  portENTER_CRITICAL(&networkMux);
  requestedProfileRevision=revision;networkSnapshot.profileSave=ProfileSaveState::Pending;
  portEXIT_CRITICAL(&networkMux);
  if(networkRequestQueue && xQueueSend(networkRequestQueue,&command,0)==pdTRUE)return true;
  portENTER_CRITICAL(&networkMux);networkSnapshot.profileSave=ProfileSaveState::Error;portEXIT_CRITICAL(&networkMux);return false;
}

bool startSetupNetwork() {
  if(networkOwned.apActive)return true;
  WiFi.persistent(false);
  IPAddress address(192,168,4,1);
  bool ready=WiFi.mode(WIFI_AP_STA) &&
    WiFi.softAPConfig(address,address,IPAddress(255,255,255,0)) &&
    WiFi.softAP(networkOwned.setupSsid,nullptr,1,0,4);
  networkOwned.apActive=ready;
  networkOwned.phase=ready?NetworkPhase::Setup:NetworkPhase::Unavailable;
  if(ready) {
    setupDns.setTTL(0);
    networkOwned.dnsReady=setupDns.start(53,"*",address);
    Serial.printf("Setup Wi-Fi: %s | http://192.168.4.1/setup | DNS=%s\n",networkOwned.setupSsid,networkOwned.dnsReady?"ready":"unavailable; use IP directly");
  } else Serial.println("Setup AP failed; retrying in background. Local fan control remains active.");
  return ready;
}
void beginSavedConnection() {
  networkOwned.online=false;
  for(auto &v:networkOwned.ip)v=0;
  WiFi.persistent(false);
  if(!WiFi.mode(networkOwned.apActive?WIFI_AP_STA:WIFI_STA)) {
    networkOwned.phase=NetworkPhase::Unavailable;networkConnecting=false;networkRetrySince=millis();return;
  }
  WiFi.setAutoReconnect(false);
  WiFi.begin(stationConfig.ssid,stationConfig.password);
  networkConnecting=true;networkAttemptSince=millis();
  networkOwned.phase=NetworkPhase::Connecting;
  Serial.println("Wi-Fi: connecting using saved NVS settings (15s timeout)");
}
void initializeNetwork() {
  uint64_t mac=ESP.getEfuseMac();
  snprintf(networkOwned.setupSsid,sizeof(networkOwned.setupSsid),"SmartFan-Setup-%06lX",(unsigned long)(mac&0xffffffu));
  savedNetworkValid=loadNetworkConfig(stationConfig);
  networkOwned.hasSavedNetwork=savedNetworkValid;
  networkRetrySince=millis();
  if(savedNetworkValid)beginSavedConnection();
  else {Serial.println("No valid NVS network settings; starting setup AP");startSetupNetwork();}
  publishNetworkState();
}
void processNetworkRequest() {
  NetworkRequest command;
  if(!networkRequestQueue || xQueueReceive(networkRequestQueue,&command,0)!=pdTRUE)return;
  if(command.type==NetworkRequestType::Profile) {
    bool ok=storeTemperatureProfile(command.profile);
    portENTER_CRITICAL(&networkMux);
    if(command.revision==requestedProfileRevision)networkSnapshot.profileSave=ok?ProfileSaveState::Saved:ProfileSaveState::Error;
    if(ok)networkSnapshot.profileSavedRevision=command.revision;
    portEXIT_CRITICAL(&networkMux);
    Serial.println(ok?"Temperature profile saved to NVS":"Profile NVS save failed; current RAM profile remains active");
  } else {
    bool ok=storeNetworkConfig(command.config);
    portENTER_CRITICAL(&networkMux);networkSnapshot.networkSave=ok?NetworkSaveState::SavedRestart:NetworkSaveState::Error;portEXIT_CRITICAL(&networkMux);
    if(ok) {
      networkRestartPending=true;networkRestartSince=millis();
      Serial.println("Network settings saved and verified; restarting in 2 seconds");
    } else Serial.println("Network NVS save failed; no restart. Use setup page to retry.");
  }
  memset(&command,0,sizeof(command));
}
void serviceProvisioning() {
  processNetworkRequest();
  if(networkRestartPending && (uint32_t)(millis()-networkRestartSince)>=2000) {ESP.restart();return;}
  IPAddress ip=WiFi.localIP();
  bool online=savedNetworkValid && WiFi.status()==WL_CONNECTED && !(ip==IPAddress(0,0,0,0));
  if(online) {
    if(!networkOwned.online) {
      Serial.print("Wi-Fi connected, IP: ");Serial.println(ip);
    }
    networkOwned.online=true;networkConnecting=false;networkOwned.phase=NetworkPhase::Online;
    for(int i=0;i<4;++i)networkOwned.ip[i]=ip[i];
    if(networkOwned.apActive && WiFi.softAPdisconnect(true)) {
      setupDns.stop();networkOwned.apActive=false;networkOwned.dnsReady=false;
      WiFi.mode(WIFI_STA);
      Serial.println("Setup AP and captive DNS stopped after successful station connection");
    }
  } else {
    if(networkOwned.online) {
      networkOwned.online=false;for(auto &v:networkOwned.ip)v=0;
      networkOwned.phase=NetworkPhase::Retry;networkRetrySince=millis();
      WiFi.disconnectAsync(false,false);
      Serial.println("Wi-Fi lost; local control continues. Saved network retry in 30s.");
    }
    if(networkConnecting && (uint32_t)(millis()-networkAttemptSince)>=PROVISION_CONNECT_MS) {
      WiFi.disconnectAsync(false,false);networkConnecting=false;networkRetrySince=millis();
      startSetupNetwork();networkOwned.phase=networkOwned.apActive?NetworkPhase::Setup:NetworkPhase::Unavailable;
      Serial.println("Wi-Fi timeout; setup AP available for reconfiguration; saved settings retry every 30s");
    } else if(!networkConnecting && (uint32_t)(millis()-networkRetrySince)>=PROVISION_RETRY_MS) {
      networkRetrySince=millis();
      if(savedNetworkValid)beginSavedConnection();
      else if(!networkOwned.apActive)startSetupNetwork();
    }
  }
  // Core 3.3.10 DNSServer handles requests asynchronously; this is a compatibility no-op.
  if(networkOwned.dnsReady)setupDns.processNextRequest();
  publishNetworkState();
}
void provisioningTask(void *) {
  initializeNetwork();
  for(;;) {serviceProvisioning();vTaskDelay(pdMS_TO_TICKS(10));}
}
void restoreProfileAtBoot() {
  TemperatureProfile restored;
  bool loaded=loadStoredProfile(restored);
  if(loaded) {activeProfile=restored;profileRevision=1;}
  portENTER_CRITICAL(&networkMux);
  networkSnapshot.profileSave=loaded?ProfileSaveState::Saved:ProfileSaveState::Default;
  networkSnapshot.profileSavedRevision=loaded?profileRevision:0;
  portEXIT_CRITICAL(&networkMux);
  Serial.println(loaded?"Temperature profile restored from NVS; boot mode remains manual":"Using default temperature profile (no valid saved profile)");
}
void startProvisioning() {
  networkRequestQueue=xQueueCreate(4,sizeof(NetworkRequest));
  if(!networkRequestQueue || xTaskCreate(provisioningTask,"fanNetwork",10240,nullptr,1,&networkTaskHandle)!=pdPASS) {
    if(networkRequestQueue)vQueueDelete(networkRequestQueue);networkRequestQueue=nullptr;
    portENTER_CRITICAL(&networkMux);networkSnapshot.phase=NetworkPhase::Unavailable;portEXIT_CRITICAL(&networkMux);
    Serial.println("Network service unavailable; local control remains active");
  }
}
