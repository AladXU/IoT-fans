#include <Arduino.h>
#include <Wire.h>
#include <WiFi.h>
#include <esp_system.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include "DutyCommandParser.h"
#include "EnvironmentMonitor.h"

constexpr uint8_t FAN_CTRL = 4;
constexpr uint8_t TACH_PIN = 5;
constexpr int START_DUTY = 50;
constexpr float PULSES_PER_REV = 2.0f;  // Assumed; not independently calibrated.
constexpr uint8_t SDA_PIN = 12;
constexpr uint8_t SCL_PIN = 13;
constexpr uint8_t OLED_ADDRESS = 0x3C;

Adafruit_SSD1306 oled(128, 64, &Wire, -1, 100000, 100000);

volatile uint32_t pulseCount = 0;
portMUX_TYPE pulseMux = portMUX_INITIALIZER_UNLOCKED;
DutyCommandParser commandParser;
bool pwmReady = false;
int fanDuty = -1;
uint32_t lastSample = 0;
float currentRpm = 0;
bool rpmValid = false;
bool i2cReady = false;
bool oledReady = false;
uint32_t lastOledAttempt = 0;
uint32_t lastOledRefresh = 0;
uint8_t oledPage = 0;  // Main-loop-owned; I2C task reads a protected snapshot.

void ARDUINO_ISR_ATTR onTach() {
  portENTER_CRITICAL_ISR(&pulseMux);
  pulseCount = pulseCount + 1;
  portEXIT_CRITICAL_ISR(&pulseMux);
}

bool applyDuty(int duty) {
  if (!pwmReady || duty < 0 || duty > 100) return false;
  uint32_t gpioDuty = ((100 - duty) * 255 + 50) / 100;
  if (!ledcWrite(FAN_CTRL, gpioDuty)) return false;
  fanDuty = duty;
  return true;
}

#include "TemperatureControl.h"
#include "Provisioning.h"

void handleSerial() {
  // Bound work per loop so serial input cannot starve RPM sampling.
  for (unsigned int budget = 0; budget < 64 && Serial.available(); ++budget) {
    int requestedDuty = 0;
    CommandResult result = commandParser.feed((char)Serial.read(), requestedDuty);
    switch (result) {
      case CommandResult::None:
        break;
      case CommandResult::Valid:
        if (applyManualDuty(requestedDuty)) {
          Serial.printf("Accepted: duty=%d%%\n", fanDuty);
        } else {
          Serial.println("Rejected: PWM unavailable; setting unchanged");
        }
        break;
      case CommandResult::OutOfRange:
        Serial.println("Rejected: duty must be 0..100; setting unchanged");
        break;
      case CommandResult::TooLong:
        Serial.println("Rejected: line too long; setting unchanged");
        break;
      case CommandResult::Invalid:
        Serial.println("Rejected: enter a whole number 0..100; setting unchanged");
        break;
    }
  }
}

void sampleRpm() {
  if (millis() - lastSample < 1000) return;
  uint32_t sampledAt;
  uint32_t pulses;
  portENTER_CRITICAL(&pulseMux);
  sampledAt = millis();
  pulses = pulseCount;
  pulseCount = 0;
  portEXIT_CRITICAL(&pulseMux);

  uint32_t elapsed = sampledAt - lastSample;
  lastSample = sampledAt;
  float rpm = pulses * 60000.0f / (PULSES_PER_REV * elapsed);
  currentRpm = rpm;
  rpmValid = true;
  if (fanDuty >= 0) Serial.printf("Duty: %d%%", fanDuty);
  else Serial.print("Duty: unavailable");
  Serial.printf(" | Pulses: %lu | dt: %lu ms | RPM: %.0f\n",
                (unsigned long)pulses, (unsigned long)elapsed, rpm);
}

#include "LocalButtons.h"
#include "WebDashboard.h"
#include "RpmStatusLed.h"
#include "I2cPeripherals.h"

void setup() {
  Serial.begin(115200);
  delay(1500);
  Serial.printf("Boot: smartfan-advanced-pid-idle-4 | reset reason=%d\n", (int)esp_reset_reason());

  digitalWrite(FAN_CTRL, LOW);
  pinMode(FAN_CTRL, OUTPUT);
  pwmReady = ledcAttach(FAN_CTRL, 25000, 8);
  if (!applyDuty(START_DUTY)) {
    Serial.println("PWM initialization failed");
  }

  pinMode(TACH_PIN, INPUT);  // Existing external 10k pull-up to 3.3V.
  attachInterrupt(digitalPinToInterrupt(TACH_PIN), onTach, FALLING);
  portENTER_CRITICAL(&pulseMux);
  pulseCount = 0;
  lastSample = millis();
  portEXIT_CRITICAL(&pulseMux);

  Serial.println("Manual fan control ready. Enter 0..100, then press Enter.");
  Serial.println("RPM assumes 2 pulses/revolution. Duty 0% may still spin.");
  if (fanDuty >= 0) Serial.printf("Starting duty: %d%%\n", fanDuty);

  startLocalButtons();
  startRpmStatusLed();

  restoreProfileAtBoot();
  startDashboard();
  startI2cPeripherals();
  startProvisioning();
}

void loop() {
  handleSerial();
  processDashboardCommands();
  serviceLocalButtons();
  serviceTemperatureControl();
  sampleRpm();
  serviceRpmControl();
  // Readers run at 20ms or slower; avoid copying/locking snapshots in a busy loop.
  static uint32_t lastSnapshotPublish = 0;
  const uint32_t now = millis();
  if ((uint32_t)(now - lastSnapshotPublish) >= 20) {
    publishDashboardSnapshot();
    lastSnapshotPublish = now;
  }
  // Block this task for one RTOS tick so the idle task and other work can run.
  // PWM hardware and TACH interrupts continue; RPM uses actual elapsed time.
  vTaskDelay(1);
}
