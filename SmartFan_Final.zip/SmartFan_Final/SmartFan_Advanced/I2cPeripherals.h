#pragma once

// Single owner for Wire, OLED, and SHT30. No I2C calls in the main or HTTP tasks.
bool oledResponds() {
  Wire.beginTransmission(OLED_ADDRESS);
  return Wire.endTransmission() == 0;
}

bool startOled() {
  if (!i2cReady || !oledResponds()) return false;
  // Keep Wire on the already configured GPIO12/GPIO13 pins.
  if (!oled.begin(SSD1306_SWITCHCAPVCC, OLED_ADDRESS, true, false)) return false;
  oled.setTextColor(SSD1306_WHITE);
  oled.setTextWrap(false);
  return true;
}

void serviceOled() {
  if (!i2cReady) return;
  uint32_t now = millis();
  if (!oledReady) {
    if (now - lastOledAttempt < 5000) return;
    lastOledAttempt = now;
    oledReady = startOled();
    if (!oledReady) return;
    Serial.println("OLED 0x3C ready");
  }
  if (now - lastOledRefresh < 500) return;
  lastOledRefresh = now;
  if (!oledResponds()) {
    oledReady = false;
    lastOledAttempt = now;
    Serial.println("OLED unavailable; serial control and RPM remain active");
    return;
  }

  DashboardSnapshot state = readDashboardSnapshot();
  uint32_t displayedAt = millis();
  oled.clearDisplay();
  oled.setTextSize(1);
  oled.setCursor(0, 0);
  oled.print(state.mode==FanMode::Pid ? (state.pidFault ? "RPM! | " : "PID | ") : state.mode==FanMode::Automatic ? (state.fallback ? "FAIL | " : "AUTO | ") : "MAN | ");
  if(state.network.apActive && !state.wifi) oled.print("Setup AP");
  else if (state.wifi) oled.print("WiFi online");
  else if (state.wifiConnecting) oled.print("Connecting");
  else oled.print("WiFi offline");
  if(state.outputFailed) { oled.setCursor(0,0);oled.print("PWM ERROR           "); }
  oled.drawFastHLine(0, 10, 128, SSD1306_WHITE);

  if(state.network.apActive && !state.wifi) {
    oled.setTextSize(1);oled.setCursor(0,13);oled.print("Wi-Fi Not Connected");
    oled.setCursor(0,24);oled.print(state.network.setupSsid);
    oled.setCursor(0,35);oled.print("192.168.4.1/setup");
    oled.setCursor(0,46);oled.print("Duty ");oled.print(state.duty);oled.print("% RPM ");
    if(state.rpmValid)oled.print(state.rpm,0);else oled.print("--");
    oled.setCursor(0,56);
    EnvironmentStatus setupStatus=environmentStatusAt(state.environment,displayedAt);
    if(setupStatus==EnvironmentStatus::Ready) {oled.print("T:");oled.print(state.environment.temperature,1);oled.print("C RH:");oled.print(state.environment.humidity,0);oled.print('%');}
    else {oled.print("SHT: ");oled.print(environmentStatusLabel(setupStatus));}
    oled.display();return;
  }
  EnvironmentStatus status = environmentStatusAt(state.environment, displayedAt);
  if (state.oledPage == 0) {
  oled.setTextSize(2);
  oled.setCursor(0, 12);
  oled.print("Duty ");
  if (state.duty >= 0) { oled.print(state.duty); oled.print('%'); }
  else oled.print("--");

  oled.setTextSize(1);
  oled.setCursor(0, 31);
  oled.print("RPM ");
  if (state.rpmValid) oled.print(state.rpm, 0);
  else oled.print("--");

  oled.setTextSize(1);
  oled.setCursor(0, 43);
  if(state.mode==FanMode::Pid) {oled.print("Target ");oled.print(state.rpmTarget);oled.print(" RPM");}
  else if (status == EnvironmentStatus::Ready) {
    oled.print("T:"); oled.print(state.environment.temperature, 1); oled.print("C ");
    oled.print("RH:"); oled.print(state.environment.humidity, 1); oled.print('%');
  } else {
    oled.print("SHT: "); oled.print(environmentStatusLabel(status));
  }
  } else {
    oled.setCursor(0, 12);
    if (status == EnvironmentStatus::Ready) {
      oled.setTextSize(2);
      oled.print("T "); oled.print(state.environment.temperature, 1); oled.print('C');
      oled.setCursor(0, 31);
      oled.print("RH "); oled.print(state.environment.humidity, 1); oled.print('%');
    } else {
      oled.setTextSize(1);
      oled.print("SHT: "); oled.print(environmentStatusLabel(status));
      oled.setCursor(0, 28);
      oled.print("No current reading");
    }
    oled.setTextSize(1);
    oled.setCursor(0, 48);
    oled.print("Duty ");
    if (state.duty >= 0) { oled.print(state.duty); oled.print('%'); }
    else oled.print("--");
    oled.print(" RPM ");
    if (state.rpmValid) oled.print(state.rpm, 0);
    else oled.print("--");
  }
  oled.setTextSize(1);
  oled.setCursor(0, 56);
  if (state.wifi) {
    oled.print("IP ");
    oled.print(IPAddress(state.ip[0], state.ip[1], state.ip[2], state.ip[3]));
  } else {
    oled.print("Wi-Fi Not Connected");
  }
  oled.display();
}


TaskHandle_t i2cTaskHandle = nullptr;

void i2cPeripheralsTask(void *) {
  i2cReady = Wire.begin(SDA_PIN, SCL_PIN, 100000);
  if (i2cReady) Wire.setTimeOut(20);
  else setEnvironmentFailure(EnvironmentStatus::Unavailable);
  lastOledAttempt = millis();
  oledReady = startOled();
  Serial.println(oledReady ? "OLED 0x3C ready" : "OLED unavailable; fan and RPM continue");
  for (;;) {
    serviceEnvironment(i2cReady);
    serviceOled();
    vTaskDelay(pdMS_TO_TICKS(10));
  }
}

void startI2cPeripherals() {
  if (xTaskCreate(i2cPeripheralsTask, "fanI2c", 8192, nullptr, 1, &i2cTaskHandle) != pdPASS) {
    setEnvironmentFailure(EnvironmentStatus::Unavailable);
    Serial.println("I2C task unavailable; fan, RPM, serial and web remain active");
  }
}
