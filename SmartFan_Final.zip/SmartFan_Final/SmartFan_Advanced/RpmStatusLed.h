#pragma once

#include <esp32-hal-rmt.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include "RpmLedEffect.h"

constexpr uint8_t STATUS_LED_PIN = 21;
constexpr uint8_t STATUS_LED_BRIGHTNESS = 64;
constexpr uint32_t STATUS_LED_FRAME_MS = 20;
constexpr uint32_t STATUS_LED_STALE_MS = 3000;
constexpr uint32_t STATUS_LED_SELF_TEST_MS = 4200;
rmt_data_t statusLedSymbols[24];
bool statusLedReady = false;
bool ledSelfTestDone = false;
uint32_t lastLedFrame = 0;
uint32_t ledSelfTestStarted = 0;
RpmLedAnimator ledAnimator;
TaskHandle_t ledTaskHandle = nullptr;

uint8_t scaleStatusLed(uint8_t channel, uint8_t level) {
  return (uint8_t)((uint32_t)channel * level * STATUS_LED_BRIGHTNESS / (255u * 255u));
}

bool sendStatusLed(uint8_t red, uint8_t green, uint8_t blue) {
  // GRB is a candidate order. Verify it with the RED/GREEN/BLUE boot check.
  uint8_t colors[3] = {green, red, blue};
  size_t symbol = 0;
  for (uint8_t color : colors) {
    for (int bit = 7; bit >= 0; --bit) {
      bool high = (color & (1u << bit)) != 0;
      statusLedSymbols[symbol].level0 = 1;
      statusLedSymbols[symbol].duration0 = high ? 8 : 4;
      statusLedSymbols[symbol].level1 = 0;
      statusLedSymbols[symbol].duration1 = high ? 4 : 8;
      ++symbol;
    }
  }
  return rmtWriteAsync(STATUS_LED_PIN, statusLedSymbols, 24);
}

void serviceRpmStatusLed() {
  uint32_t now = millis();
  uint32_t elapsed = now - lastLedFrame;
  if (!statusLedReady || elapsed < STATUS_LED_FRAME_MS) return;
  if (!rmtTransmitCompleted(STATUS_LED_PIN)) return;
  lastLedFrame = now;
  RpmLedFrame frame;
  uint32_t sinceTestStart = now - ledSelfTestStarted;
  if (!ledSelfTestDone && sinceTestStart < STATUS_LED_SELF_TEST_MS) {
    frame = rpmLedSelfTestFrame(sinceTestStart);
  } else {
    if (!ledSelfTestDone) {
      ledSelfTestDone = true;
      ledAnimator.reset();
      elapsed = STATUS_LED_FRAME_MS;
      Serial.println("LED primary check complete; live RPM color and breathing active");
    }
    DashboardSnapshot snapshot = readDashboardSnapshot();
    bool fresh = snapshot.rpmValid && now - snapshot.sampledAt < STATUS_LED_STALE_MS;
    frame = ledAnimator.update(snapshot.rpm, fresh, elapsed);
  }
  if (!sendStatusLed(scaleStatusLed(frame.color.red, frame.level),
                     scaleStatusLed(frame.color.green, frame.level),
                     scaleStatusLed(frame.color.blue, frame.level))) {
    statusLedReady = false;
    Serial.println("RGB transmission failed; fan, RPM and web control continue");
  }
}

void rpmStatusLedTask(void *) {
  for (;;) {
    serviceRpmStatusLed();
    vTaskDelay(pdMS_TO_TICKS(STATUS_LED_FRAME_MS));
  }
}

void startRpmStatusLed() {
  statusLedReady = rmtInit(STATUS_LED_PIN, RMT_TX_MODE, RMT_MEM_NUM_BLOCKS_1, 10000000);
  if (statusLedReady) statusLedReady = rmtSetEOT(STATUS_LED_PIN, 0);
  if (statusLedReady) statusLedReady = sendStatusLed(0, 0, 0);
  lastLedFrame = millis();
  ledSelfTestStarted = lastLedFrame;
  if (statusLedReady &&
      xTaskCreate(rpmStatusLedTask, "fanLed", 4096, nullptr, 1, &ledTaskHandle) != pdPASS)
    statusLedReady = false;
  Serial.println(statusLedReady
      ? "LED primary check: RED -> GREEN -> BLUE, then smooth RPM effect (GRB candidate)"
      : "RGB unavailable; fan, RPM and web control continue");
}
