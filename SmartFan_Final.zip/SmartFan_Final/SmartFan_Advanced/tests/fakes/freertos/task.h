#pragma once
#include "FreeRTOS.h"
inline int xTaskCreate(void(*)(void*),const char*,int,void*,int,TaskHandle_t*) { return pdPASS; }
inline void vTaskDelay(int) {}
