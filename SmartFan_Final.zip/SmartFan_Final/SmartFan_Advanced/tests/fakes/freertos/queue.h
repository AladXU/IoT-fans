#pragma once
#include "FreeRTOS.h"
#include <deque>
#include <vector>
#include <cstring>
struct FakeQueue {unsigned capacity;size_t size;std::deque<std::vector<char>> values;};
inline QueueHandle_t xQueueCreate(int capacity, size_t size) {return new FakeQueue{unsigned(capacity),size,{}};}
inline int xQueueSend(QueueHandle_t q,const void* source,int) {
  auto *queue=static_cast<FakeQueue*>(q);if(queue->values.size()>=queue->capacity)return 0;
  const char *bytes=static_cast<const char*>(source);queue->values.emplace_back(bytes,bytes+queue->size);return pdTRUE;
}
inline int xQueueReceive(QueueHandle_t q,void* target,int) {
  auto *queue=static_cast<FakeQueue*>(q);if(queue->values.empty())return 0;
  memcpy(target,queue->values.front().data(),queue->size);queue->values.pop_front();return pdTRUE;
}
inline void vQueueDelete(QueueHandle_t q) {delete static_cast<FakeQueue*>(q);}
