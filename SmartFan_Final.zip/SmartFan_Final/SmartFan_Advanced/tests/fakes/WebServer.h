#pragma once
#include <string>
#include <vector>
#include <utility>
#define PROGMEM
#define HTTP_GET 0
#define HTTP_POST 1
using String = std::string;
struct WebServer {
  int code=0;
  std::string payload,controlHeader="1";
  std::vector<std::pair<std::string,std::string>> arguments={{"duty","50"}};
  explicit WebServer(int) {}
  void sendHeader(const char*,const char*) {}
  void send(int c,const char*,const char* text) {code=c;payload=text;}
  void send_P(int c,const char* t,const char* text) {send(c,t,text);}
  String header(const char*) {return controlHeader;}
  int args() {return arguments.size();}
  bool hasArg(const char* key) {for(auto &a:arguments)if(a.first==key)return true;return false;}
  String arg(const char* key) {for(auto &a:arguments)if(a.first==key)return a.second;return "";}
  void enableDelay(bool) {}
  void collectHeaders(const char**,int) {}
  template<class F> void on(const char*,int,F) {}
  template<class F> void onNotFound(F) {}
  void begin() {}
  void stop() {}
  void handleClient() {}
};
