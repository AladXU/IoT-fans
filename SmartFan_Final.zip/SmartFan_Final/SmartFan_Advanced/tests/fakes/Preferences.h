#pragma once
#include <map>
#include <string>
#include <vector>
#include <cstring>
struct Preferences {
  static bool openOk,writeOk,readOk;
  static std::map<std::string,std::vector<unsigned char>> records;
  bool begin(const char*,bool=false){return openOk;}
  void end(){}
  size_t getBytesLength(const char* key){return records.count(key)?records[key].size():0;}
  size_t getBytes(const char* key,void *out,size_t n){if(!readOk||!records.count(key))return 0;auto &r=records[key];size_t size=r.size()<n?r.size():n;memcpy(out,r.data(),size);return size;}
  size_t putBytes(const char* key,const void* bytes,size_t n){if(!writeOk)return 0;auto *p=static_cast<const unsigned char*>(bytes);records[key]={p,p+n};return n;}
};
inline bool Preferences::openOk=true;
inline bool Preferences::writeOk=true;
inline bool Preferences::readOk=true;
inline std::map<std::string,std::vector<unsigned char>> Preferences::records;
