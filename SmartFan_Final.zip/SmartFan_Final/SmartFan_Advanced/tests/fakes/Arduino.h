#pragma once
#include <cstdint>
#include <cstddef>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <string>
#include <cstdarg>
extern uint32_t fakeNow;
inline uint32_t millis() { return fakeNow; }
inline void delay(uint32_t ms) { fakeNow += ms; }
inline int analogRead(uint8_t) { return 0; }
using portMUX_TYPE = int;
#define portMUX_INITIALIZER_UNLOCKED 0
#define portENTER_CRITICAL(x) ((void)(x))
#define portEXIT_CRITICAL(x) ((void)(x))
struct FakeSerial {
  void println(const char *) {}
  template<typename T> void println(const T &) {}
  void print(const char *) {}
  void printf(const char *, ...) {}
};
extern FakeSerial Serial;
constexpr int LOW=0, HIGH=1, INPUT_PULLUP=2;
void pinMode(uint8_t,int);
int digitalRead(uint8_t);
