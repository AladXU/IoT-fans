#pragma once
#include "Arduino.h"
struct IPAddress {
  uint8_t b[4];
  IPAddress(uint8_t a=0,uint8_t c=0,uint8_t d=0,uint8_t e=0):b{a,c,d,e}{}
  uint8_t operator[](int i)const{return b[i];}
  bool operator==(const IPAddress&o)const{return memcmp(b,o.b,4)==0;}
};
constexpr int WIFI_STA=1,WIFI_AP_STA=3,WL_CONNECTED=3;
struct FakeWiFi {
  bool radioOk=true,apOk=true,ap=false,disconnectApOk=true;
  int statusValue=0,beginCount=0,modeValue=0,stopApCount=0;
  IPAddress address;
  void persistent(bool){}
  bool mode(int m){modeValue=m;return radioOk;}
  bool softAPConfig(IPAddress,IPAddress,IPAddress){return apOk;}
  bool softAP(const char*,const char*,int,int,int){ap=apOk;return ap;}
  bool softAPdisconnect(bool){++stopApCount;if(disconnectApOk)ap=false;return disconnectApOk;}
  void setAutoReconnect(bool){}
  void begin(const char*,const char*){++beginCount;}
  IPAddress localIP(){return address;}
  int status(){return statusValue;}
  void disconnectAsync(bool,bool){statusValue=0;address=IPAddress();}
};
extern FakeWiFi WiFi;
struct FakeESP {int restarts=0;uint64_t getEfuseMac(){return 0x112233aabbcc;}void restart(){++restarts;}};
extern FakeESP ESP;
