#pragma once
#include "WiFi.h"
struct DNSServer {
  bool startOk=true,running=false;int stops=0;
  void setTTL(int){}
  bool start(int,const char*,IPAddress){running=startOk;return running;}
  void stop(){running=false;++stops;}
  void processNextRequest(){}
};
