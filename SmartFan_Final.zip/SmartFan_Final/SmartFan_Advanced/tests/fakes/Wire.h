#pragma once
#include <cstdint>
#include <cstddef>
#include <vector>
class TwoWire {
 public:
  bool present = true;
  bool corrupt = false;
  bool shortRead = false;
  uint16_t rawT = 26214; // 25 C
  uint16_t rawH = 32768; // approximately 50 %RH
  unsigned sampleRequests = 0;
  uint8_t address = 0;
  size_t cursor = 0;
  std::vector<uint8_t> command, bytes;
  void beginTransmission(uint8_t addr) { address = addr; command.clear(); }
  size_t write(uint8_t b) { command.push_back(b); return 1; }
  uint8_t endTransmission() { return present ? 0 : 2; }
  static uint8_t crc(uint8_t a, uint8_t b) {
    uint8_t r = 255;
    for (uint8_t v : {a,b}) {
      r ^= v;
      for (int i=0;i<8;i++) r = r & 128 ? (r<<1)^0x31 : r<<1;
    }
    return r;
  }
  size_t requestFrom(uint8_t, uint8_t) {
    ++sampleRequests; cursor = 0;
    uint8_t a=rawT>>8,b=rawT&255,c=rawH>>8,d=rawH&255;
    bytes={a,b,crc(a,b),c,d,crc(c,d)};
    if (corrupt) bytes[5] ^= 1;
    if (shortRead) bytes.resize(4);
    if (!present) bytes.clear();
    return bytes.size();
  }
  int available() { return bytes.size()-cursor; }
  int read() { return bytes.at(cursor++); }
};
extern TwoWire Wire;
