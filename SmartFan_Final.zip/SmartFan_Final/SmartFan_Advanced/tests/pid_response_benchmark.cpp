#include <cmath>
#include <iostream>
#include <vector>
#include "RpmPid.h"
float speedAt(int duty,float scale){
 const float r[]={780,870,2040,3300,4440};
 int i=duty==100?3:duty/25;
 return (r[i]+(r[i+1]-r[i])*(duty-25*i)/25)*scale;
}
int main(){
 std::cout<<"kp="<<PID_KP<<" ki="<<PID_KI<<"\n";
 for(float tau:{.5f,1.5f,3.f})for(float scale:{.9f,1.f,1.1f}){
  RpmPid pid;int duty=50;float speed=speedAt(duty,scale);uint32_t at=0;pid.seed(2500,speed,duty,at);
  auto advance=[&](int target){float avg=0;for(int j=0;j<50;++j){speed+=(speedAt(duty,scale)-speed)*(1-std::exp(-.02f/tau));avg+=speed/50;}at+=1000;duty=pid.step(target,std::round(avg/30)*30,duty,at);return speed;};
  for(int s=0;s<120;++s)advance(2500);
  int worst=0;float overshoot=0;
  for(int target:{3500,1500}){
   float initial=speed;pid.seed(target,speed,duty,at);std::vector<float> samples;
   for(int s=0;s<90;++s){float r=advance(target);samples.push_back(r);overshoot=std::max(overshoot,initial<target?r-target:target-r);}
   int settled=90;for(int s=89;s>=0;--s){if(std::fabs(samples[s]-target)>120)break;settled=s+1;}worst=std::max(worst,settled);
  }
  std::cout<<"tau="<<tau<<" scale="<<scale<<" settle120="<<worst<<" overshoot="<<overshoot<<"\n";
 }
}
