#include <cassert>
#include <cmath>
#include <cstring>
#include <iostream>
#include "Arduino.h"
#include "EnvironmentReading.h"
uint32_t fakeNow=1000,lastSample=1000;
FakeSerial Serial;
int fanDuty=50,applyCalls=0;
float currentRpm=2040;
bool pwmReady=true,rpmValid=true,applyOk=true;
uint8_t oledPage=0;
EnvironmentReading readEnvironmentSnapshot(){return {};}
bool applyDuty(int duty){++applyCalls;if(!applyOk || !pwmReady || duty<0 || duty>100)return false;fanDuty=duty;return true;}
#include "TemperatureControl.h"
#include "NetworkConfig.h"
#include "NetworkState.h"
NetworkSnapshot readNetworkSnapshot(){return {};}
bool queueProfilePersistence(const TemperatureProfile &,uint32_t){return true;}
bool queueNetworkConfiguration(const NetworkConfig &){return true;}
#include "WebDashboard.h"
void feedback(float rpm){fakeNow+=1000;lastSample=fakeNow;currentRpm=rpm;rpmValid=true;serviceRpmControl();}
float plantSpeed(int duty){
  const float d[]={0,25,50,75,100},r[]={780,870,2040,3300,4440};
  for(int i=0;i<4;++i)if(duty<=d[i+1])return r[i]+(r[i+1]-r[i])*(duty-d[i])/25;
  return r[4];
}
void modelCheck(float tau,float scale){
  // Explicit software-only plant. It is NOT a substitute for physical tuning.
  RpmPid pid;int duty=50;float speed=plantSpeed(duty)*scale;
  uint32_t at=0;pid.seed(2500,speed,duty,at);
  for(int second=0;second<180;++second){
    const int target=second<60?2500:second<120?3500:1500;
    if(second==60 || second==120)pid.seed(target,speed,duty,at);
    float average=0;
    for(int i=0;i<50;++i){speed+=(plantSpeed(duty)*scale-speed)*(1-std::exp(-.02f/tau));average+=speed/50;}
    at+=1000;const int previous=duty;duty=pid.step(target,std::round(average/30)*30,duty,at);
    assert(duty>=0 && duty<=100 && std::abs(duty-previous)<=10);
    // This transient bound catches the formerly slow setpoint response, not just eventual settling.
    if(second%60>=30)assert(std::fabs(speed-target)<120);
    if(second>=60 && second<120)assert(speed<3650);
    if(second>=120)assert(speed>1350);
  }
}
int main(){
  int parsed=17;
  for(const char *text:{"","-1","+2","2.5","1e3","20001","999999999"," 2500","2500x"})assert(!parseRequestedRpm(text,strlen(text),parsed)&&parsed==17);
  assert(!parseRequestedRpm("2\0",2,parsed));
  assert(parseRequestedRpm("0",1,parsed)&&parsed==0);
  assert(parseRequestedRpm("20000",5,parsed)&&parsed==20000);
  RpmPid pure;pure.seed(20000,4440,50,0);int output=50;
  for(uint32_t i=1;i<=600;++i){int old=output;output=pure.step(20000,4440,output,i*1000);assert(output>=0&&output<=100&&std::abs(output-old)<=10);}
  assert(output==100 && std::fabs(pure.integral)<110); // No growth after ten minutes at saturation.
  pure.seed(2500,4440,output,600000);output=pure.step(2500,4440,output,601000);assert(output<100);
  pure.seed(0,780,output,601000);
  for(uint32_t i=1;i<=300;++i)output=pure.step(0,780,output,601000+i*1000);
  assert(output==0 && std::fabs(pure.integral)<10);
  pure.seed(2500,780,output,901000);assert(pure.step(2500,780,output,902000)>0);
  RpmPid rollover;rollover.seed(2500,2000,50,0xffffff00u);assert(rollover.step(2500,2000,50,744)>50);
  RpmPid invalid=rollover;assert(invalid.step(2500,NAN,50,1744)==50);
  assert(invalid.steppedAt==rollover.steppedAt);
  // The quiet band holds actual output without rewriting measured RPM.
  RpmPid quiet;quiet.seed(4000,3990,84,0);
  uint32_t quietAt=0;
  for(float rpm:{3990.f,4020.f,3960.f,4020.f,3990.f}) {
    assert(quiet.step(4000,rpm,84,quietAt+=1000)==84 && quiet.holding);
  }
  int nearDuty=84;
  for(float rpm:{3930.f,4110.f,3900.f,4080.f}) {
    int before=nearDuty;nearDuty=quiet.step(4000,rpm,nearDuty,quietAt+=1000);
    assert(!quiet.holding && std::abs(nearDuty-before)<=1);
  }
  int beforeDisturbance=nearDuty;
  for(int i=0;i<15;++i)nearDuty=quiet.step(4000,3600,nearDuty,quietAt+=1000);
  assert(nearDuty>beforeDisturbance); // Repeated real errors outside the band still drive control.
  for(float tau:{.5f,1.5f,3.0f})for(float scale:{.9f,1.0f,1.1f})modelCheck(tau,scale);
  assert(setRequestedRpm(2500)&&fanMode==FanMode::Pid&&fanDuty==50);
  feedback(2000);assert(fanDuty>50&&fanDuty<=60);
  const auto saved=rpmPid;int calls=applyCalls;
  for(int i=0;i<200;++i)serviceRpmControl();
  assert(rpmPid.integral==saved.integral&&applyCalls==calls);
  applyOk=false;const int oldDuty=fanDuty;feedback(1500);
  assert(pidOutputFailed&&fanDuty==oldDuty&&rpmPid.integral==saved.integral);
  applyOk=true;feedback(1500);assert(!pidOutputFailed&&fanDuty>=oldDuty);
  fakeNow+=PID_FEEDBACK_STALE_MS;serviceRpmControl();assert(pidFeedbackFault&&fanDuty==100);
  feedback(4400);assert(!pidFeedbackFault&&fanDuty==100);
  feedback(4400);assert(fanDuty<100);
  assert(setRequestedRpm(2500));
  feedback(0);feedback(0);assert(!pidFeedbackFault);feedback(0);assert(pidFeedbackFault&&fanDuty==100);
  feedback(4400);assert(!pidFeedbackFault);
  assert(applyManualDuty(24)&&fanMode==FanMode::Manual&&!pidFeedbackFault);
  feedback(1000);assert(fanDuty==24);
  selectFanMode(FanMode::Automatic);assert(fanMode==FanMode::Automatic&&temperatureFallback);
  setRequestedRpm(3000);assert(fanMode==FanMode::Pid&&!temperatureFallback);
  assert(!setRequestedRpm(20001)&&requestedRpm==3000);
  // Execute production HTTP/queue and status, rather than testing another parser implementation.
  webDutyQueue=xQueueCreate(4,sizeof(WebCommand));publishDashboardSnapshot();
  for(const char *text:{"-1","2500.5","1e3","20001","abc"}){
    dashboardServer.arguments={{"rpm",text}};receiveRequestedRpm();assert(dashboardServer.code==400&&requestedRpm==3000);
  }
  dashboardServer.arguments={{"rpm","2500"},{"rpm","3500"}};receiveRequestedRpm();assert(dashboardServer.code==400);
  dashboardServer.arguments={{"rpm","2500"}};dashboardServer.controlHeader="";receiveRequestedRpm();assert(dashboardServer.code==403);
  dashboardServer.controlHeader="1";receiveRequestedRpm();assert(dashboardServer.code==202&&requestedRpm==3000);
  processDashboardCommands();assert(requestedRpm==2500&&fanMode==FanMode::Pid);
  dashboardServer.arguments={{"mode","manual"}};receiveFanMode();processDashboardCommands();assert(fanMode==FanMode::Manual);
  dashboardServer.arguments={{"mode","pid"}};receiveFanMode();assert(dashboardServer.code==202);processDashboardCommands();assert(fanMode==FanMode::Pid);
  for(int i=0;i<4;++i){receiveFanMode();assert(dashboardServer.code==202);}receiveFanMode();assert(dashboardServer.code==503);
  for(int i=0;i<4;++i)processDashboardCommands();
  publishDashboardSnapshot();sendDashboardStatus();
  assert(dashboardServer.payload.find("\"mode\":\"pid\"")!=std::string::npos);
  assert(dashboardServer.payload.find("\"targetRpm\":2500")!=std::string::npos);
  assert(dashboardServer.payload.substr(dashboardServer.payload.size()-2)=="}}");
  fakeNow+=PID_FEEDBACK_STALE_MS;serviceRpmControl();publishDashboardSnapshot();sendDashboardStatus();
  assert(dashboardServer.payload.find("\"rpm\":null")!=std::string::npos);
  assert(dashboardServer.payload.find("\"feedbackFault\":true")!=std::string::npos);
  // Production status preserves the raw measurement when the controller is holding.
  fakeNow+=1000;lastSample=fakeNow;currentRpm=3990;rpmValid=true;fanDuty=84;
  setRequestedRpm(4000);feedback(4020);assert(rpmPid.holding);
  publishDashboardSnapshot();sendDashboardStatus();
  assert(dashboardServer.payload.find("\"rpm\":4020")!=std::string::npos);
  assert(dashboardServer.payload.find("\"status\":\"holding\"")!=std::string::npos);
  assert(dashboardServer.payload.find("\"holdBandRpm\":45")!=std::string::npos);
  vQueueDelete(webDutyQueue);
  std::cout<<"PASS: real PID bounds/slew/anti-windup/reversal, rollover, software plant models, fresh-only scheduling, PWM failure, RPM fault/recovery, mode exclusivity and production HTTP validation/queue/status\n";
}
