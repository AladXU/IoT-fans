import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
const html=fs.readFileSync(new URL('../DashboardPage.h',import.meta.url),'utf8');
const js=html.match(/<script>([\s\S]*?)<\/script>/)[1];
const elements=new Map();
const element=id=>{
  if(!elements.has(id)) elements.set(id,{textContent:'',value:'',dataset:{},style:{},disabled:false,events:{},addEventListener(t,f){this.events[t]=f;}});
  return elements.get(id);
};
let clock=0, handler, requests=0, active=0, maxActive=0;
const valid={mode:'manual',duty:50,rpm:2040,wifi:true,temperatureC:25.25,humidityPercent:61.5,sensorStatus:'ok',sensorAgeMs:100,sensorStaleAfterMs:5000};
handler=async()=>({ok:true,json:async()=>valid});
const context=vm.createContext({console,AbortController,Date,location:{hostname:'10.0.0.7'},performance:{now:()=>clock},
  setTimeout:()=>1,clearTimeout:()=>{},setInterval:()=>1,
  document:{getElementById:element,addEventListener:()=>{}},
  fetch:async(...args)=>{requests++;active++;maxActive=Math.max(maxActive,active);try{return await handler(...args);}finally{active--;}}
});
vm.runInContext(js,context);
const flush=()=>new Promise(resolve=>setImmediate(resolve));
await flush();
assert.equal(element('temperature').textContent,'25.3');
assert.equal(element('humidity').textContent,'61.5');
for(const status of ['missing','read_error','unavailable','starting','stale']) {
  context.showReadings({...valid,sensorStatus:status,temperatureC:null,humidityPercent:null});
  assert.equal(element('temperature').textContent,'--');assert.equal(element('humidity').textContent,'--');
  assert.equal(element('sensor-state').dataset.error,'true');
}
context.showReadings({...valid,sensorAgeMs:5000});assert.equal(element('temperature').textContent,'--');
context.showReadings(valid);clock=4900;context.expireEnvironment();assert.equal(element('temperature').textContent,'--');
context.showReadings(valid);context.showOffline();assert.equal(element('temperature').textContent,'--');
context.showReadings(valid);assert.equal(element('sensor-state').dataset.error,'false');
const before=requests;element('requested').value='101';element('control').events.submit({preventDefault(){}});
assert.equal(requests,before);assert.equal(element('message').dataset.error,'true');
let resolveRequest;handler=()=>new Promise(resolve=>resolveRequest=resolve);
const pending=context.poll();await flush();
await context.poll();assert.equal(active,1);
element('requested').value='24';element('control').events.submit({preventDefault(){}});
assert.equal(active,1);assert.equal(element('apply').disabled,true);
resolveRequest({ok:true,json:async()=>valid});await pending;
const paths=[];handler=async(path,options)=>{paths.push(path);if(path==='/api/duty'){assert.equal(options.body,'duty=24');return {ok:true,json:async()=>({requestedDuty:24})};}return {ok:true,json:async()=>({...valid,duty:24})};};
await context.poll();assert.deepEqual(paths,['/api/duty','/api/status']);
assert.equal(element('duty').textContent,24);assert.equal(element('apply').disabled,false);assert.equal(maxActive,1);
console.log('PASS: dashboard live/fault/stale/offline/recovery, invalid input and serialized requests');
// Test real profile editor and mode requests through the same non-overlapping pump.
context.showReadings({...valid,mode:'automatic',fallback:false,calculatedDuty:38,profileRevision:1,profile:{temperatures:[26,28,30],duties:[25,50,100]}});
assert.match(element('mode-state').textContent,/Automatic/);
assert.match(element('auto-state').textContent,/38%/);
assert.equal(element('t1').value,26);
element('t1').value='27';
context.showReadings({...valid,mode:'automatic',fallback:true,calculatedDuty:100,profileRevision:1,profile:{temperatures:[26,28,30],duties:[25,50,100]}});
assert.equal(element('t1').value,'27'); // Polling must not overwrite edits.
assert.equal(element('auto-state').dataset.error,'true');
const callProfile=()=>element('profile-control').events.submit({preventDefault(){}});
for(const [t,d] of [ [['26','26','30'],['25','50','100']], [['26','28','30'],['50','25','100']], [['26','28','30'],['25','50','101']], [['26','28','NaN'],['25','50','100']] ]) {
  for(let i=0;i<3;i++){element('t'+(i+1)).value=t[i];element('d'+(i+1)).value=d[i];}
  const count=requests;callProfile();assert.equal(requests,count);assert.equal(element('config-message').dataset.error,'true');
}
for(let i=1;i<=3;i++){element('t'+i).value=String(24+2*i);element('d'+i).value=String([25,50,100][i-1]);}
const configPaths=[];
handler=async(path,options)=>{
  configPaths.push(path);
  if(path==='/api/profile'){assert.match(options.body,/t1=26/);assert.match(options.body,/d3=100/);return {ok:true,json:async()=>({queued:true})};}
  return {ok:true,json:async()=>({...valid,mode:'manual'})};
};
callProfile();assert.equal(element('save-profile').disabled,true);await context.poll();
assert.deepEqual(configPaths,['/api/profile','/api/status']);assert.equal(element('save-profile').disabled,false);
handler=async(path,options)=>{
  if(path==='/api/mode'){assert.equal(options.body,'mode=automatic');return {ok:true,json:async()=>({queued:true})};}
  return {ok:true,json:async()=>({...valid,mode:'automatic',fallback:false,calculatedDuty:50})};
};
element('auto-mode').events.click();await context.poll();assert.match(element('mode-state').textContent,/Automatic/);
handler=async()=>({ok:false,json:async()=>({error:'busy'})});
element('manual-mode').events.click();await context.poll();assert.equal(element('manual-mode').disabled,false);assert.equal(element('config-message').dataset.error,'true');
assert.match(element('mode-state').textContent,/unconfirmed/);assert.equal(maxActive,1);
console.log('PASS: atomic profile form validation, edit preservation, actual mode confirmation, fault output, queue failures and shared request pump');

context.showReadings({...valid,stationIp:'10.157.215.137',setupApActive:false});
assert.match(element('network-result').textContent,/Wi-Fi connected/);assert.match(element('network-result').textContent,/10.157.215.137/);
assert.match(element('network-result').textContent,/hotspot closed/);
context.showOffline();assert.match(element('network-result').textContent,/unconfirmed/);
console.log('PASS: dashboard confirms actual Wi-Fi/IP and clears success on loss');

// Mode-specific controls follow confirmed device state, including external changes.
context.showReadings({...valid,mode:'manual'});
assert.equal(element('manual-pane').hidden,false);
assert.equal(element('automatic-pane').hidden,true);
assert.equal(element('mode-waiting').hidden,true);
assert.equal(element('control-pane-title').textContent,'Manual duty');
const draft=element('t1').value;
handler=async(path)=>({ok:true,json:async()=>path==='/api/mode'?{queued:true}:{...valid,mode:'manual'}});
element('auto-mode').events.click();
assert.equal(element('manual-pane').hidden,false); // A click is not confirmation.
await context.poll();
assert.equal(element('manual-pane').hidden,false); // Nor is a queued POST acknowledgement.
context.showReadings({...valid,mode:'automatic',calculatedDuty:50,fallback:false});
assert.equal(element('manual-pane').hidden,true);
assert.equal(element('automatic-pane').hidden,false);
assert.equal(element('control-pane-title').textContent,'Automatic temperature');
assert.equal(element('t1').value,draft); // Hidden editors retain unsaved inputs.
context.showReadings({...valid,mode:'automatic',fallback:true,calculatedDuty:100});
assert.equal(element('automatic-pane').hidden,false);
assert.equal(element('auto-state').dataset.error,'true');
context.showReadings({...valid,mode:'manual',duty:24}); // Serial / physical button takeover.
assert.equal(element('manual-pane').hidden,false);
assert.equal(element('automatic-pane').hidden,true);
context.showOffline();
assert.equal(element('manual-pane').hidden,true);
assert.equal(element('automatic-pane').hidden,true);
assert.equal(element('mode-waiting').hidden,false);
context.showReadings({...valid,mode:'automatic',calculatedDuty:50,fallback:false});
assert.equal(element('automatic-pane').hidden,false);
assert.equal(element('mode-waiting').hidden,true);
console.log('PASS: confirmed manual/automatic panels, queued requests, edit preservation, external takeover, fault and reconnect');

const pidData={targetRpm:2500,status:'tracking',intervalMs:1000,staleAfterMs:2500,kp:.006,ki:.002,kd:.001,slewPercentPerSecond:10,nearKp:.004,nearKi:.0015,nearErrorRpm:150,farErrorRpm:600,nearSlewPercentPerSecond:1,holdBandRpm:45};
context.showReadings({...valid,mode:'pid',pid:pidData});
assert.equal(element('pid-pane').hidden,false);
assert.equal(element('manual-pane').hidden,true);
assert.equal(element('automatic-pane').hidden,true);
assert.equal(element('pid-mode').dataset.active,'true');
assert.equal(element('pid-target').textContent,2500);
assert.equal(element('requested-rpm').value,2500);
element('requested-rpm').value='3500';context.showReadings({...valid,mode:'pid',pid:pidData});
assert.equal(element('requested-rpm').value,'3500');
for(const text of ['','-1','1.5','1e3','20001','999999']){
  const before=requests;element('requested-rpm').value=text;
  element('rpm-control').events.submit({preventDefault(){}});
  assert.equal(requests,before);assert.equal(element('config-message').dataset.error,'true');
}
const pidPaths=[];
context.showReadings({...valid,mode:'manual',pid:pidData});
handler=async(path,options)=>{
  pidPaths.push(path);
  if(path==='/api/rpm'){assert.equal(options.body,'rpm=3500');return {ok:true,json:async()=>({queued:true})};}
  return {ok:true,json:async()=>({...valid,mode:'manual',pid:pidData})};
};
element('requested-rpm').value='3500';element('rpm-control').events.submit({preventDefault(){}});
assert.equal(element('manual-pane').hidden,false);assert.equal(element('apply-rpm').disabled,true);
await context.poll();assert.deepEqual(pidPaths,['/api/rpm','/api/status']);
assert.equal(element('manual-pane').hidden,false);assert.equal(element('pid-target').textContent,2500);
assert.equal(element('apply-rpm').disabled,false);
context.showReadings({...valid,mode:'pid',pid:{...pidData,targetRpm:3500}});
assert.equal(element('pid-target').textContent,3500);
for(const status of ['limited_high','limited_low','holding','feedback_fault','output_error']){
  context.showReadings({...valid,mode:'pid',pid:{...pidData,status}});
  assert.equal(element('pid-pane').hidden,false);
  assert.equal(element('pid-state').dataset.error,String(status==='feedback_fault'||status==='output_error'));
}
context.showReadings({...valid,mode:'manual',pid:pidData});assert.equal(element('pid-pane').hidden,true);
handler=async(path,options)=>{
  if(path==='/api/mode'){assert.equal(options.body,'mode=pid');return {ok:true,json:async()=>({queued:true})};}
  return {ok:true,json:async()=>({...valid,mode:'pid',pid:pidData})};
};
element('pid-mode').events.click();await context.poll();assert.equal(element('pid-pane').hidden,false);
context.showOffline();assert.equal(element('pid-pane').hidden,true);assert.equal(element('pid-mode').dataset.active,'false');
context.showReadings({...valid,mode:'pid',pid:pidData});assert.equal(element('pid-pane').hidden,false);
console.log('PASS: PID panel/strict target validation, serialized RPM commands, device-confirmed mode/target, edit retention, saturation/fault and offline recovery');

context.showReadings({...valid,mode:'pid',rpm:4020,pid:{...pidData,targetRpm:4000,status:'holding'}});
assert.equal(element('rpm').textContent,4020);
assert.match(element('pid-state').textContent,/45 RPM/);
assert.match(element('pid-settings').textContent,/0.0015/);
console.log('PASS: hold tolerance is disclosed and raw RPM remains visible');
