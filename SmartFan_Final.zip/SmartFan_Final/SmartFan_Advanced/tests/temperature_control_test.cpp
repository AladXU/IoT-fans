#include <cassert>
#include <iostream>
#include <cstring>
#include "Arduino.h"
#include "EnvironmentReading.h"
uint32_t fakeNow=1000,lastSample=1000;
FakeSerial Serial;
int fanDuty=50;
float currentRpm=2040;
bool pwmReady=true,rpmValid=true,applyOk=true;
uint8_t oledPage=0;
enum class WifiPhase {Disabled,Connecting,Connected,Backoff};
WifiPhase wifiPhase=WifiPhase::Connected;
uint8_t stationIp[4]={10,0,0,2};
EnvironmentReading sensor;
EnvironmentReading readEnvironmentSnapshot(){return sensor;}
bool applyDuty(int duty){if(!applyOk || !pwmReady || duty<0 || duty>100)return false;fanDuty=duty;return true;}
#include "TemperatureControl.h"
#include "NetworkConfig.h"
#include "NetworkState.h"
NetworkSnapshot readNetworkSnapshot(){NetworkSnapshot n;n.online=true;n.phase=NetworkPhase::Online;return n;}
bool queueProfilePersistence(const TemperatureProfile &,uint32_t){return true;}
bool queueNetworkConfiguration(const NetworkConfig &){return true;}
#include "WebDashboard.h"
void sample(float t) {sensor.temperature=t;sensor.humidity=50;sensor.hasSample=true;sensor.status=EnvironmentStatus::Ready;sensor.sampledAt=fakeNow;}
int main(){
  TemperatureProfile p={{26,28,30},{25,50,100}};assert(validTemperatureProfile(p));
  assert(temperatureDuty(p,0)==25 && temperatureDuty(p,26)==25);
  assert(temperatureDuty(p,27)==38 && temperatureDuty(p,28)==50 && temperatureDuty(p,29)==75);
  assert(temperatureDuty(p,30)==100 && temperatureDuty(p,100)==100);
  int previous=-1;for(int i=2000;i<=3500;++i){int d=temperatureDuty(p,i/100.0f);assert(d>=previous && d>=25 && d<=100);previous=d;}
  auto invalid=p;invalid.temperature[1]=26;assert(!setTemperatureProfile(invalid));assert(profileRevision==0);
  invalid=p;invalid.duty[1]=24;assert(!validTemperatureProfile(invalid));
  invalid=p;invalid.duty[2]=101;assert(!validTemperatureProfile(invalid));
  invalid=p;invalid.temperature[2]=INFINITY;assert(!validTemperatureProfile(invalid));
  float out=99;for(const char *text:{"","nan","inf","28abc","2e1"," 28","+28","--1","125.1","-40.1","."})assert(!parseTemperature(text,strlen(text),out));
  assert(parseTemperature("-40",3,out)&&out==-40);assert(parseTemperature(".5",2,out)&&out==.5f);
  assert(!parseTemperature("2\0",2,out));
  sample(29);selectFanMode(FanMode::Automatic);assert(fanDuty==75 && calculatedDuty==75 && !temperatureFallback);
  fakeNow+=5000;serviceTemperatureControl();assert(fanDuty==100 && temperatureFallback);
  sample(26);serviceTemperatureControl();assert(fanDuty==25 && !temperatureFallback);
  sensor.status=EnvironmentStatus::ReadError;serviceTemperatureControl();assert(fanDuty==100);
  sensor.status=EnvironmentStatus::Missing;serviceTemperatureControl();assert(temperatureFallback);
  sample(28);serviceTemperatureControl();assert(fanDuty==50);
  applyOk=false;sample(30);serviceTemperatureControl();assert(fanDuty==50 && automaticOutputFailed && calculatedDuty==100);
  assert(!applyManualDuty(24) && fanMode==FanMode::Automatic && fanDuty==50);
  applyOk=true;fakeNow+=250;serviceTemperatureControl();assert(fanDuty==100 && !automaticOutputFailed);
  assert(applyManualDuty(24));assert(fanMode==FanMode::Manual && fanDuty==24);sample(30);serviceTemperatureControl();assert(fanDuty==24);
  selectFanMode(FanMode::Automatic);selectFanMode(FanMode::Manual);assert(fanDuty==100 && calculatedDuty==-1);
  // Execute real HTTP handlers and main-loop command dispatcher.
  webDutyQueue=xQueueCreate(4,sizeof(WebCommand));publishDashboardSnapshot();
  dashboardServer.arguments={{"t1","26"},{"t2","28"},{"t3","30"},{"d1","20"},{"d2","50"},{"d3","90"}};
  receiveTemperatureProfile();assert(dashboardServer.code==202 && profileRevision==0);
  processDashboardCommands();assert(profileRevision==1 && activeProfile.duty[0]==20 && fanMode==FanMode::Manual);
  auto saved=activeProfile;
  dashboardServer.arguments[1].second="25";receiveTemperatureProfile();assert(dashboardServer.code==400);processDashboardCommands();assert(profileRevision==1 && activeProfile.temperature[1]==saved.temperature[1]);
  dashboardServer.arguments={{"t1","1"},{"t2","2"},{"t3","3"},{"d1","0"},{"d2","50"},{"d2","100"}};
  receiveTemperatureProfile();assert(dashboardServer.code==400 && profileRevision==1);
  dashboardServer.arguments={{"mode","automatic"}};receiveFanMode();assert(dashboardServer.code==202);processDashboardCommands();assert(fanMode==FanMode::Automatic && fanDuty==90);
  dashboardServer.arguments={{"mode","bad"}};receiveFanMode();assert(dashboardServer.code==400 && fanMode==FanMode::Automatic);
  dashboardServer.arguments={{"duty","101"}};receiveDashboardDuty();assert(dashboardServer.code==400 && fanMode==FanMode::Automatic);
  dashboardServer.arguments={{"duty","24"}};receiveDashboardDuty();assert(dashboardServer.code==202 && fanMode==FanMode::Automatic);
  processDashboardCommands();assert(fanMode==FanMode::Manual && fanDuty==24);
  dashboardServer.controlHeader="";receiveDashboardDuty();assert(dashboardServer.code==403);
  receiveTemperatureProfile();assert(dashboardServer.code==403);receiveFanMode();assert(dashboardServer.code==403);
  dashboardServer.controlHeader="1";dashboardServer.arguments={{"mode","automatic"}};
  for(int i=0;i<4;++i){receiveFanMode();assert(dashboardServer.code==202);}receiveFanMode();assert(dashboardServer.code==503);
  for(int i=0;i<4;++i)processDashboardCommands();
  publishDashboardSnapshot();sendDashboardStatus();assert(dashboardServer.payload.find("\"mode\":\"automatic\"")!=std::string::npos);
  assert(dashboardServer.payload.find("\"duties\":[20,50,90]")!=std::string::npos);
  fakeNow+=5000;serviceTemperatureControl();publishDashboardSnapshot();sendDashboardStatus();
  assert(dashboardServer.payload.find("\"fallback\":true")!=std::string::npos && dashboardServer.payload.find("\"calculatedDuty\":100")!=std::string::npos);
  vQueueDelete(webDutyQueue);
  std::cout<<"PASS: profile validation/interpolation, real sensor freshness/fallback/recovery, manual override, PWM failure, HTTP validation/queue/actual status\n";
}
