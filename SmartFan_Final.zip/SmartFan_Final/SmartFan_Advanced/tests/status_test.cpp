#include <cassert>
#include <iostream>
#include "Arduino.h"
#include "EnvironmentReading.h"
uint32_t fakeNow=1000;
FakeSerial Serial;
int fanDuty=50;
uint8_t oledPage=0;
float currentRpm=2040;
bool rpmValid=true, pwmReady=true;
uint32_t lastSample=1000;
enum class WifiPhase { Disabled, Connecting, Connected, Backoff };
WifiPhase wifiPhase=WifiPhase::Connected;
uint8_t stationIp[4]={10,0,0,2};
EnvironmentReading testReading;
EnvironmentReading readEnvironmentSnapshot() {return testReading;}
bool applyDuty(int d) {fanDuty=d;return true;}
#include "TemperatureControl.h"
#include "NetworkConfig.h"
#include "NetworkState.h"
NetworkSnapshot readNetworkSnapshot(){NetworkSnapshot n;n.online=true;n.phase=NetworkPhase::Online;return n;}
bool queueProfilePersistence(const TemperatureProfile &,uint32_t){return true;}
bool queueNetworkConfiguration(const NetworkConfig &){return true;}
#include "WebDashboard.h"
void contains(const char* value) {assert(dashboardServer.payload.find(value)!=std::string::npos);}
int main() {
  publishDashboardSnapshot();sendDashboardStatus();
  contains("\"sensorStatus\":\"starting\"");contains("\"temperatureC\":null");contains("\"sensorAgeMs\":null");
  testReading.temperature=25.25;testReading.humidity=61.5;testReading.sampledAt=900;
  testReading.hasSample=true;testReading.status=EnvironmentStatus::Ready;
  publishDashboardSnapshot();sendDashboardStatus();
  contains("\"temperatureC\":25.25");contains("\"humidityPercent\":61.50");contains("\"sensorAgeMs\":100");
  contains("\"duty\":50");contains("\"rpm\":2040");
  for (auto status:{EnvironmentStatus::Missing,EnvironmentStatus::ReadError,EnvironmentStatus::Unavailable}) {
    testReading.status=status; publishDashboardSnapshot(); sendDashboardStatus();
    contains("\"temperatureC\":null");contains("\"humidityPercent\":null");
    assert(dashboardServer.payload.find(environmentStatusCode(status))!=std::string::npos);
  }
  testReading.status=EnvironmentStatus::Ready;publishDashboardSnapshot();
  fakeNow=5899;sendDashboardStatus();contains("\"sensorStatus\":\"ok\"");
  fakeNow=5900;sendDashboardStatus();contains("\"sensorStatus\":\"stale\"");contains("\"temperatureC\":null");
  fakeNow=1000;testReading.temperature=NAN;publishDashboardSnapshot();sendDashboardStatus();
  contains("\"sensorStatus\":\"read_error\"");contains("\"temperatureC\":null");
  assert(dashboardServer.payload.find("nan")==std::string::npos);
  std::cout<<"PASS: real HTTP handler serializes valid values, null failures, age and expired snapshots\n";
}
