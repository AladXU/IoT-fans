#include <cassert>
#include <iostream>
#include "Arduino.h"
#include "WiFi.h"
#include "EnvironmentReading.h"
uint32_t fakeNow=1000;
FakeSerial Serial;FakeWiFi WiFi;FakeESP ESP;
int fanDuty=50;bool pwmReady=true,rpmValid=true;float currentRpm=2040;uint32_t lastSample=1000;uint8_t oledPage=0;
EnvironmentReading readEnvironmentSnapshot(){return {};}
bool applyDuty(int duty){fanDuty=duty;return true;}
#include "TemperatureControl.h"
#include "Provisioning.h"
#include "WebDashboard.h"
NetworkConfig config(){NetworkConfig c={};strcpy(c.ssid,"Test hotspot");strcpy(c.password,"test-key-123");strcpy(c.serverUrl,"http://hub.local:8080/path");return c;}
void resetRuntime(){networkSnapshot={};networkOwned={};stationConfig={};savedNetworkValid=false;networkConnecting=false;networkRestartPending=false;WiFi={};ESP={};setupDns={};fakeNow=1000;}
int main(){
  auto c=config();assert(validNetworkConfig(c));
  for(const char* url:{"https://example.com","http://192.168.1.10:8080/path?x=1","http://localhost",""})assert(validServerUrl(url));
  for(const char* url:{"ftp://abc","http://","http://abc:0","http://abc:65536","http://abc:","http://abc:1:2","http://-abc","http://abc-","http://abc..com","http://user@abc","http://abc/ bad","http://abc/\""})assert(!validServerUrl(url));
  char field[4];assert(!copyConfigField(field,4,"a\0b",3));assert(!copyConfigField(field,4,"abcd",4));assert(copyConfigField(field,4,"abc",3));
  NetworkConfig invalid=c;strcpy(invalid.password,"short");assert(!validNetworkConfig(invalid));
  invalid=c;memset(invalid.ssid,'x',sizeof(invalid.ssid));assert(!validNetworkConfig(invalid));
  NetworkConfig loaded={};assert(!loadNetworkConfig(loaded));assert(storeNetworkConfig(c));assert(loadNetworkConfig(loaded));assert(strcmp(loaded.ssid,c.ssid)==0);
  auto intact=Preferences::records["network"];
  Preferences::records["network"][10]^=1;assert(!loadNetworkConfig(loaded));Preferences::records["network"]=intact;
  Preferences::writeOk=false;assert(!storeNetworkConfig(c));Preferences::writeOk=true;
  Preferences::readOk=false;assert(!storeNetworkConfig(c));Preferences::readOk=true;
  TemperatureProfile p={{26,28,30},{30,50,100}},restored={};assert(storeTemperatureProfile(p));assert(loadStoredProfile(restored)&&restored.duty[0]==30);
  Preferences::records["profile"].resize(4);assert(!loadStoredProfile(restored));
  storeTemperatureProfile(p);restoreProfileAtBoot();assert(activeProfile.duty[0]==30 && fanMode==FanMode::Manual && readNetworkSnapshot().profileSave==ProfileSaveState::Saved);
  // Empty NVS starts open AP immediately; captive DNS failures are explicit.
  Preferences::records.clear();resetRuntime();networkRequestQueue=xQueueCreate(4,sizeof(NetworkRequest));
  initializeNetwork();auto s=readNetworkSnapshot();assert(s.apActive && s.dnsReady && !s.online && WiFi.beginCount==0);
  assert(std::string(s.setupSsid)=="SmartFan-Setup-AABBCC");
  assert(queueNetworkConfiguration(c));assert(!queueNetworkConfiguration(c));
  processNetworkRequest();assert(readNetworkSnapshot().networkSave==NetworkSaveState::SavedRestart && ESP.restarts==0);
  fakeNow+=1999;serviceProvisioning();assert(ESP.restarts==0);++fakeNow;serviceProvisioning();assert(ESP.restarts==1);
  // Reboot with valid saved configuration -> attempt, timeout -> setup, retry -> success -> AP/DNS close.
  resetRuntime();initializeNetwork();assert(WiFi.beginCount==1 && !readNetworkSnapshot().apActive);
  fakeNow+=14999;serviceProvisioning();assert(!readNetworkSnapshot().apActive);
  ++fakeNow;serviceProvisioning();assert(readNetworkSnapshot().apActive && !networkConnecting);
  fakeNow+=30000;serviceProvisioning();assert(networkConnecting && WiFi.beginCount==2 && readNetworkSnapshot().apActive);
  WiFi.statusValue=WL_CONNECTED;WiFi.address=IPAddress(10,0,0,7);serviceProvisioning();s=readNetworkSnapshot();
  assert(s.online && !s.apActive && !s.dnsReady && !WiFi.ap && !setupDns.running);
  // Loss never interferes with fan state; it eventually opens setup again.
  WiFi.statusValue=0;serviceProvisioning();assert(!readNetworkSnapshot().online && fanDuty==50);
  fakeNow+=30000;serviceProvisioning();fakeNow+=15000;serviceProvisioning();assert(readNetworkSnapshot().apActive);
  // Async curve persistence: old acknowledgements cannot hide a newer pending request.
  assert(queueProfilePersistence(p,2));p.duty[0]=35;assert(queueProfilePersistence(p,3));
  processNetworkRequest();assert(readNetworkSnapshot().profileSave==ProfileSaveState::Pending);
  processNetworkRequest();s=readNetworkSnapshot();assert(s.profileSave==ProfileSaveState::Saved&&s.profileSavedRevision==3);
  assert(loadStoredProfile(restored)&&restored.duty[0]==35);
  Preferences::writeOk=false;queueProfilePersistence(p,4);processNetworkRequest();assert(readNetworkSnapshot().profileSave==ProfileSaveState::Error);
  assert(queueNetworkConfiguration(c));processNetworkRequest();assert(readNetworkSnapshot().networkSave==NetworkSaveState::Error && !networkRestartPending);Preferences::writeOk=true;
  // Missing/corrupt storage, AP/DNS failure and timer rollover remain recoverable.
  Preferences::records.clear();resetRuntime();setupDns.startOk=false;initializeNetwork();assert(readNetworkSnapshot().apActive&&!readNetworkSnapshot().dnsReady);
  resetRuntime();WiFi.apOk=false;initializeNetwork();assert(!readNetworkSnapshot().apActive);WiFi.apOk=true;fakeNow+=30000;serviceProvisioning();assert(readNetworkSnapshot().apActive);
  storeNetworkConfig(c);resetRuntime();fakeNow=0xfffffff0u;initializeNetwork();fakeNow=14983;serviceProvisioning();assert(networkConnecting);fakeNow=14984;serviceProvisioning();assert(readNetworkSnapshot().apActive);
  // Actual setup HTTP handlers: never echo secret fields, reject duplicates, confirm queued storage.
  networkSnapshot.networkSave=NetworkSaveState::Idle;publishDashboardSnapshot();
  dashboardServer.arguments={{"ssid","Test hotspot"},{"password","test-key-123"},{"serverUrl","http://hub.local:8080/path"}};
  receiveNetworkConfiguration();assert(dashboardServer.code==202);
  assert(dashboardServer.payload.find("test-key-123")==std::string::npos);
  receiveNetworkConfiguration();assert(dashboardServer.code==503);
  sendSetupState();assert(dashboardServer.payload.find("test-key-123")==std::string::npos);
  assert(dashboardServer.payload.find("password")==std::string::npos);
  processNetworkRequest();sendSetupState();assert(dashboardServer.payload.find("saved_restart")!=std::string::npos);
  dashboardServer.arguments={{"ssid","a"},{"password","short"},{"serverUrl",""}};
  receiveNetworkConfiguration();assert(dashboardServer.code==400);
  dashboardServer.arguments={{"ssid","a"},{"password","test-key-123"},{"password","test-key-123"}};
  receiveNetworkConfiguration();assert(dashboardServer.code==400);
  dashboardServer.arguments={{"ssid","a"},{"password",std::string("abc\0defgh",9)},{"serverUrl",""}};
  receiveNetworkConfiguration();assert(dashboardServer.code==400);
  dashboardServer.controlHeader="";receiveNetworkConfiguration();assert(dashboardServer.code==403);
  redirectToSetup();assert(dashboardServer.code==302);
  vQueueDelete(networkRequestQueue);
  std::cout<<"PASS: validated versioned NVS records, corruption/write/read failure, cold restore, AP/DNS, timeout/retry/reconnect/shutdown, restart-after-save, profile acknowledgements and timer rollover\n";
}
