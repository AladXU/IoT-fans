#include <iostream>
#include <algorithm>
#include "RpmPid.h"
int main(){const int samples[]={4020,3930,3930,3990,3930,3990,4020,3960,3990,3960,4020,4110,3900,3990,4020,3960,4080,3930,3990};RpmPid p;int duty=84,low=84,high=84,changes=0,total=0;uint32_t at=0;p.seed(4000,3900,duty,at);for(int rpm:samples){int before=duty;duty=p.step(4000,rpm,duty,at+=1000);if(duty!=before)++changes;total+=std::abs(duty-before);low=std::min(low,duty);high=std::max(high,duty);}std::cout<<"fixed-input replay, NOT plant response: duty="<<low<<".."<<high<<", changes="<<changes<<", travel="<<total<<"\n";}
