#include <cassert>
#include <iostream>
#include "Arduino.h"
#include "EnvironmentMonitor.h"
uint32_t fakeNow = 100;
FakeSerial Serial;
TwoWire Wire;
int main() {
  assert(readEnvironmentSnapshot().status == EnvironmentStatus::Starting);
  Wire.present = false;
  serviceEnvironment(true);
  assert(environmentStatusAt(readEnvironmentSnapshot(),fakeNow)==EnvironmentStatus::Missing);
  assert(!readEnvironmentSnapshot().hasSample);
  Wire.present = true;
  fakeNow += 4999; serviceEnvironment(true);
  assert(Wire.sampleRequests==0);
  ++fakeNow; serviceEnvironment(true);
  auto s=readEnvironmentSnapshot();
  assert(s.hasSample && environmentStatusAt(s,fakeNow)==EnvironmentStatus::Ready);
  assert(std::abs(s.temperature-25.0f)<0.001f && std::abs(s.humidity-50.0f)<0.01f);
  assert(Wire.address==0x44 && Wire.command[0]==0x24 && Wire.command[1]==0);
  assert(Wire.sampleRequests==1); // init() samples once, no redundant read.
  fakeNow=environmentLastAttempt+1999; serviceEnvironment(true); assert(Wire.sampleRequests==1);
  ++fakeNow; serviceEnvironment(true); assert(Wire.sampleRequests==2);
  auto good=readEnvironmentSnapshot();
  Wire.corrupt=true; fakeNow=environmentLastAttempt+2000; serviceEnvironment(true);
  auto failed=readEnvironmentSnapshot();
  assert(failed.status==EnvironmentStatus::ReadError && failed.sampledAt==good.sampledAt);
  assert(environmentStatusAt(failed,fakeNow)!=EnvironmentStatus::Ready); // cached library values not valid.
  Wire.corrupt=false; fakeNow=environmentLastAttempt+5000; serviceEnvironment(true);
  assert(readEnvironmentSnapshot().status==EnvironmentStatus::Ready);
  Wire.shortRead=true; fakeNow=environmentLastAttempt+2000; serviceEnvironment(true);
  assert(readEnvironmentSnapshot().status==EnvironmentStatus::ReadError);
  Wire.shortRead=false; Wire.present=false; fakeNow=environmentLastAttempt+5000; serviceEnvironment(true);
  assert(readEnvironmentSnapshot().status==EnvironmentStatus::Missing);
  Wire.present=true; fakeNow=environmentLastAttempt+5000; serviceEnvironment(true);
  s=readEnvironmentSnapshot();
  assert(environmentStatusAt(s,s.sampledAt+4999)==EnvironmentStatus::Ready);
  assert(environmentStatusAt(s,s.sampledAt+5000)==EnvironmentStatus::Stale);
  s.sampledAt=0xfffffff0u;
  assert(environmentStatusAt(s,20)==EnvironmentStatus::Ready);
  assert(environmentStatusAt(s,(uint32_t)(s.sampledAt+5000))==EnvironmentStatus::Stale);
  assert(!environmentValuesValid(NAN,50) && !environmentValuesValid(25,INFINITY));
  assert(!environmentValuesValid(-41,50) && !environmentValuesValid(25,101));
  assert(environmentValuesValid(-40,0) && environmentValuesValid(125,100));
  s.temperature=NAN; assert(environmentStatusAt(s,20)==EnvironmentStatus::ReadError);
  setEnvironmentFailure(EnvironmentStatus::Unavailable);
  unsigned count=Wire.sampleRequests; serviceEnvironment(false);
  assert(Wire.sampleRequests==count && readEnvironmentSnapshot().status==EnvironmentStatus::Unavailable);
  // Scheduler arithmetic also works through millis() rollover.
  environmentInitialized=false; environmentAttempted=true; environmentLastAttempt=0xfffffff0u;
  fakeNow=20; serviceEnvironment(true); assert(Wire.sampleRequests==count);
  fakeNow=(uint32_t)(environmentLastAttempt+5000); serviceEnvironment(true);
  assert(Wire.sampleRequests==count+1 && readEnvironmentSnapshot().status==EnvironmentStatus::Ready);
  std::cout<<"PASS: real arduino-sht driver CRC/short-read, missing/retry/recovery, freshness, range and timer wrap\n";
}
