#include <cassert>
#include <iostream>
#include "Arduino.h"
#include "ButtonLogic.h"
uint32_t fakeNow=0;
FakeSerial Serial;
bool pwmReady=true, applySucceeds=true;
int fanDuty=50, applyCalls=0;
uint8_t oledPage=0;
int pins[40];
void pinMode(uint8_t pin,int mode) { assert(pin>=7 && pin<=10 && mode==INPUT_PULLUP); }
int digitalRead(uint8_t pin) { return pins[pin]; }
bool applyDuty(int duty) { ++applyCalls; if(!applySucceeds) return false; fanDuty=duty;return true; }
bool applyManualDuty(int duty) {return applyDuty(duty);}
#include "LocalButtons.h"
void edge(uint8_t pin,bool pressed) {
  pins[pin]=pressed?LOW:HIGH;fakeNow+=5;serviceLocalButtons();
  fakeNow+=35;serviceLocalButtons();
}
int main() {
  const ButtonRoles roles={0,1,2,3};
  ButtonController controller;bool down[4]={};controller.begin(down,0);
  down[0]=true;assert(controller.update(down,100,roles).delta==0);
  down[0]=false;controller.update(down,110,roles);
  down[0]=true;controller.update(down,120,roles);
  assert(controller.update(down,149,roles).delta==0);
  assert(controller.update(down,150,roles).delta==5);
  assert(controller.update(down,5000,roles).delta==0); // held: no repeat.
  down[0]=false;controller.update(down,5010,roles);controller.update(down,5040,roles);
  down[0]=down[2]=true;controller.update(down,5050,roles);
  auto a=controller.update(down,5080,roles);assert(a.delta==1 && a.fine && a.pressedMask==5);
  down[1]=down[3]=true;controller.update(down,5090,roles);a=controller.update(down,5120,roles);
  assert(a.delta==0 && a.directionConflict && a.page);
  // Held at boot: requires a release and subsequent fresh press.
  controller.begin(down,6000);assert(controller.update(down,7000,roles).pressedMask==0);
  for(auto &v:down)v=false;controller.update(down,7010,roles);controller.update(down,7040,roles);
  down[0]=true;controller.update(down,7050,roles);assert(controller.update(down,7080,roles).delta==5);
  // Unsigned time arithmetic handles rollover.
  for(auto &v:down)v=false;controller.begin(down,0xffffffe0u);
  down[1]=true;controller.update(down,0xfffffff0u,roles);
  assert(controller.update(down,13,roles).delta==0);
  assert(controller.update(down,14,roles).delta==-5);
  // Role remapping allows physical panel order correction without rewiring.
  for(auto &v:down)v=false;controller.begin(down,0);down[3]=true;
  controller.update(down,10,{3,2,1,0});assert(controller.update(down,40,{3,2,1,0}).delta==5);
  assert(buttonRequestedDuty(98,5)==100 && buttonRequestedDuty(2,-5)==0);
  // Execute real LocalButtons adapter, including shared fan state and apply failure.
  for(auto &p:pins)p=HIGH;
  fakeNow=100;startLocalButtons();
  edge(7,true);assert(fanDuty==55 && applyCalls==1);
  fakeNow+=1000;serviceLocalButtons();assert(applyCalls==1);
  edge(7,false);fanDuty=24;edge(7,true);assert(fanDuty==29);edge(7,false);
  edge(9,true);edge(8,true);assert(fanDuty==28);edge(8,false);
  edge(7,true);assert(fanDuty==29);edge(7,false);edge(9,false);
  fanDuty=0;edge(8,true);assert(fanDuty==0);edge(8,false);
  fanDuty=100;edge(7,true);assert(fanDuty==100);edge(7,false);
  int previousCalls=applyCalls;edge(10,true);assert(oledPage==1 && applyCalls==previousCalls);
  edge(10,false);edge(10,true);assert(oledPage==0);edge(10,false);
  applySucceeds=false;edge(8,true);assert(fanDuty==100);edge(8,false);
  pwmReady=false;previousCalls=applyCalls;edge(8,true);assert(applyCalls==previousCalls);edge(8,false);
  std::cout<<"PASS: debounce, held/startup suppression, fine combination, simultaneous keys, limits, rollover, page, shared state and apply failure\n";
}
