# Host tests

Run `python3 scripts/run_tests.py` from the release root. Select dependencies with `--node PATH --sdk PATH --sht-dir PATH`. A failed check returns a nonzero exit code. The runner does not upload firmware or operate hardware. See the [bench checklist](../../TEST_PLAN.md).


These tests use the production headers and page script, plus fakes only for hardware/RTOS/HTTP boundaries. They do not verify physical I2C wiring, RF, OLED appearance, timing on target, or RPM calibration.

From the project root (parent of SmartFan_Advanced), compile with a C++17 compiler:

```sh
clang++ -std=c++17 -I SmartFan_Advanced/tests/fakes -I SmartFan_Advanced -I "$HOME/Documents/Arduino/libraries/arduino-sht" SmartFan_Advanced/tests/environment_test.cpp "$HOME/Documents/Arduino/libraries/arduino-sht/SHTSensor.cpp" -o /tmp/smartfan-environment-test
/tmp/smartfan-environment-test
clang++ -std=c++17 -I SmartFan_Advanced/tests/fakes -I SmartFan_Advanced SmartFan_Advanced/tests/status_test.cpp -o /tmp/smartfan-status-test
/tmp/smartfan-status-test
node SmartFan_Advanced/tests/dashboard_test.mjs
```

Adjust the arduino-sht include/source path for your installation. On this Mac, clang required `-isysroot /Library/Developer/CommandLineTools/SDKs/MacOSX15.4.sdk`. The JavaScript test was executed using the available Node runtime; Node is not currently on the user's shell PATH. None of these tools is needed for ordinary Arduino uploads.

Button test: compile tests/buttons_test.cpp with the same C++17 include and SDK flags as status_test.cpp, then run the executable. Tests exercise production button logic and GPIO adapter with fake inputs and clock. The separate bench check of physical key order is recorded in [TEST_STATUS.md](../TEST_STATUS.md).

Temperature control/API test: compile tests/temperature_control_test.cpp with the same C++17/include/SDK flags and run. It executes production profile parser, controller, actual HTTP handlers and queue dispatcher. Run dashboard_test.mjs for actual page editor/mode/request tests. Host tests cannot establish physical closed-loop response or sensor-fault wiring behavior.

Provisioning tests: compile tests/provisioning_test.cpp with the same C++17/include/SDK flags and run. This executes the production NVS record handling, network state machine, persistence command processing and setup HTTP handlers with fake Preferences/WiFi/DNS/clock/queue. Run tests/setup_page_test.mjs for the actual setup page request pump. These tests cannot confirm physical Wi-Fi association, captive popups, RF stability, or power-cycle persistence on real Flash.

PID test: compile tests/rpm_control_test.cpp with the same C++17/fake include/SDK flags. It exercises the production PID, RPM service and HTTP handlers, including software-only fan models; models do not establish physical tuning or accuracy. Run dashboard_test.mjs for third-mode and RPM form tests.

Response benchmark: compile tests/pid_response_benchmark.cpp with C++17 and -I SmartFan_Advanced. Compile the same source with the pre-tuning checkpoint directory on the include path to compare the old production parameters. Timings and overshoot describe only the declared software models.

Ripple benchmark: compile tests/pid_ripple_benchmark.cpp against the production RpmPid.h, or the pre-near-target checkpoint for comparison. It replays fixed measured inputs and does not simulate a new physical fan trajectory.
