# Wi-Fi provisioning and persistent settings

The ESP32 stores settings in its built-in Preferences/NVS. Keep the existing wiring and leave **Erase All Flash Before Sketch Upload** disabled to retain compatible records. The [validation history](TEST_STATUS.md) distinguishes host tests from physical Wi-Fi and power-cycle observations.

## First setup

1. Upload SmartFan_Advanced.ino and open the serial monitor at 115200 baud. The final release prints `smartfan-advanced-pid-idle-4`. The first provisioning build used `smartfan-advanced-portal-1`.
2. The firmware reads the `smartfan` NVS namespace. Credentials from an older sketch's WiFiConfig.h are not imported. Without a valid record the device opens its setup hotspot.
3. Keep the target 2.4 GHz network available. On the computer, join the open SmartFan-Setup-XXXXXX network named on the OLED or serial monitor.
4. If the setup page does not open automatically, browse to http://192.168.4.1/setup. Stay connected even if the computer reports no internet.
5. Enter the exact SSID and password. The optional HTTP/HTTPS server URL is reserved for a future Hub and can be blank. Select **Save and restart**.
6. The page reports submission, followed by save confirmation. The network task writes and verifies the record, then restarts about two seconds later. A failed save permits another attempt without a restart. If the page disconnects early, check the OLED or serial monitor for the result.
7. Rejoin the target network on the computer and open the device IP displayed on the OLED. Check fan control, sensor readings and buttons.
8. Once connected, the ESP32 closes its setup AP and captive DNS. Refresh the computer's network list to clear cached entries.

## Reconnection and network changes

At startup, missing, incompatible, corrupt or invalid records trigger the setup AP. With a valid record the first attempt lasts 15 seconds. A wrong password, unavailable network or missing IP opens the AP for reconfiguration. Saved settings are retried about every 30 seconds while local control continues. Success closes the AP.

After an established connection drops, the device waits about 30 seconds and opens another 15-second connection window. Connecting status appears during the attempt. When setup is available, the OLED shows its SSID and address. Use **Wi-Fi settings** on the dashboard or open `/setup` at the current IP to replace all network fields, save and restart. Previously stored passwords are never sent back to the browser.

The setup form accepts a typed SSID. Wildcard DNS and HTTP probe redirects support captive portal discovery. Automatic popup behavior depends on the client, and HTTPS redirection is unreliable. Use the direct IP shown on the OLED or serial monitor if DNS fails (`dnsReady=false`). AP or network task initialization failures are reported as unavailable. AP startup retries in the background, with local control remaining available. A dedicated hardware NVS-reset button is not implemented.

## Temperature profile storage

Saving a profile applies it in RAM and queues an asynchronous NVS write on the network/storage task. Check **Active profile** and **Profile storage**.

| State | Meaning |
|---|---|
| default | The firmware is using 26/28/30°C mapped to 25/50/100%. |
| pending | The new RAM profile is active and the save is pending. |
| saved | Write and readback succeeded. The saved revision identifies the profile in this boot session. |
| error | Storage failed or the queue was full. The RAM profile remains active. Restart may restore the last successful save. |

HTTP 202 acknowledges a queued request. Acknowledgements are revision-aware, so an earlier save cannot mark a newer pending profile as saved. Wait for **saved** before power-cycling. A saved profile loads as revision 1 on a fresh boot. Revision 0 denotes defaults. Each boot starts in Manual at 50%. Temperature, humidity and RPM history are not persisted.

## Validation and record format

One versioned blob contains SSID, password and server URL. A second blob stores the profile. Length, magic, version, checksum and fields are validated. Each Preferences putBytes is followed by a readback comparison. Atomicity applies to an individual settings record.

- SSID: 1–32 bytes, no control characters. Network passwords may be empty for an open network, 8–63 bytes or a 64-digit hexadecimal PSK.
- Server URL: empty or up to 192 bytes. HTTP/HTTPS, DNS names, IPv4, localhost, optional port 1–65535 and paths are supported. IPv6 literals and embedded credentials are rejected.
- SSID and password preserve intentional spaces. The browser trims the URL. The backend rejects embedded NULs and missing, extra or duplicate fields.
- Serial output, status responses and error messages omit passwords. The stored server URL does not trigger outbound telemetry.
- A full flash erase clears NVS. Normal uploads with erase disabled retain compatible records. The distributed sketch uses the setup page in place of a private WiFiConfig.h.

## HTTP endpoints and tasks

| Request | Behavior |
|---|---|
| GET / | Setup page on an offline setup AP, otherwise the dashboard when online |
| GET /dashboard | Direct fan controls, including on the setup AP |
| GET /setup | Setup form on either network |
| GET /api/setup-state | Includes phase, online, apActive, dnsReady, setupSsid, save, hasSavedNetwork and stationIp |
| POST /api/network | Send exactly ssid, password and serverUrl as form-urlencoded with X-Fan-Control: 1. Responses are 202 queued, 400 invalid input, 403 missing header or 503 unavailable/busy. Save states are idle, pending, saved_restart and error. |
| GET /api/status | Includes profileSave and profileSavedRevision alongside control status |

Other HTTP discovery paths redirect to http://192.168.4.1/setup during setup. Unknown paths return 404 online. One network task owns Wi-Fi, DNS and runtime NVS writes. The main loop uses snapshots and queues and restores the curve before starting the tasks. A separate HTTP task handles clients and rebinds its listener. The setup page serializes requests. I2C and RGB run in dedicated tasks. Flash writes can briefly affect scheduling. Timing and pulse loss require bench measurement.

## Connection feedback

The portal-feedback-1 build added separate submission, save and Wi-Fi status. If restarting breaks the old AP connection, the page clears the previous AP state and reports the result as unconfirmed. Rejoin the target network and open the IP shown on the OLED for confirmed connection status. If the attempt times out, join the setup AP to correct the settings. **Check connection again** reads the current state without saving or restarting. Submissions and retries share one request queue.
