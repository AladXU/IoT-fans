#pragma once
#include <Preferences.h>
#include "NetworkConfig.h"

// Each configuration is a single versioned NVS blob, committed by Preferences.
// No partial set of SSID/password/url or three-point values is ever loaded.
template<typename T> bool loadConfigBlob(const char *key,uint32_t magic,T &out) {
  Preferences preferences;
  if(!preferences.begin("smartfan",true))return false;
  StoredConfig<T> record={};
  bool ok=preferences.getBytesLength(key)==sizeof(record) &&
    preferences.getBytes(key,&record,sizeof(record))==sizeof(record);
  preferences.end();
  if(!ok || record.magic!=magic || record.version!=1 || record.checksum!=configChecksum(
      reinterpret_cast<const uint8_t*>(&record),offsetof(StoredConfig<T>,checksum)))return false;
  out=record.value;return true;
}
template<typename T> bool saveConfigBlob(const char *key,uint32_t magic,const T &value) {
  StoredConfig<T> record={};record.magic=magic;record.version=1;record.value=value;
  record.checksum=configChecksum(reinterpret_cast<const uint8_t*>(&record),offsetof(StoredConfig<T>,checksum));
  Preferences preferences;if(!preferences.begin("smartfan",false))return false;
  bool ok=preferences.putBytes(key,&record,sizeof(record))==sizeof(record);
  StoredConfig<T> check={};
  ok=ok && preferences.getBytesLength(key)==sizeof(record) &&
    preferences.getBytes(key,&check,sizeof(check))==sizeof(check) && memcmp(&record,&check,sizeof(record))==0;
  preferences.end();return ok;
}
inline bool loadNetworkConfig(NetworkConfig &out) {
  NetworkConfig candidate={};
  if(!loadConfigBlob("network",NETWORK_CONFIG_MAGIC,candidate)||!validNetworkConfig(candidate))return false;
  out=candidate;return true;
}
inline bool storeNetworkConfig(const NetworkConfig &value) {
  return validNetworkConfig(value) && saveConfigBlob("network",NETWORK_CONFIG_MAGIC,value);
}
inline bool loadStoredProfile(TemperatureProfile &out) {
  TemperatureProfile candidate={};
  if(!loadConfigBlob("profile",PROFILE_CONFIG_MAGIC,candidate)||!validTemperatureProfile(candidate))return false;
  out=candidate;return true;
}
inline bool storeTemperatureProfile(const TemperatureProfile &value) {
  return validTemperatureProfile(value) && saveConfigBlob("profile",PROFILE_CONFIG_MAGIC,value);
}
