#pragma once
#include <math.h>
#include <stddef.h>
#include <stdint.h>

struct TemperatureProfile { float temperature[3]; int duty[3]; };
inline bool validTemperatureProfile(const TemperatureProfile &p) {
  for (int i=0;i<3;++i) {
    if (!isfinite(p.temperature[i]) || p.temperature[i] < -40 || p.temperature[i] > 125 ||
        p.duty[i] < 0 || p.duty[i] > 100) return false;
    if (i && (p.temperature[i] <= p.temperature[i-1] || p.duty[i] < p.duty[i-1])) return false;
  }
  return true;
}
inline int temperatureDuty(const TemperatureProfile &p, float temperature) {
  if (temperature <= p.temperature[0]) return p.duty[0];
  if (temperature >= p.temperature[2]) return p.duty[2];
  int i = temperature <= p.temperature[1] ? 0 : 1;
  float fraction = (temperature-p.temperature[i])/(p.temperature[i+1]-p.temperature[i]);
  return (int)lroundf(p.duty[i]+fraction*(p.duty[i+1]-p.duty[i]));
}
// Plain decimal only; reject NUL, whitespace, exponent, NaN, infinity and trailing text.
inline bool parseTemperature(const char *s, size_t size, float &out) {
  if (!size || size>16) return false;
  size_t i=0; bool negative=s[0]=='-'; if(negative) ++i;
  bool digit=false, dot=false; double value=0, scale=1;
  for (;i<size;++i) {
    char c=s[i];
    if(c=='.' && !dot) {dot=true;continue;}
    if(c<'0'||c>'9') return false;
    digit=true;
    if(dot) {scale*=10;value+=(c-'0')/scale;} else value=value*10+c-'0';
  }
  if(!digit) return false;
  double signedValue=negative?-value:value;
  if(!isfinite(signedValue)||signedValue < -40 || signedValue >125) return false;
  out=(float)signedValue;return true;
}
