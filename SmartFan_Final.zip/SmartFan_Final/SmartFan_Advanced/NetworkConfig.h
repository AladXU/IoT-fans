#pragma once
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include "TemperatureProfile.h"

struct NetworkConfig { char ssid[33]; char password[65]; char serverUrl[193]; };
inline bool validServerUrl(const char *url) {
  size_t n=strnlen(url,193);
  if(n==0) return true;  // No Hub is deployed yet; the field may be empty.
  if(n>=193) return false;
  const char *host=nullptr;
  if(strncmp(url,"http://",7)==0) host=url+7;
  else if(strncmp(url,"https://",8)==0) host=url+8;
  else return false;
  for(size_t i=0;i<n;++i) {
    unsigned char c=url[i];
    if(c<=32 || c>=127 || c=='\\' || c=='"' || c=='<' || c=='>' || c=='@') return false;
  }
  const char *end=host;
  while(*end && *end!='/' && *end!='?' && *end!='#') ++end;
  const char *colon=nullptr;
  for(const char *p=host;p<end;++p) if(*p==':') {if(colon)return false;colon=p;}
  const char *hostEnd=colon?colon:end;
  if(hostEnd==host || hostEnd-host>253) return false;
  size_t label=0;
  for(const char *p=host;p<hostEnd;++p) {
    char c=*p;
    bool alnum=(c>='a'&&c<='z')||(c>='A'&&c<='Z')||(c>='0'&&c<='9');
    if(c=='.') {if(!label || *(p-1)=='-')return false;label=0;}
    else {if(!alnum && c!='-')return false;if(!label && c=='-')return false;if(++label>63)return false;}
  }
  if(!label || *(hostEnd-1)=='-')return false;
  if(colon) {
    unsigned port=0;if(colon+1==end)return false;
    for(const char *p=colon+1;p<end;++p) {if(*p<'0'||*p>'9')return false;port=port*10+*p-'0';if(port>65535)return false;}
    if(port==0)return false;
  }
  return true;
}
inline bool validNetworkConfig(const NetworkConfig &c) {
  size_t s=strnlen(c.ssid,sizeof(c.ssid)),p=strnlen(c.password,sizeof(c.password));
  if(!s || s>32 || p>64 || (p>0 && p<8)) return false;
  for(size_t i=0;i<s;++i) if((unsigned char)c.ssid[i]<32 || c.ssid[i]==127) return false;
  for(size_t i=0;i<p;++i) if((unsigned char)c.password[i]<32 || c.password[i]==127)return false;
  if(p==64) for(size_t i=0;i<p;++i)
    if(!((c.password[i]>='0'&&c.password[i]<='9')||(c.password[i]>='a'&&c.password[i]<='f')||(c.password[i]>='A'&&c.password[i]<='F')))return false;
  return validServerUrl(c.serverUrl);
}
inline bool copyConfigField(char *destination,size_t capacity,const char *text,size_t size) {
  if(size>=capacity || memchr(text,0,size))return false;
  memcpy(destination,text,size);destination[size]=0;return true;
}
inline uint32_t configChecksum(const uint8_t *bytes,size_t size) {
  uint32_t result=2166136261u;
  for(size_t i=0;i<size;++i) {result^=bytes[i];result*=16777619u;}
  return result;
}
template<typename T> struct StoredConfig {uint32_t magic;uint32_t version;T value;uint32_t checksum;};
constexpr uint32_t NETWORK_CONFIG_MAGIC=0x53464e31;
constexpr uint32_t PROFILE_CONFIG_MAGIC=0x53465031;
