#pragma once

#include <WebServer.h>
#include <freertos/FreeRTOS.h>
#include <freertos/queue.h>
#include <freertos/task.h>
#include "WebDutyCommand.h"
#include "DashboardPage.h"
#include "SetupPage.h"

struct DashboardSnapshot {
  int duty;
  float rpm;
  bool rpmValid;
  bool wifi;
  bool pwm;
  uint32_t sampledAt;
  bool wifiConnecting;
  uint8_t ip[4];
  EnvironmentReading environment;
  uint8_t oledPage;
  FanMode mode;
  TemperatureProfile profile;
  bool fallback;
  bool outputFailed;
  int calculated;
  uint32_t profileRevision;
  NetworkSnapshot network;
  int rpmTarget;
  bool pidFault;
  bool pidWaiting;
  bool pidHolding;
};

portMUX_TYPE dashboardMux = portMUX_INITIALIZER_UNLOCKED;
DashboardSnapshot dashboardSnapshot = {-1, 0, false, false, false, 0, false, {0, 0, 0, 0}, {}, 0, FanMode::Manual, {{26,28,30},{25,50,100}}, false, false, -1, 0, {}};
enum class WebCommandType { Duty, Profile, Mode, Rpm };
struct WebCommand {
  WebCommandType type;
  int duty;
  TemperatureProfile profile;
  FanMode mode;
  int rpmTarget;
};
QueueHandle_t webDutyQueue = nullptr;
TaskHandle_t webTaskHandle = nullptr;
WebServer dashboardServer(80);

DashboardSnapshot readDashboardSnapshot() {
  portENTER_CRITICAL(&dashboardMux);
  DashboardSnapshot result = dashboardSnapshot;
  portEXIT_CRITICAL(&dashboardMux);
  return result;
}

void publishDashboardSnapshot() {
  NetworkSnapshot net=readNetworkSnapshot();
  DashboardSnapshot next = {fanDuty, currentRpm, rpmValid,
      net.online, pwmReady, lastSample,
      net.phase == NetworkPhase::Connecting,
      {net.ip[0], net.ip[1], net.ip[2], net.ip[3]}, readEnvironmentSnapshot(), oledPage, fanMode, activeProfile, temperatureFallback,
      automaticOutputFailed || pidOutputFailed, calculatedDuty, profileRevision, net, requestedRpm, pidFeedbackFault, pidWaiting, rpmPid.holding};
  portENTER_CRITICAL(&dashboardMux);
  dashboardSnapshot = next;
  portEXIT_CRITICAL(&dashboardMux);
}

void dashboardNoCache() {
  dashboardServer.sendHeader("Cache-Control", "no-store");
  dashboardServer.sendHeader("X-Content-Type-Options", "nosniff");
}

void sendDashboardStatus() {
  DashboardSnapshot state = readDashboardSnapshot();
  uint32_t now = millis();
  char duty[16], rpm[24], payload[2048];
  char temperature[24] = "null", humidity[24] = "null", age[24] = "null";
  EnvironmentStatus envStatus = environmentStatusAt(state.environment, now);
  if (envStatus == EnvironmentStatus::Ready) {
    snprintf(temperature, sizeof(temperature), "%.2f", state.environment.temperature);
    snprintf(humidity, sizeof(humidity), "%.2f", state.environment.humidity);
  }
  if (state.environment.hasSample)
    snprintf(age, sizeof(age), "%lu", (unsigned long)(now - state.environment.sampledAt));
  if (state.duty >= 0) snprintf(duty, sizeof(duty), "%d", state.duty);
  else strcpy(duty, "null");
  const bool rpmFresh=state.rpmValid && std::isfinite(state.rpm) && state.rpm>=0 && (uint32_t)(now-state.sampledAt)<PID_FEEDBACK_STALE_MS;
  if (rpmFresh) snprintf(rpm, sizeof(rpm), "%.0f", state.rpm);
  else strcpy(rpm, "null");
  char calculated[16];
  if(state.calculated >= 0) snprintf(calculated,sizeof(calculated),"%d",state.calculated);
  else strcpy(calculated,"null");
  const char *pidStatus=state.mode!=FanMode::Pid?"inactive":state.outputFailed?"output_error":
      state.pidFault || !rpmFresh?"feedback_fault":state.pidWaiting?"waiting":
      state.duty==100 && state.rpmTarget>state.rpm+60?"limited_high":
      state.duty==0 && state.rpmTarget<state.rpm-60?"limited_low":state.pidHolding?"holding":"tracking";
  snprintf(payload, sizeof(payload),
      "{\"duty\":%s,\"rpm\":%s,\"wifi\":%s,\"sampleAgeMs\":%lu,"
      "\"temperatureC\":%s,\"humidityPercent\":%s,\"sensorStatus\":\"%s\","
      "\"sensorAgeMs\":%s,\"sensorStaleAfterMs\":%lu,"
      "\"mode\":\"%s\",\"fallback\":%s,\"outputFailed\":%s,\"calculatedDuty\":%s,"
      "\"stationIp\":\"%u.%u.%u.%u\",\"setupApActive\":%s,\"pid\":{\"targetRpm\":%d,\"status\":\"%s\",\"feedbackFault\":%s,\"intervalMs\":%lu,\"staleAfterMs\":%lu,\"kp\":%.4f,\"ki\":%.4f,\"kd\":%.4f,\"slewPercentPerSecond\":%.1f,\"nearKp\":%.4f,\"nearKi\":%.4f,\"nearErrorRpm\":%.0f,\"farErrorRpm\":%.0f,\"nearSlewPercentPerSecond\":%.1f,\"holdBandRpm\":%.0f},\"profileSave\":\"%s\",\"profileSavedRevision\":%lu,\"profileRevision\":%lu,\"profile\":{\"temperatures\":[%.6f,%.6f,%.6f],\"duties\":[%d,%d,%d]}}",
      duty, rpm, state.wifi ? "true" : "false", (unsigned long)(now - state.sampledAt),
      temperature, humidity, environmentStatusCode(envStatus), age,
      (unsigned long)ENVIRONMENT_STALE_MS, fanModeCode(state.mode),
      state.fallback?"true":"false",state.outputFailed?"true":"false",calculated,
      unsigned(state.ip[0]),unsigned(state.ip[1]),unsigned(state.ip[2]),unsigned(state.ip[3]),state.network.apActive?"true":"false",
      state.rpmTarget,pidStatus,state.pidFault?"true":"false",(unsigned long)PID_INTERVAL_MS,(unsigned long)PID_FEEDBACK_STALE_MS,PID_KP,PID_KI,PID_KD,PID_SLEW_PER_SECOND,PID_NEAR_KP,PID_NEAR_KI,PID_NEAR_ERROR,PID_FAR_ERROR,PID_NEAR_SLEW,PID_HOLD_RPM,
      profileSaveCode(state.network.profileSave),(unsigned long)state.network.profileSavedRevision,
      (unsigned long)state.profileRevision,
      state.profile.temperature[0],state.profile.temperature[1],state.profile.temperature[2],
      state.profile.duty[0],state.profile.duty[1],state.profile.duty[2]);
  dashboardNoCache();
  dashboardServer.send(200, "application/json", payload);
}

void receiveDashboardDuty() {
  dashboardNoCache();
  if (dashboardServer.header("X-Fan-Control") != "1") {
    dashboardServer.send(403, "application/json", "{\"error\":\"Use the dashboard Apply button.\"}");
    return;
  }
  if (dashboardServer.args() != 1 || !dashboardServer.hasArg("duty")) {
    dashboardServer.send(400, "application/json", "{\"error\":\"Provide exactly one duty value. Setting unchanged.\"}");
    return;
  }
  String text = dashboardServer.arg("duty");
  int requested = -1;
  if (parseWebDuty(text.c_str(), text.length(), requested) != CommandResult::Valid) {
    dashboardServer.send(400, "application/json", "{\"error\":\"Enter a whole number from 0 to 100. Setting unchanged.\"}");
    return;
  }
  DashboardSnapshot state = readDashboardSnapshot();
  WebCommand command = {}; command.type=WebCommandType::Duty; command.duty=requested;
  if (!state.pwm || !webDutyQueue || xQueueSend(webDutyQueue, &command, 0) != pdTRUE) {
    dashboardServer.send(503, "application/json", "{\"error\":\"Control unavailable or busy; request not queued.\"}");
    return;
  }
  char payload[64];
  snprintf(payload, sizeof(payload), "{\"queued\":true,\"requestedDuty\":%d}", requested);
  // Queued, not yet confirmed as applied. GET /api/status reports actual duty.
  dashboardServer.send(202, "application/json", payload);
}

bool queueConfigurationCommand(const WebCommand &command) {
  dashboardNoCache();
  if(!readDashboardSnapshot().pwm || !webDutyQueue || xQueueSend(webDutyQueue,&command,0)!=pdTRUE) {
    dashboardServer.send(503,"application/json","{\"error\":\"Control unavailable or busy; unchanged.\"}");return false;
  }
  dashboardServer.send(202,"application/json","{\"queued\":true}");return true;
}

bool configurationHeaderValid() {
  dashboardNoCache();
  if(dashboardServer.header("X-Fan-Control")=="1") return true;
  dashboardServer.send(403,"application/json","{\"error\":\"Use the dashboard controls.\"}");return false;
}

void receiveTemperatureProfile() {
  if(!configurationHeaderValid()) return;
  const char *names[]={"t1","t2","t3","d1","d2","d3"};
  bool valid=dashboardServer.args()==6;
  WebCommand command={};command.type=WebCommandType::Profile;
  for(int i=0;i<6;++i) {
    if(!dashboardServer.hasArg(names[i])) {valid=false;continue;}
    String text=dashboardServer.arg(names[i]);
    if(i<3) valid=parseTemperature(text.c_str(),text.length(),command.profile.temperature[i]) && valid;
    else valid=(parseWebDuty(text.c_str(),text.length(),command.profile.duty[i-3])==CommandResult::Valid) && valid;
  }
  if(!valid || !validTemperatureProfile(command.profile)) {
    dashboardServer.send(400,"application/json","{\"error\":\"Require T1 < T2 < T3 (-40..125 C), D1 <= D2 <= D3 (whole 0..100). Entire profile unchanged.\"}");return;
  }
  queueConfigurationCommand(command);
}

void receiveFanMode() {
  if(!configurationHeaderValid()) return;
  String mode=dashboardServer.arg("mode");
  if(dashboardServer.args()!=1 || !dashboardServer.hasArg("mode") || (mode!="manual" && mode!="automatic" && mode!="pid")) {
    dashboardServer.send(400,"application/json","{\"error\":\"Mode must be manual, automatic or pid; unchanged.\"}");return;
  }
  WebCommand command={};command.type=WebCommandType::Mode;
  command.mode=mode=="manual"?FanMode::Manual:mode=="automatic"?FanMode::Automatic:FanMode::Pid;
  queueConfigurationCommand(command);
}

void receiveRequestedRpm() {
  if(!configurationHeaderValid()) return;
  int target=-1;
  String text=dashboardServer.arg("rpm");
  if(dashboardServer.args()!=1 || !dashboardServer.hasArg("rpm") || !parseRequestedRpm(text.c_str(),text.length(),target)) {
    dashboardServer.send(400,"application/json","{\"error\":\"Enter one whole RPM from 0 to 20000. Setting unchanged.\"}");return;
  }
  WebCommand command={};command.type=WebCommandType::Rpm;command.rpmTarget=target;
  queueConfigurationCommand(command);
}

void sendSetupState() {
  NetworkSnapshot state=readNetworkSnapshot();
  const char *save="idle";
  switch(state.networkSave) {case NetworkSaveState::Pending:save="pending";break;
    case NetworkSaveState::SavedRestart:save="saved_restart";break;
    case NetworkSaveState::Error:save="error";break;default:break;}
  char payload[320];
  snprintf(payload,sizeof(payload),"{\"phase\":\"%s\",\"online\":%s,\"apActive\":%s,\"dnsReady\":%s,\"setupSsid\":\"%s\",\"save\":\"%s\",\"stationIp\":\"%u.%u.%u.%u\",\"hasSavedNetwork\":%s}",
    networkPhaseCode(state.phase),state.online?"true":"false",state.apActive?"true":"false",state.dnsReady?"true":"false",state.setupSsid,save,unsigned(state.ip[0]),unsigned(state.ip[1]),unsigned(state.ip[2]),unsigned(state.ip[3]),state.hasSavedNetwork?"true":"false");
  dashboardNoCache();dashboardServer.send(200,"application/json",payload);
}
void receiveNetworkConfiguration() {
  if(!configurationHeaderValid())return;
  NetworkConfig config={};const char *fields[]={"ssid","password","serverUrl"};
  bool valid=dashboardServer.args()==3;
  for(int i=0;i<3;++i) {
    if(!dashboardServer.hasArg(fields[i])) {valid=false;continue;}
    String text=dashboardServer.arg(fields[i]);
    char *dest=i==0?config.ssid:(i==1?config.password:config.serverUrl);
    size_t capacity=i==0?sizeof(config.ssid):(i==1?sizeof(config.password):sizeof(config.serverUrl));
    valid=copyConfigField(dest,capacity,text.c_str(),text.length())&&valid;
  }
  if(!valid || !validNetworkConfig(config)) {
    dashboardServer.send(400,"application/json","{\"error\":\"Invalid SSID/password or HTTP/HTTPS server URL; settings unchanged.\"}");
  } else if(!queueNetworkConfiguration(config)) {
    dashboardServer.send(503,"application/json","{\"error\":\"Network service busy or unavailable; retry after checking status.\"}");
  } else dashboardServer.send(202,"application/json","{\"queued\":true}");
  memset(&config,0,sizeof(config));
}
void sendSetupPage() {dashboardNoCache();dashboardServer.send_P(200,"text/html; charset=utf-8",SETUP_HTML);}
void redirectToSetup() {
  dashboardNoCache();dashboardServer.sendHeader("Location","http://192.168.4.1/setup");
  dashboardServer.send(302,"text/plain","Open Wi-Fi setup");
}

void dashboardTask(void *) {
  dashboardServer.enableDelay(false);
  const char *headers[] = {"X-Fan-Control"};
  dashboardServer.collectHeaders(headers, 1);
  dashboardServer.on("/", HTTP_GET, []() {
    dashboardNoCache();
    NetworkSnapshot state=readNetworkSnapshot();
    dashboardServer.send_P(200, "text/html; charset=utf-8", state.apActive && !state.online?SETUP_HTML:DASHBOARD_HTML);
  });
  dashboardServer.on("/dashboard",HTTP_GET,[](){dashboardNoCache();dashboardServer.send_P(200,"text/html; charset=utf-8",DASHBOARD_HTML);});
  dashboardServer.on("/setup",HTTP_GET,sendSetupPage);
  dashboardServer.on("/api/setup-state",HTTP_GET,sendSetupState);
  dashboardServer.on("/api/network",HTTP_POST,receiveNetworkConfiguration);
  dashboardServer.on("/api/status", HTTP_GET, sendDashboardStatus);
  dashboardServer.on("/api/duty", HTTP_POST, receiveDashboardDuty);
  dashboardServer.on("/api/profile", HTTP_POST, receiveTemperatureProfile);
  dashboardServer.on("/api/mode", HTTP_POST, receiveFanMode);
  dashboardServer.on("/api/rpm", HTTP_POST, receiveRequestedRpm);
  dashboardServer.onNotFound([]() {
    if(readNetworkSnapshot().apActive && !readNetworkSnapshot().online) {redirectToSetup();return;}
    dashboardNoCache();
    dashboardServer.send(404, "application/json", "{\"error\":\"Not found.\"}");
  });
  bool listening = false;
  int previousInterfaces=0;
  for (;;) {
    NetworkSnapshot state=readNetworkSnapshot();
    int interfaces=(state.online?1:0)|(state.apActive?2:0);
    bool online=interfaces!=0;
    if(listening && interfaces!=previousInterfaces) {dashboardServer.stop();listening=false;}
    previousInterfaces=interfaces;
    if (online && !listening) {
      dashboardServer.begin();
      listening = true;
    } else if (!online && listening) {
      dashboardServer.stop();
      listening = false;
    }
    // WebServer can wait for slow clients. Only this separate task waits;
    // the Arduino loop keeps processing control, RPM, Wi-Fi, and OLED.
    if (listening) dashboardServer.handleClient();
    vTaskDelay(pdMS_TO_TICKS(2));
  }
}

void startDashboard() {
  webDutyQueue = xQueueCreate(4, sizeof(WebCommand));
  if (!webDutyQueue) {
    Serial.println("Web dashboard unavailable: command queue allocation failed");
    return;
  }
  publishDashboardSnapshot();
  if (xTaskCreate(dashboardTask, "fanWeb", 8192, nullptr, 1, &webTaskHandle) != pdPASS) {
    vQueueDelete(webDutyQueue);
    webDutyQueue = nullptr;
    Serial.println("Web dashboard unavailable: task allocation failed");
  } else {
    Serial.println("Web dashboard ready: use http:// followed by the OLED IP");
  }
}

void processDashboardCommands() {
  WebCommand command;
  if (!webDutyQueue || xQueueReceive(webDutyQueue, &command, 0) != pdTRUE) return;
  switch(command.type) {
    case WebCommandType::Duty:
      if(applyManualDuty(command.duty)) Serial.printf("Web accepted: duty=%d%% | mode=manual\n",fanDuty);
      else Serial.println("Web request failed: PWM unavailable; setting unchanged");
      break;
    case WebCommandType::Profile:
      if(setTemperatureProfile(command.profile)) {
        queueProfilePersistence(activeProfile,profileRevision);
        Serial.printf("Profile applied: revision=%lu; NVS save queued (check status)\n",(unsigned long)profileRevision);
      }
      break;
    case WebCommandType::Mode: selectFanMode(command.mode); break;
    case WebCommandType::Rpm:
      if(setRequestedRpm(command.rpmTarget)) Serial.printf("PID target accepted: %d RPM\n",requestedRpm);
      else Serial.println("PID request failed; target/mode unchanged");
      break;
  }
}
