#pragma once
#include "ButtonLogic.h"

// OLED header labels K1,K2,K3,K4, irrespective of the header's physical order.
constexpr uint8_t BUTTON_PINS[4] = {7, 8, 9, 10};
// Indices into BUTTON_PINS: provisional physical order, verify once on hardware.
// Change only these role indices if the panel's top-to-bottom key order differs.
constexpr ButtonRoles BUTTON_ROLES = {0, 1, 2, 3};
static_assert(BUTTON_ROLES.up < 4 && BUTTON_ROLES.down < 4 &&
              BUTTON_ROLES.fine < 4 && BUTTON_ROLES.page < 4, "Invalid button role index");
static_assert(BUTTON_ROLES.up != BUTTON_ROLES.down && BUTTON_ROLES.up != BUTTON_ROLES.fine &&
              BUTTON_ROLES.up != BUTTON_ROLES.page && BUTTON_ROLES.down != BUTTON_ROLES.fine &&
              BUTTON_ROLES.down != BUTTON_ROLES.page && BUTTON_ROLES.fine != BUTTON_ROLES.page,
              "Each role needs a different button");
ButtonController localButtons;
uint32_t lastButtonPoll = 0;

void startLocalButtons() {
  bool down[4];
  for (uint8_t i=0; i<4; ++i) {
    pinMode(BUTTON_PINS[i], INPUT_PULLUP);
    down[i] = digitalRead(BUTTON_PINS[i]) == LOW;
  }
  lastButtonPoll = millis();
  localButtons.begin(down, lastButtonPoll);
  Serial.println("Buttons ready: K1/GPIO7 +5, K2/GPIO8 -5, hold K3/GPIO9 for 1%, K4/GPIO10 page");
  Serial.println("Verify physical top-to-bottom order once; buttons held at boot require release before action.");
}

void serviceLocalButtons() {
  uint32_t now = millis();
  if ((uint32_t)(now - lastButtonPoll) < 5) return;
  lastButtonPoll = now;
  bool down[4];
  for (uint8_t i=0; i<4; ++i) down[i] = digitalRead(BUTTON_PINS[i]) == LOW;
  ButtonAction action = localButtons.update(down, now, BUTTON_ROLES);
  for (uint8_t i=0; i<4; ++i)
    if (action.pressedMask & (1u << i))
      Serial.printf("Button K%u (GPIO%u): pressed\n", unsigned(i+1), unsigned(BUTTON_PINS[i]));
  if (action.directionConflict)
    Serial.println("Buttons: both directions held; duty unchanged");
  if (action.delta != 0) {
    if (fanDuty < 0 || !pwmReady) {
      Serial.println("Button rejected: PWM unavailable; setting unchanged");
    } else {
      int requested = buttonRequestedDuty(fanDuty, action.delta);
      if (applyManualDuty(requested))
        Serial.printf("Button accepted: duty=%d%% | step=%d%%\n", fanDuty, action.fine ? 1 : 5);
      else Serial.println("Button rejected: PWM unavailable; setting unchanged");
    }
  }
  if (action.page) {
    oledPage = (oledPage + 1) % 2;
    Serial.printf("OLED page: %s\n", oledPage == 0 ? "fan overview" : "environment detail");
  }
}
