#pragma once

const char DASHBOARD_HTML[] PROGMEM = R"FANPAGE(<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="icon" href="data:,"><title>SmartFan · Control</title>
<style>
:root{color-scheme:light;--ink:#202a29;--muted:#65706d;--line:#d9dfdc;--paper:#fff;--canvas:#f4f5f2;--accent:#185e50;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;color:var(--ink);background:var(--canvas);font-synthesis:none}
*{box-sizing:border-box;border-radius:0!important}body{margin:0;padding:0 28px}button,input{font:inherit}button,a,input{touch-action:manipulation}a{color:var(--accent);text-underline-offset:4px}button:focus-visible,a:focus-visible,input:focus-visible,summary:focus-visible{outline:2px solid var(--accent);outline-offset:3px}[hidden]{display:none!important}
main{max-width:1180px;margin:auto}.topbar{display:flex;justify-content:space-between;align-items:center;gap:20px;height:76px;border-bottom:1px solid var(--line)}.brand{display:flex;align-items:center;gap:10px;font-size:17px;font-weight:750;letter-spacing:-.5px}.brand-mark{display:grid;place-items:center;width:29px;height:29px;background:var(--ink);color:white;font-size:11px;letter-spacing:0}.topbar nav{display:flex;align-items:center;gap:24px;font-size:13px}.topbar nav a{text-decoration:none;font-weight:600}#connection{font-size:12px;font-weight:650;padding:7px 10px;border:1px solid var(--line);background:var(--paper)}
.page-heading{padding:28px 0 16px;display:flex;align-items:end;justify-content:space-between;gap:16px}.eyebrow{margin:0 0 9px;font-size:10px;letter-spacing:1.8px;text-transform:uppercase;font-weight:700;color:var(--muted)}h1{font-size:34px;letter-spacing:-1.2px;line-height:1.1;margin:0;font-weight:650}.subtitle{color:var(--muted);font-size:14px;margin:10px 0 0;line-height:1.5}.system-label{font-size:11px;color:var(--muted);letter-spacing:1px;text-transform:uppercase}
#network-result{font-size:12px;line-height:1.6;border-left:2px solid var(--accent);padding:6px 11px;margin:0 0 20px;color:var(--muted)}#network-result[data-state=offline]{border-color:#a46b15;color:#805b13}.section-caption{display:flex;justify-content:space-between;align-items:center;margin-bottom:12px}h2{font-size:19px;letter-spacing:-.4px;font-weight:650;margin:0}h3{font-size:13px;font-weight:650;margin:0 0 9px}.section-no{color:var(--muted);font-size:11px;font-variant-numeric:tabular-nums;letter-spacing:1px}
.metrics{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));border:1px solid var(--line);background:white}.metric{padding:21px 23px;border-right:1px solid var(--line)}.metric:last-child{border-right:0}.label{color:var(--muted);font-size:12px;font-weight:550}.value{font-size:44px;font-weight:600;letter-spacing:-1.6px;line-height:1.15;margin-top:12px;font-variant-numeric:tabular-nums}.unit{font-size:13px;font-weight:500;letter-spacing:0;color:var(--muted);margin-left:5px}
#sensor-state{font-size:11px;color:var(--muted);margin:9px 0 24px;min-height:16px}#sensor-state[data-error=true]{color:#a22f26}.workspace{display:grid;grid-template-columns:minmax(0,.85fr) minmax(0,1.4fr);gap:22px;align-items:start}.panel{border:1px solid var(--line);background:var(--paper);padding:24px}.panel-header{display:flex;justify-content:space-between;align-items:center;gap:16px;padding-bottom:20px;border-bottom:1px solid var(--line);margin-bottom:20px}.panel-header .eyebrow{margin:0 0 6px}.field-label{display:block;font-size:12px;font-weight:650;color:var(--muted);margin-bottom:10px}.mode-line{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin:0 0 7px;font-size:16px;font-weight:600;line-height:1.45}#auto-state{font-size:13px;color:var(--muted);line-height:1.5;margin:0 0 17px;min-height:20px}#auto-state[data-error=true],#config-message[data-error=true],#message[data-error=true]{color:#a22f26}
button{border:1px solid var(--accent);background:var(--accent);color:white;padding:11px 16px;font-size:13px;font-weight:600;cursor:pointer;min-height:42px;line-height:1.3}button:hover{background:#12483e}button:disabled{opacity:.45;cursor:wait}.mode-buttons{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:0}.mode-buttons button{border-color:var(--line);background:white;color:var(--muted)}.mode-buttons button+button{border-left:0}.mode-buttons button[data-active=true]{background:#e8f1ec;color:var(--accent);box-shadow:inset 0 -2px var(--accent)}.mode-buttons button:hover{background:#eff3f0}
#control{margin:0}.mode-note{margin:16px 0 0}.auto-summary{border-left:2px solid var(--accent);padding-left:12px;margin-bottom:22px}.auto-summary h3{margin-bottom:7px}.waiting-pane{font-size:14px;line-height:1.7;color:var(--muted)}#control-pane-title{margin:0}.profile-heading{margin-bottom:16px}input{background:#fff;border:1px solid #bcc6c0;color:var(--ink);width:100%;min-width:0;padding:10px 12px;font-size:16px;min-height:44px;font-variant-numeric:tabular-nums}input:hover{border-color:#8f9f95}.controls{display:flex;gap:10px;align-items:stretch}.controls .input-unit{display:flex;align-items:center;width:140px;border:1px solid #bcc6c0}.input-unit input{border:0;width:105px}.input-unit span{padding-right:13px;color:var(--muted);font-size:14px}.controls button{flex:1}.controls .rpm-input{width:160px}.rpm-input input{width:100%}#pid-state{font-size:13px;line-height:1.6;color:var(--muted);margin:0}#pid-state[data-error=true]{color:#a22f26}
.note{font-size:12px;line-height:1.65;color:var(--muted);margin:12px 0 0}.tip{border-left:2px solid var(--line);padding-left:10px}.help{margin-top:20px;padding:13px 14px;background:#f5f6f3;color:var(--muted);font-size:12px;line-height:1.7}.help summary{cursor:pointer;font-weight:600;color:#4d5b53}.help p{margin:9px 0 0}.help p+p{margin-top:7px}.result{font-size:12px;line-height:1.6;margin:11px 0 0}.result:empty{display:none}
.profile-table{border-collapse:collapse;width:100%;table-layout:fixed}.profile-table th{text-align:left;font-size:11px;font-weight:600;color:var(--muted);padding:0 0 10px}.profile-table th:first-child{width:44px}.profile-table th:nth-child(2),.profile-table td:nth-child(2){padding-right:12px}.profile-table td{padding:0 0 12px}.point-id{font-size:11px;color:var(--muted);font-variant-numeric:tabular-nums}.sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}.profile-actions{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-top:6px}.constraint{font-size:11px;color:var(--muted);line-height:1.6}.device-state{border-top:1px solid var(--line);padding-top:17px;margin-top:20px}#profile-storage{font-size:11px;color:var(--muted);margin:0 0 7px;line-height:1.5}#active-profile{font-size:12px;line-height:1.7;margin:0;font-variant-numeric:tabular-nums}.command-result{font-size:12px;line-height:1.6;margin:16px 0 0;border-left:2px solid var(--accent);padding:8px 12px;background:#edf2ee}.command-result:empty{display:none}
footer{display:flex;justify-content:space-between;gap:20px;border-top:1px solid var(--line);padding:18px 0 24px;margin-top:25px;color:var(--muted);font-size:11px;line-height:1.6}
@media(max-width:850px){.workspace{grid-template-columns:1fr}.metric{padding:18px}.value{font-size:36px}.page-heading{padding-top:24px}.system-label{display:none}}
@media(max-width:520px){body{padding:0 16px}.topbar{height:65px}.topbar nav{gap:12px}h1{font-size:29px}.metrics{grid-template-columns:repeat(2,minmax(0,1fr))}.metric:nth-child(2){border-right:0}.metric:nth-child(-n+2){border-bottom:1px solid var(--line)}.metric{padding:17px}.value{font-size:38px}.panel{padding:20px}.workspace{gap:16px}.profile-actions{align-items:flex-start;flex-direction:column}.profile-actions button{width:100%}.mode-buttons{grid-template-columns:repeat(3,minmax(0,1fr))}footer{flex-direction:column;gap:5px}.subtitle{font-size:13px}}
@media(max-width:380px){.topbar{height:auto;min-height:65px;flex-wrap:wrap;padding:15px 0;gap:12px}.topbar nav{width:100%;justify-content:space-between}.panel{padding:16px}.value{font-size:34px}.profile-table th:first-child{width:32px}.controls .input-unit{width:115px}.input-unit input{width:80px}}
@media(prefers-reduced-motion:reduce){*{scroll-behavior:auto!important}}
</style></head><body><main>
<header class="topbar"><div class="brand"><span class="brand-mark" aria-hidden="true">SF</span>SmartFan</div><nav aria-label="Device navigation"><a href="/setup">Wi-Fi settings ↗</a><span id="connection" role="status">Connecting…</span></nav></header>
<div class="page-heading"><div><p class="eyebrow">DEVICE / CONTROL PANEL</p><h1>Fan control</h1><p class="subtitle">Live readings. Direct control. Automatic cooling.</p></div><span class="system-label">ESP32 · LOCAL NETWORK</span></div>
<p id="network-result" role="status" aria-live="polite">Checking the Wi-Fi connection…</p>
<section aria-labelledby="readings-title"><div class="section-caption"><h2 id="readings-title">Live readings</h2><span class="section-no">01 / TELEMETRY</span></div>
<div class="metrics">
<div class="metric"><div class="label">Applied duty</div><div class="value"><span id="duty">--</span><span class="unit">%</span></div></div>
<div class="metric"><div class="label">Fan speed</div><div class="value"><span id="rpm">--</span><span class="unit">RPM</span></div></div>
<div class="metric"><div class="label">Temperature</div><div class="value"><span id="temperature">--</span><span class="unit">°C</span></div></div>
<div class="metric"><div class="label">Humidity</div><div class="value"><span id="humidity">--</span><span class="unit">%RH</span></div></div>
</div><p id="sensor-state" role="status">SHT30: waiting for first reading.</p></section>
<div class="workspace">
<section class="panel" aria-labelledby="control-title">
<div class="panel-header"><div><p class="eyebrow">02 / OPERATION</p><h2 id="control-title">Operating mode</h2></div></div>
<span class="field-label">Active on device</span><p id="mode-state" class="mode-line" role="status">Waiting for device</p>
<div class="mode-buttons" aria-label="Select operating mode"><button type="button" id="manual-mode" aria-pressed="false">Manual</button><button type="button" id="auto-mode" aria-pressed="false">Auto temp</button><button type="button" id="pid-mode" aria-pressed="false">PID RPM</button></div>
<p class="note tip mode-note">Choose a mode. Its controls appear in section 03 once the device confirms.</p>
<p id="config-message" class="command-result" role="status" aria-live="polite"></p>
<details class="help"><summary>How the controls work</summary><p>Manual holds the current duty. A valid duty command from the page, serial console or buttons switches to Manual, including during PID control.</p><p>Automatic uses the temperature profile. Missing or stale temperature requests 100% fallback duty. A 0% command may still leave the fan spinning.</p></details>
</section>
<section class="panel" aria-labelledby="control-pane-title">
<div class="panel-header"><div><p class="eyebrow">03 / CONTROLS</p><h2 id="control-pane-title">Waiting for device</h2></div><span id="control-pane-label" class="section-no"></span></div>
<p id="mode-waiting" class="waiting-pane" role="status">The controls appear after the device reports its operating mode.</p>
<div id="manual-pane" hidden>
<form id="control" novalidate><label class="field-label" for="requested">Manual duty · 0–100%</label><div class="controls"><div class="input-unit"><input id="requested" name="duty" type="number" min="0" max="100" step="1" inputmode="numeric" placeholder="0–100" required><span aria-hidden="true">%</span></div><button id="apply" type="submit">Apply duty</button></div>
<p class="note tip">Manual keeps the duty you apply. A 0% command may still leave the fan spinning.</p><p id="message" class="result" role="status" aria-live="polite"></p></form>
</div>
<div id="automatic-pane" hidden>
<div class="auto-summary"><h3>Automatic control status</h3><p id="auto-state" role="status"></p></div>
<form id="profile-control" novalidate aria-labelledby="profile-title">
<h3 id="profile-title" class="profile-heading">Temperature profile</h3>
<table class="profile-table"><thead><tr><th scope="col">Point</th><th scope="col">Temperature · °C</th><th scope="col">Duty · %</th></tr></thead><tbody>
<tr><td class="point-id">01</td><td><label class="sr-only" for="t1">T1 temperature (°C)</label><input id="t1" type="number" step="any" min="-40" max="125" required></td><td><label class="sr-only" for="d1">Duty 1 (%)</label><input id="d1" type="number" step="1" min="0" max="100" required></td></tr>
<tr><td class="point-id">02</td><td><label class="sr-only" for="t2">T2 temperature (°C)</label><input id="t2" type="number" step="any" min="-40" max="125" required></td><td><label class="sr-only" for="d2">Duty 2 (%)</label><input id="d2" type="number" step="1" min="0" max="100" required></td></tr>
<tr><td class="point-id">03</td><td><label class="sr-only" for="t3">T3 temperature (°C)</label><input id="t3" type="number" step="any" min="-40" max="125" required></td><td><label class="sr-only" for="d3">Duty 3 (%)</label><input id="d3" type="number" step="1" min="0" max="100" required></td></tr>
</tbody></table>
<div class="profile-actions"><div class="constraint">T1 &lt; T2 &lt; T3<br>Duty 1 ≤ Duty 2 ≤ Duty 3</div><button id="save-profile" type="submit">Save profile</button></div>
<div class="device-state"><h3>Profile status</h3><p id="profile-storage" role="status">Profile storage: checking…</p><p id="active-profile">Active profile: waiting for device</p></div>
<details class="help"><summary>Profile rules &amp; startup behavior</summary><p>The device interpolates linearly between points and holds the endpoint duties outside the range. Temperatures must increase; duties must stay level or increase.</p><p>Saving does not switch operating mode. Wait for storage confirmation before disconnecting power. Boot mode is Manual.</p></details>
</form></div>
<div id="pid-pane" hidden>
<div class="auto-summary"><h3>Active target · <span id="pid-target">--</span> RPM</h3><p id="pid-state" role="status">Waiting for device.</p></div>
<form id="rpm-control" novalidate><label class="field-label" for="requested-rpm">Target speed · RPM</label><div class="controls"><div class="input-unit rpm-input"><input id="requested-rpm" name="rpm" type="number" min="0" max="20000" step="1" inputmode="numeric" placeholder="2500" required></div><button id="apply-rpm" type="submit">Apply RPM</button></div>
<p class="note tip">The controller adjusts duty from real TACH feedback. Targets outside the fan's range settle at its minimum or maximum speed; 0 RPM may still spin.</p></form>
<details class="help"><summary>Controller settings &amp; recovery</summary><p id="pid-settings">Waiting for controller settings.</p><p>Manual duty input from serial or buttons exits PID. RPM feedback loss requests 100% fallback; fresh feedback resumes control. Startup is Manual. The target and PID mode are not saved across power cycles.</p><p>Initial gains need testing on your fan. These readings do not confirm that tuning is complete.</p></details>
</div></section></div>
<footer><span>Live data · dashboard 1 s / temperature &amp; humidity 2 s</span><span id="updated">Waiting for first reading.</span></footer>
</main>
<script>
const byId = id => document.getElementById(id);
let requestBusy = false;
let nextPoll = 0;
let pendingDuty = null;
let pendingConfiguration = null;
let profileLoaded = false;
let pidEditorLoaded = false;
function setConfigurationBusy(busy) {
  for(const id of ['save-profile','manual-mode','auto-mode','pid-mode','apply-rpm']) byId(id).disabled=busy;
}
function queueConfiguration(path,body) {
  if(byId('save-profile').disabled) return;
  pendingConfiguration={path,body};setConfigurationBusy(true);
  byId('config-message').textContent='Sending request…';byId('config-message').dataset.error='false';
  if(!requestBusy) {clearTimeout(nextPoll);nextPoll=setTimeout(poll,0);}
}

async function request(path, options = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 4000);
  try {
    const response = await fetch(path, {...options, cache:'no-store', signal:controller.signal});
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'Request failed.');
    return data;
  } finally { clearTimeout(timer); }
}
let sensorFreshUntil = 0;
function hideEnvironment(message) {
  sensorFreshUntil = 0;
  byId('temperature').textContent = '--';
  byId('humidity').textContent = '--';
  byId('sensor-state').textContent = message;
  byId('sensor-state').dataset.error = 'true';
}
function showEnvironment(data) {
  const age = data.sensorAgeMs;
  const limit = data.sensorStaleAfterMs;
  const valid = data.sensorStatus === 'ok' && Number.isFinite(data.temperatureC) &&
    Number.isFinite(data.humidityPercent) && Number.isFinite(age) && age >= 0 &&
    Number.isFinite(limit) && limit > 0 && age < limit;
  if (valid) {
    byId('temperature').textContent = data.temperatureC.toFixed(1);
    byId('humidity').textContent = data.humidityPercent.toFixed(1);
    sensorFreshUntil = performance.now() + limit - age;
    byId('sensor-state').textContent = 'SHT30: live · sampled every 2 seconds';
    byId('sensor-state').dataset.error = 'false';
  } else {
    const messages = {
      starting:'SHT30: starting; waiting for first reading.',
      missing:'SHT30: sensor missing or not responding; retrying.',
      read_error:'SHT30: measurement failed; retrying.',
      stale:'SHT30: reading is stale; waiting for a fresh sample.',
      unavailable:'SHT30: sensor service unavailable.'
    };
    hideEnvironment(messages[data.sensorStatus] || 'SHT30: no valid fresh reading.');
  }
}
// Expire values even if the next network request is slow or the tab was backgrounded.
function expireEnvironment() {
  if (sensorFreshUntil && performance.now() >= sensorFreshUntil)
    hideEnvironment('SHT30: reading is stale; waiting for a fresh sample.');
}
setInterval(expireEnvironment, 250);
document.addEventListener('visibilitychange', expireEnvironment);
function showModePane(mode) {
  const manual=mode==='manual', automatic=mode==='automatic', pid=mode==='pid';
  byId('manual-pane').hidden=!manual;
  byId('automatic-pane').hidden=!automatic;
  byId('pid-pane').hidden=!pid;
  byId('mode-waiting').hidden=manual || automatic || pid;
  byId('control-pane-title').textContent=manual?'Manual duty':automatic?'Automatic temperature':pid?'Closed-loop RPM':'Waiting for device';
  byId('control-pane-label').textContent=manual?'MANUAL':automatic?'AUTO':pid?'PID':'';
}
function showReadings(data) {
  showEnvironment(data);
  showModePane(data.mode);
  byId('mode-waiting').textContent='The controls appear after the device reports its operating mode.';
  byId('network-result').dataset.state=data.wifi?'online':'offline';
  byId('network-result').textContent=data.wifi?'Wi-Fi connected · IP '+(data.stationIp || location.hostname)+' · '+(data.setupApActive?'setup hotspot closing':'setup hotspot closed'):'The device reports that Wi-Fi is offline.';
  const storage={default:'default profile (not saved yet)',pending:'saving; RAM profile already active',saved:'saved to device',error:'SAVE FAILED; current profile is RAM only'};
  byId('profile-storage').textContent='Profile storage: '+(storage[data.profileSave] || 'unknown')+' · saved revision '+(data.profileSavedRevision ?? '--');
  byId('profile-storage').style.color=data.profileSave==='error'?'#a62828':'';
  const automatic=data.mode==='automatic';
  byId('manual-mode').dataset.active=String(data.mode==='manual');
  byId('auto-mode').dataset.active=String(automatic);
  byId('pid-mode').dataset.active=String(data.mode==='pid');
  byId('pid-mode').setAttribute?.('aria-pressed',String(data.mode==='pid'));
  byId('manual-mode').setAttribute?.('aria-pressed',String(data.mode==='manual'));
  byId('auto-mode').setAttribute?.('aria-pressed',String(automatic));
  byId('mode-state').textContent = 'Mode: ' + (data.mode==='automatic' ? 'Automatic temperature' : data.mode==='pid'?'PID RPM':'Manual');
  byId('auto-state').textContent = data.outputFailed ? 'PWM output failed; check actual duty.' :
    data.mode==='automatic' ? (data.fallback ? 'Temperature fault · fallback requested: 100%' : 'Calculated duty: '+data.calculatedDuty+'%') : 'Manual duty control active';
  byId('auto-state').dataset.error=String(Boolean(data.outputFailed || data.fallback));
  if(data.pid) {
    byId('pid-target').textContent=Number.isFinite(data.pid.targetRpm)?data.pid.targetRpm:'--';
    if(!pidEditorLoaded && Number.isFinite(data.pid.targetRpm)) {byId('requested-rpm').value=data.pid.targetRpm;pidEditorLoaded=true;}
    const pidMessages={inactive:'PID is inactive.',waiting:'Waiting for a fresh RPM window.',tracking:'Controlling from live TACH feedback.',holding:'Within ±'+(data.pid.holdBandRpm ?? 45)+' RPM; holding duty to avoid chasing small count changes.',limited_high:'Maximum duty reached; the requested RPM may be above the fan range.',limited_low:'Minimum duty reached; the requested RPM may be below the fan range.',feedback_fault:'RPM feedback unavailable or no pulses. Fallback requested: 100%.',output_error:'PWM output failed. Check Applied duty above.'};
    byId('pid-state').textContent=pidMessages[data.pid.status] || 'Controller state unconfirmed.';
    byId('pid-state').dataset.error=String(data.pid.status==='feedback_fault' || data.pid.status==='output_error');
    byId('pid-settings').textContent='Update: '+data.pid.intervalMs+' ms · Far-error Kp '+data.pid.kp+' · Ki '+data.pid.ki+' · Kd '+data.pid.kd+'. Near target: Kp '+data.pid.nearKp+' / Ki '+data.pid.nearKi+', at most '+data.pid.nearSlewPercentPerSecond+' duty point/s. Within ±'+data.pid.holdBandRpm+' RPM: hold duty. Large-error limit: '+data.pid.slewPercentPerSecond+' points/s. Output 0–100%; anti-windup enabled.';
  }
  if(data.profile && data.profile.temperatures.length===3 && data.profile.duties.length===3) {
    byId('active-profile').textContent='Active profile (revision '+data.profileRevision+'): '+data.profile.temperatures.map((t,i)=>t+'°C → '+data.profile.duties[i]+'%').join(' · ');
    if(!profileLoaded) {
      for(let i=0;i<3;i++) {byId('t'+(i+1)).value=data.profile.temperatures[i];byId('d'+(i+1)).value=data.profile.duties[i];}
      profileLoaded=true;
    }
  }
  byId('duty').textContent = data.duty === null ? '--' : data.duty;
  byId('rpm').textContent = data.rpm === null ? '--' : Math.round(data.rpm);
  byId('connection').textContent = data.wifi ? 'Connected' : 'Wi-Fi offline';
  byId('updated').textContent = 'Updated ' + new Date().toLocaleTimeString();
  byId('duty').style.opacity = '1'; byId('rpm').style.opacity = '1';
}
function showOffline() {
  showModePane(null);
  byId('control-pane-title').textContent='Connection lost';
  byId('mode-waiting').textContent='Reconnect to confirm the operating mode and show its controls.';
  for(const id of ['manual-mode','auto-mode','pid-mode']) {
    byId(id).dataset.active='false';byId(id).setAttribute?.('aria-pressed','false');
  }
  byId('network-result').dataset.state='offline';
  byId('network-result').textContent='Connection lost. Retrying. Device status is unconfirmed.';
  hideEnvironment('SHT30: connection lost; no current reading.');
  byId('mode-state').textContent='Mode: connection lost; state unconfirmed';
  byId('auto-state').textContent='Reconnect to confirm actual device state.';
  byId('connection').textContent = 'Disconnected · retrying';
  byId('updated').textContent = 'Readings may be out of date.';
  byId('duty').style.opacity = '.45'; byId('rpm').style.opacity = '.45';
}
async function poll() {
  if (requestBusy) return;
  requestBusy = true;
  const started = Date.now();
  try {
    if (pendingDuty !== null) {
      const text = pendingDuty;
      pendingDuty = null;
      try {
        const result = await request('/api/duty', {
          method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded','X-Fan-Control':'1'},
          body:'duty=' + encodeURIComponent(text)
        });
        byId('message').textContent = 'Requested ' + result.requestedDuty + '%. Check Applied duty above for confirmation.';
        byId('message').dataset.error = 'false';
      } catch (error) {
        byId('message').textContent = error.message + ' Check Applied duty before retrying.';
        byId('message').dataset.error = 'true';
      } finally { byId('apply').disabled = false; }
    }
    if(pendingConfiguration !== null) {
      const command=pendingConfiguration;pendingConfiguration=null;
      try {
        await request(command.path,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded','X-Fan-Control':'1'},body:command.body});
        byId('config-message').textContent='Request queued. Check the active mode or profile.';
        byId('config-message').dataset.error='false';
      } catch(error) {
        byId('config-message').textContent=error.message+' Check reported state before retrying.';
        byId('config-message').dataset.error='true';
      } finally {setConfigurationBusy(false);}
    }
    showReadings(await request('/api/status'));
  } catch (_) { showOffline(); }
  finally {
    requestBusy = false;
    nextPoll = setTimeout(poll, (pendingDuty !== null || pendingConfiguration !== null) ? 0 : Math.max(100, 1000 - (Date.now() - started)));
  }
}
byId('control').addEventListener('submit', event => {
  event.preventDefault();
  if (byId('apply').disabled) return;
  const text = byId('requested').value.trim();
  const message = byId('message');
  if (!/^\d+$/.test(text) || !Number.isSafeInteger(Number(text)) || Number(text) > 100) {
    message.textContent = 'Enter a whole number from 0 to 100. Setting unchanged.';
    message.dataset.error = 'true'; return;
  }
  pendingDuty = text;
  byId('apply').disabled = true;
  message.textContent = 'Sending request…'; message.dataset.error = 'false';
  if (!requestBusy) { clearTimeout(nextPoll); nextPoll = setTimeout(poll, 0); }
});
byId('manual-mode').addEventListener('click',()=>queueConfiguration('/api/mode','mode=manual'));
byId('auto-mode').addEventListener('click',()=>queueConfiguration('/api/mode','mode=automatic'));
byId('pid-mode').addEventListener('click',()=>queueConfiguration('/api/mode','mode=pid'));
byId('rpm-control').addEventListener('submit',event=>{
  event.preventDefault();
  const text=byId('requested-rpm').value.trim();
  if(!/^\d{1,5}$/.test(text) || Number(text)>20000) {byId('config-message').textContent='Enter a whole RPM from 0 to 20000. Target and mode unchanged.';byId('config-message').dataset.error='true';return;}
  queueConfiguration('/api/rpm','rpm='+encodeURIComponent(text));
});
byId('profile-control').addEventListener('submit',event=>{
  event.preventDefault();
  if(byId('save-profile').disabled) return;
  const t=[],d=[],parts=[];
  let valid=true;
  for(let i=1;i<=3;i++) {
    const temp=String(byId('t'+i).value).trim(), duty=String(byId('d'+i).value).trim();
    valid=valid && /^-?(?:\d+(?:\.\d*)?|\.\d+)$/.test(temp) && temp.length<=16 &&
      Number.isFinite(Number(temp)) && Number(temp)>=-40 && Number(temp)<=125 &&
      /^\d+$/.test(duty) && Number.isSafeInteger(Number(duty)) && Number(duty)<=100;
    t.push(Number(temp));d.push(Number(duty));
    parts.push('t'+i+'='+encodeURIComponent(temp),'d'+i+'='+encodeURIComponent(duty));
  }
  valid=valid && t[0]<t[1] && t[1]<t[2] && d[0]<=d[1] && d[1]<=d[2];
  if(!valid) {
    byId('config-message').textContent='Require T1 < T2 < T3 (-40..125°C) and non-decreasing whole duties 0..100. Entire profile unchanged.';
    byId('config-message').dataset.error='true';return;
  }
  queueConfiguration('/api/profile',parts.join('&'));
});
poll();
</script></body></html>)FANPAGE";
