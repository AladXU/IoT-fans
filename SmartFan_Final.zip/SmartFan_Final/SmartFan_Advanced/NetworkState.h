#pragma once
#include <stdint.h>
enum class NetworkPhase {Starting,Connecting,Online,Setup,Retry,Unavailable};
enum class ProfileSaveState {Default,Pending,Saved,Error};
enum class NetworkSaveState {Idle,Pending,SavedRestart,Error};
struct NetworkSnapshot {
  NetworkPhase phase=NetworkPhase::Starting;
  bool online=false,apActive=false,dnsReady=false,hasSavedNetwork=false;
  uint8_t ip[4]={0,0,0,0};
  char setupSsid[32]={};
  NetworkSaveState networkSave=NetworkSaveState::Idle;
  ProfileSaveState profileSave=ProfileSaveState::Default;
  uint32_t profileSavedRevision=0;
};
inline const char *networkPhaseCode(NetworkPhase phase) {
  switch(phase) {
    case NetworkPhase::Starting:return "starting";
    case NetworkPhase::Connecting:return "connecting";
    case NetworkPhase::Online:return "online";
    case NetworkPhase::Setup:return "setup";
    case NetworkPhase::Retry:return "retry";
    default:return "unavailable";
  }
}
inline const char *profileSaveCode(ProfileSaveState state) {
  switch(state) {case ProfileSaveState::Default:return "default";case ProfileSaveState::Pending:return "pending";
    case ProfileSaveState::Saved:return "saved";default:return "error";}
}
