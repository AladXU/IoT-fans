#pragma once

#include <stddef.h>
#include <stdint.h>

enum class CommandResult { None, Valid, Invalid, OutOfRange, TooLong };

// Fixed-size, line-based parser. Invalid input never changes the output value.
class DutyCommandParser {
 public:
  CommandResult feed(char c, int &output) {
    if (c == '\r' || c == '\n') {
      if (c == '\n' && afterCR_) {
        afterCR_ = false;
        return CommandResult::None;
      }
      afterCR_ = (c == '\r');
      CommandResult result = overflow_ ? CommandResult::TooLong : parse(output);
      length_ = 0;
      overflow_ = false;
      return result;
    }
    afterCR_ = false;
    if (overflow_) return CommandResult::None;
    if (length_ < sizeof(buffer_)) buffer_[length_++] = c;
    else overflow_ = true;
    return CommandResult::None;
  }

 private:
  char buffer_[32] = {};
  size_t length_ = 0;
  bool overflow_ = false;
  bool afterCR_ = false;

  static bool space(char c) { return c == ' ' || c == '\t'; }

  CommandResult parse(int &output) const {
    size_t begin = 0;
    size_t end = length_;
    while (begin < end && space(buffer_[begin])) ++begin;
    while (end > begin && space(buffer_[end - 1])) --end;
    if (begin == end) return CommandResult::Invalid;

    int value = 0;
    bool tooLarge = false;
    for (size_t i = begin; i < end; ++i) {
      char c = buffer_[i];
      if (c < '0' || c > '9') return CommandResult::Invalid;
      int digit = c - '0';
      if (!tooLarge) {
        if (value > (100 - digit) / 10) tooLarge = true;
        else value = value * 10 + digit;
      }
    }
    if (tooLarge) return CommandResult::OutOfRange;
    output = value;
    return CommandResult::Valid;
  }
};
