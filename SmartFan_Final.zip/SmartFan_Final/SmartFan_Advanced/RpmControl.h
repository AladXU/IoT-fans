#pragma once
#include "RpmPid.h"

RpmPid rpmPid;
int requestedRpm = 2500;
bool pidFeedbackFault = false;
bool pidOutputFailed = false;
bool pidWaiting = true;
uint8_t pidZeroSamples = 0;
uint32_t pidConsumedSample = 0;
uint32_t pidLastFaultApply = 0;
bool pidFaultAttempted = false;

bool rpmFeedbackFresh(uint32_t now) {
  return rpmValid && std::isfinite(currentRpm) && currentRpm >= 0 &&
      (uint32_t)(now - lastSample) < PID_FEEDBACK_STALE_MS;
}
void resetRpmControl() {
  rpmPid.reset();
  pidFeedbackFault = false; pidOutputFailed = false; pidWaiting = true;
  pidZeroSamples = 0; pidConsumedSample = lastSample; pidFaultAttempted = false;
}
void beginRpmControl() {
  resetRpmControl();
  if (rpmFeedbackFresh(millis())) {
    rpmPid.seed(requestedRpm, currentRpm, fanDuty, lastSample);
    pidWaiting = false;
  }
}
void serviceRpmControl() {
  if (fanMode != FanMode::Pid) return;
  const uint32_t now = millis();
  const bool fresh = rpmFeedbackFresh(now);
  const bool newSample = lastSample != pidConsumedSample;
  if (fresh && newSample) {
    pidConsumedSample = lastSample;
    if (currentRpm < 1 && fanDuty >= 25) {
      if (pidZeroSamples < 3) ++pidZeroSamples;
    } else pidZeroSamples = 0;
  }
  const bool fault = !fresh || pidZeroSamples >= 3;
  if (fault) {
    if (!pidFeedbackFault) Serial.println("PID: RPM missing/stale or no pulses; fallback 100%");
    pidFeedbackFault = true; pidWaiting = false; rpmPid.reset();
    calculatedDuty = 100;
    if (fanDuty == 100) { pidOutputFailed = false; return; }
    if (pidFaultAttempted && (uint32_t)(now - pidLastFaultApply) < 250) return;
    pidLastFaultApply = now; pidFaultAttempted = true;
    pidOutputFailed = !applyDuty(100);
    return;
  }
  if (pidFeedbackFault) {
    // Recover only on a fresh positive sample, not on repeated reads of an old zero.
    if (!newSample || currentRpm < 1) return;
    pidFeedbackFault = false; pidFaultAttempted = false;
    rpmPid.seed(requestedRpm, currentRpm, fanDuty, lastSample);
    calculatedDuty = fanDuty;
    Serial.println("PID: fresh RPM restored; control resumed");
    return;
  }
  if (!newSample) return;
  RpmPid candidate = rpmPid;
  const int target = candidate.step(requestedRpm, currentRpm, fanDuty, lastSample);
  calculatedDuty = target; pidWaiting = false;
  if (target != fanDuty && !applyDuty(target)) {
    pidOutputFailed = true;  // Keep the old integrator; retry at the next fresh window.
    Serial.println("PID: PWM failed; actual duty unchanged, integral not committed");
    return;
  }
  rpmPid = candidate; pidOutputFailed = false;
  Serial.printf("PID: target=%d | RPM=%.0f | duty=%d%% | I=%.3f | zone=%s\n",
      requestedRpm, currentRpm, fanDuty, rpmPid.integral, rpmPid.holding?"hold":std::fabs(requestedRpm-currentRpm)<=PID_NEAR_ERROR?"near":std::fabs(requestedRpm-currentRpm)>=PID_FAR_ERROR?"far":"blend");
}
bool setRequestedRpm(int target) {
  if (!pwmReady || fanDuty < 0 || target < 0 || target > PID_TARGET_MAX) return false;
  requestedRpm = target;
  selectFanMode(FanMode::Pid);
  return true;
}
