#pragma once

#include <math.h>
#include <stdint.h>

struct RpmLedTarget {
  uint8_t red, green, blue;
  uint16_t periodMs;
};

struct RpmLedFrame {
  RpmLedTarget color;
  uint8_t level;
};

inline RpmLedTarget rpmLedTarget(float rpm, bool valid) {
  if (!valid || !isfinite(rpm) || rpm <= 0) return {0, 0, 0, 2600};
  float bounded = rpm > 4500.0f ? 4500.0f : rpm;
  uint16_t period = (uint16_t)(2600u - (uint32_t)(bounded + 0.5f) * 2200u / 4500u);
  if (bounded <= 2250.0f) {
    uint8_t mix = (uint8_t)(bounded * (255.0f / 2250.0f) + 0.5f);
    return {0, mix, (uint8_t)(255 - mix), period};
  }
  uint8_t mix = (uint8_t)((bounded - 2250.0f) * (255.0f / 2250.0f) + 0.5f);
  return {mix, (uint8_t)(255 - mix), 0, period};
}

inline uint8_t rpmLedBreathingLevel(uint16_t phase) {
  float wave = (1.0f - cosf(phase * (6.28318530718f / 65536.0f))) * 0.5f;
  return (uint8_t)(255.0f * wave + 0.5f);
}

inline uint16_t advanceRpmLedPhase(uint16_t phase, uint32_t elapsedMs, uint16_t periodMs) {
  return (uint16_t)(phase + (uint64_t)elapsedMs * 65536u / periodMs);
}

// 1.2 seconds of each primary, separated by a 0.2-second dark gap.
inline RpmLedFrame rpmLedSelfTestFrame(uint32_t elapsedMs) {
  uint32_t stage = elapsedMs / 1400u;
  if (stage >= 3 || elapsedMs % 1400u >= 1200u) return {{0, 0, 0, 2600}, 0};
  if (stage == 0) return {{255, 0, 0, 2600}, 255};
  if (stage == 1) return {{0, 255, 0, 2600}, 255};
  return {{0, 0, 255, 2600}, 255};
}

class RpmLedAnimator {
 public:
  void reset() { initialized_ = false; filteredRpm_ = 0; phase_ = 0; }

  RpmLedFrame update(float rpm, bool fresh, uint32_t elapsedMs) {
    if (!fresh || !isfinite(rpm) || rpm <= 0) {
      reset();
      return {{0, 0, 0, 2600}, 0};
    }
    float bounded = rpm > 4500.0f ? 4500.0f : rpm;
    if (!initialized_) {
      filteredRpm_ = bounded;
      initialized_ = true;
    } else {
      // Smooth display only: never modify measured RPM or PWM control.
      float alpha = 1.0f - expf(-(float)elapsedMs / 400.0f);
      filteredRpm_ += (bounded - filteredRpm_) * alpha;
    }
    RpmLedTarget color = rpmLedTarget(filteredRpm_, true);
    phase_ = advanceRpmLedPhase(phase_, elapsedMs, color.periodMs);
    return {color, rpmLedBreathingLevel(phase_)};
  }

 private:
  bool initialized_ = false;
  float filteredRpm_ = 0;
  uint16_t phase_ = 0;
};
