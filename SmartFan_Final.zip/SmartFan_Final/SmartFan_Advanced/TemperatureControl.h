#pragma once
#include "TemperatureProfile.h"

enum class FanMode { Manual, Automatic, Pid };
const char *fanModeCode(FanMode mode) {return mode==FanMode::Manual?"manual":mode==FanMode::Automatic?"automatic":"pid";}
FanMode fanMode = FanMode::Manual;
TemperatureProfile activeProfile = {{26,28,30},{25,50,100}};
bool temperatureFallback = false;
bool automaticOutputFailed = false;
int calculatedDuty = -1;
uint32_t profileRevision = 0;
uint32_t lastAutomaticApply = 0;
bool automaticApplyAttempted = false;

void selectFanMode(FanMode mode);
#include "RpmControl.h"

bool applyManualDuty(int duty) {
  // Switch mode only after successful hardware application.
  if (!applyDuty(duty)) return false;
  bool changed = fanMode != FanMode::Manual;
  fanMode=FanMode::Manual;resetRpmControl();temperatureFallback=false;automaticOutputFailed=false;calculatedDuty=-1;
  automaticApplyAttempted=false;
  if(changed) Serial.println("Mode: manual (manual duty command overrides automatic control)");
  return true;
}

bool setTemperatureProfile(const TemperatureProfile &profile) {
  if(!validTemperatureProfile(profile)) return false;
  activeProfile=profile;++profileRevision;
  automaticApplyAttempted=false;
  return true;
}

void serviceTemperatureControl() {
  if(fanMode!=FanMode::Automatic) return;
  EnvironmentReading reading=readEnvironmentSnapshot();
  uint32_t now=millis();
  bool fallback=environmentStatusAt(reading,now)!=EnvironmentStatus::Ready;
  int target=fallback?100:temperatureDuty(activeProfile,reading.temperature);
  if(fallback!=temperatureFallback) Serial.println(fallback
      ? "AUTO: temperature unavailable/stale; fallback duty 100%"
      : "AUTO: fresh temperature restored; profile control resumed");
  temperatureFallback=fallback;calculatedDuty=target;
  // New samples and fault transitions take effect immediately. Retry failed PWM at 250ms.
  if(target==fanDuty) {automaticOutputFailed=false;return;}
  if(automaticOutputFailed && automaticApplyAttempted && (uint32_t)(now-lastAutomaticApply)<250) return;
  lastAutomaticApply=now;automaticApplyAttempted=true;
  bool success=applyDuty(target);
  if(!success && !automaticOutputFailed) Serial.println("AUTO: PWM application failed; actual duty unchanged");
  if(success) Serial.printf("AUTO: applied duty=%d%% | fallback=%s\n",fanDuty,fallback?"yes":"no");
  automaticOutputFailed=!success;
}

void selectFanMode(FanMode mode) {
  fanMode=mode;automaticApplyAttempted=false;automaticOutputFailed=false;
  temperatureFallback=false;
  if(mode==FanMode::Pid) {calculatedDuty=fanDuty;beginRpmControl();serviceRpmControl();}
  else {
    resetRpmControl();
    if(mode==FanMode::Manual) calculatedDuty=-1;
    else serviceTemperatureControl();
  }
  Serial.printf("Mode: %s\n",fanModeCode(mode));
}
