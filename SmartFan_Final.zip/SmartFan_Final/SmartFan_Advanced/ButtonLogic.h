#pragma once
#include <stdint.h>

constexpr uint32_t BUTTON_DEBOUNCE_MS = 30;
struct ButtonRoles { uint8_t up, down, fine, page; };
struct ButtonAction {
  uint8_t pressedMask = 0;
  int delta = 0;
  bool fine = false;
  bool page = false;
  bool directionConflict = false;
};

class DebouncedButton {
 public:
  void begin(bool down, uint32_t now) {
    raw_ = stable_ = down;
    changedAt_ = now;
  }
  bool update(bool down, uint32_t now) {
    if (down != raw_) { raw_ = down; changedAt_ = now; }
    if (raw_ == stable_ || (uint32_t)(now - changedAt_) < BUTTON_DEBOUNCE_MS) return false;
    stable_ = raw_;
    return stable_;  // Only a debounced press edge, never hold-repeat or release.
  }
  bool down() const { return stable_; }
 private:
  bool raw_ = false, stable_ = false;
  uint32_t changedAt_ = 0;
};

class ButtonController {
 public:
  void begin(const bool down[4], uint32_t now) {
    for (uint8_t i=0; i<4; ++i) keys_[i].begin(down[i], now);
  }
  ButtonAction update(const bool down[4], uint32_t now, ButtonRoles roles) {
    ButtonAction result;
    // Update every key first so a simultaneous fine+direction press uses 1%.
    for (uint8_t i=0; i<4; ++i)
      if (keys_[i].update(down[i], now)) result.pressedMask |= 1u << i;
    result.fine = keys_[roles.fine].down();
    result.page = result.pressedMask & (1u << roles.page);
    bool up = result.pressedMask & (1u << roles.up);
    bool decrease = result.pressedMask & (1u << roles.down);
    if (up || decrease) {
      result.directionConflict = keys_[roles.up].down() && keys_[roles.down].down();
      if (!result.directionConflict) result.delta = (up ? 1 : -1) * (result.fine ? 1 : 5);
    }
    return result;
  }
 private:
  DebouncedButton keys_[4];
};

inline int buttonRequestedDuty(int current, int delta) {
  int requested = current + delta;
  return requested < 0 ? 0 : (requested > 100 ? 100 : requested);
}
