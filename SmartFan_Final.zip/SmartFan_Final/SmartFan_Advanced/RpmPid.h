#pragma once
#include <cmath>
#include <cstddef>
#include <cstdint>

constexpr uint32_t PID_INTERVAL_MS = 1000;
constexpr uint32_t PID_FEEDBACK_STALE_MS = 2500;
constexpr int PID_TARGET_MAX = 20000;  // Input bound, not a promise of achievable speed.
constexpr float PID_KP = 0.012f;      // % duty / RPM
constexpr float PID_KI = 0.006f;      // % duty / (RPM * second)
constexpr float PID_KD = 0.001f;      // % duty * second / RPM
constexpr float PID_SLEW_PER_SECOND = 10.0f;
constexpr float PID_NEAR_KP = 0.004f;
constexpr float PID_NEAR_KI = 0.0015f;
constexpr float PID_NEAR_ERROR = 150.0f;
constexpr float PID_FAR_ERROR = 600.0f;
constexpr float PID_NEAR_SLEW = 1.0f;
constexpr float PID_HOLD_RPM = 45.0f; // Documented control tolerance, never a rewritten RPM reading.

inline float pidClamp(float value, float low, float high) {
  return value < low ? low : value > high ? high : value;
}
inline float pidAggressiveness(float error) {
  return pidClamp((std::fabs(error)-PID_NEAR_ERROR)/(PID_FAR_ERROR-PID_NEAR_ERROR),0,1);
}
inline float pidProportionalGain(float error) {
  return PID_NEAR_KP+(PID_KP-PID_NEAR_KP)*pidAggressiveness(error);
}
inline float pidIntegralGain(float error) {
  return PID_NEAR_KI+(PID_KI-PID_NEAR_KI)*pidAggressiveness(error);
}
inline bool parseRequestedRpm(const char *text, size_t length, int &result) {
  if (!text || !length || length > 5) return false;
  int value = 0;
  for (size_t i = 0; i < length; ++i) {
    if (text[i] < '0' || text[i] > '9') return false;
    value = value * 10 + text[i] - '0';
    if (value > PID_TARGET_MAX) return false;
  }
  result = value;
  return true;
}

// Pure discrete PID; callers commit this state only if the PWM application succeeds.
// Derivative is on measurement with a one-second first-order filter, avoiding setpoint kick.
// Integral tracking accounts for BOTH duty saturation and the output slew limit.
struct RpmPid {
  float integral = 0;
  float derivative = 0;
  float previousRpm = 0;
  uint32_t steppedAt = 0;
  bool initialized = false;
  bool holding = false;

  void reset() { *this = {}; }
  void seed(int target, float measured, int actualDuty, uint32_t at) {
    previousRpm = measured;
    derivative = 0;
    const float error=target-measured;
    integral = actualDuty - pidProportionalGain(error) * error;
    steppedAt = at;
    initialized = true;
    holding = false;
  }
  int step(int target, float measured, int actualDuty, uint32_t at) {
    if (!std::isfinite(measured) || measured < 0 || target < 0 || target > PID_TARGET_MAX)
      return actualDuty;
    const uint32_t elapsed = at - steppedAt;
    if (!initialized || elapsed > PID_FEEDBACK_STALE_MS) {
      seed(target, measured, actualDuty, at);
      return actualDuty;
    }
    if (elapsed < PID_INTERVAL_MS) return actualDuty;
    const float dt = elapsed / 1000.0f;
    const float error = target - measured;
    const float slope = (measured - previousRpm) / dt;
    derivative += dt / (1.0f + dt) * (slope - derivative);
    const float p = pidProportionalGain(error) * error;
    const float d = -PID_KD * derivative;
    // TACH count quantization is 30 RPM per pulse at 1 s / PPR=2. Avoid chasing
    // one-count changes: hold the ACTUAL duty within the stated tolerance.
    holding = std::fabs(error) <= PID_HOLD_RPM;
    if (holding) {
      integral = actualDuty - p - d;
      previousRpm = measured;
      steppedAt = at;
      return actualDuty;
    }
    const float proposedIntegral = integral + pidIntegralGain(error) * error * dt;
    const float raw = p + proposedIntegral + d;
    const float slew=PID_NEAR_SLEW+(PID_SLEW_PER_SECOND-PID_NEAR_SLEW)*pidAggressiveness(error);
    const float low = pidClamp(actualDuty - slew * dt, 0, 100);
    const float high = pidClamp(actualDuty + slew * dt, 0, 100);
    const float limited = pidClamp(raw, low, high);
    // External-reset/back-calculation tracking: do not accumulate unreachable output.
    integral = proposedIntegral + (limited - raw);
    previousRpm = measured;
    steppedAt = at;
    return static_cast<int>(std::lround(limited));
  }
};
