# SmartFan acceptance checklist

Build `smartfan-advanced-pid-idle-4` · November 16, 2026

| Feature | Recorded evidence | Outstanding checks |
|---|---|---|
| PWM, serial, RPM, OLED, RGB and dashboard | User tests and a 15-minute basic-build run | Brief regression on the final build |
| SHT30 and four buttons | User confirmation and screenshots | Concurrent use on the final build |
| Temperature curve and manual takeover | Screenshots and logs include invalid-profile rejection | Retain the existing evidence |
| Missing sensor and recovery | 100% at 4440 RPM during the fault, followed by live readings after reconnection | Cold-start evidence covers power-off rewiring only |
| Wi-Fi and profile storage | Successful connection, setup feedback and save/restart observations | Record wrong-password fallback, rejoining the AP and full recovery |
| PID | Physical observations at 2500, 3500 and 4000 RPM, including a brief stable-3 run | Check idle-4, steps in both directions, saturation recovery and extended operation |
| Main-loop idle optimization | Firmware compiled | Measure temperature and power |
| Multi-device Hub | Outside the implemented scope | See optional future checks below |

The user identified the main ESP32 chip in the photo. The estimated 50°C was based on touch. Resolve the heating issue before extended runs. Disconnect power if the board resets unexpectedly, USB disconnects, an unusual smell develops or temperature continues rising abnormally.

## Recording results

Record the date, operator, boot marker, power source, network, test ID, expectation, observation, pass/fail/untested and log or screenshot filename. The following procedures require bench observations. Keep model results in a separate record.

| ID | Procedure and expected result |
|---|---|
| T01 · Startup | After cooling, upload idle-4 normally and verify the boot marker. Observe the dashboard, OLED, serial and USB for 2–3 minutes. Use an instrument to record chip surface temperature if available. The SHT30 reports ambient temperature. |
| T02 · Manual control | Change the dashboard from 50% to 75%, then send 24 over serial. A coarse increment gives 29%, followed by a fine decrement to 28%. Check the reported applied duty across interfaces after refresh. Reject 101 and fractional inputs without changing duty. |
| T03 · Modes | Select Manual, Auto temp and PID RPM in turn. Section 03 must match the confirmed device mode. Serial 24 selects Manual. Only the active controller may set duty. |
| T04 · Temperature | Save 26/28/30°C mapped to 25/50/100%. Check interpolation against the live reading. Setting T1 equal to T2 must reject the whole edit. A valid curve around room temperature avoids the need for heating. Restore the desired curve afterward. |
| T05 · PID steps | After resolving the heating issue, run 1500 → 2500 → 3500 → 4000 → 2500 RPM for 60 seconds each. Record target, measured RPM, duty, time to approach target, and minimum/maximum/mean over the final 20 seconds. The ±45 RPM hold band describes control behavior. The fan limits reachable speeds. |
| T06 · PID boundaries | Request 0 and a target above the measured maximum, e.g. 6000. Observe the output limits, then return to 2500 and check recovery. Keep hands clear of the blades. The fan can still spin at 0% duty. Reject −1, 2500.5 and 20001 while retaining the previous target. |
| T07 · Sensor fault | Disconnect USB and fan power before removing the SHT30. Restart and select Auto. Expect missing status, blank temperature/humidity and 100% fallback. Power down, reconnect the module, restart and select Auto again. Confirm fresh readings. |
| T08 · Wi-Fi recovery | Keep the correct password available. Save a deliberately incorrect password in /setup. After timeout, join the setup hotspot and open http://192.168.4.1/setup. Restore the correct password and verify an assigned IP, an accessible dashboard and closure of the setup AP. |
| T09 · Persistence and offline operation | Save a different valid curve, wait for saved status and power-cycle. The curve should persist and the fan should start in Manual at 50%. Check local serial, buttons and temperature control during a network outage. After reconnection, open the current IP. |
| T10 · Integrated run | Once heating is resolved, run the final build for 15 minutes. Exercise all three modes and record start, end and any anomalies. Watch for resets, stopped tasks, extended dashboard loss or invalid readings presented as current. The previous basic-build run is recorded separately. |

Host tests cover runtime tachometer fault injection, recovery and integral anti-windup. Runtime tachometer faults on hardware remain unverified. Use power-off rewiring for bench tests.

## Automated regression

`python3 scripts/run_tests.py` runs six production C++ test groups and two embedded JavaScript suites. Environment tests use the actual arduino-sht driver with simulated hardware boundaries. Compile firmware separately in Arduino IDE or CLI. RF reliability, thermal behavior, power consumption, PWM waveform and absolute RPM accuracy require physical measurements.

## Future Hub acceptance criteria

Use at least two independent physical controllers. Register devices without source edits. Show each ID, name, readings, mode and update time. Return individual results for both single-device and group commands. Verify isolation when a device disconnects, clear timeout/offline/recovery states and continued autonomous operation when the Hub goes offline.

See the [dated test run](docs/TEST_RUN_20261116.md). Mark bench checks as passed only after recording the observation.
