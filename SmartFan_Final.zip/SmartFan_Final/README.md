# SmartFan for ESP32-S3

Release `smartfan-advanced-pid-idle-4`, November 16, 2026. This sketch includes the basic controls and the advanced single-device features.

## Build and run

Open [SmartFan_Advanced.ino](SmartFan_Advanced/SmartFan_Advanced.ino) in Arduino IDE with all sibling headers in place. Select **Waveshare ESP32-S3-Zero**, Arduino ESP32 core **3.3.10**, default partition scheme, **USB CDC On Boot enabled**, **Erase All Flash Before Sketch Upload disabled**. Use 115200 baud.

Install arduino-sht 1.2.6, Adafruit SSD1306 2.5.17, Adafruit GFX 1.12.6 and Adafruit BusIO 1.17.4. On first use, join `SmartFan-Setup-XXXXXX` and open http://192.168.4.1/setup to enter the 2.4 GHz network details. Rejoin that network on the computer and open the IP shown on the OLED. The ESP32 serves both web pages directly from the sketch headers. It reads network settings from NVS.

At boot the fan starts in Manual at 50%. The network and temperature profile persist. The mode and PID target reset on restart.

## Course features

| Item | Implementation |
|---|---|
| Basic 2.1–2.7 | PWM, tachometer, serial control, Wi-Fi, OLED, RGB feedback, web controls and task scheduling |
| 3.1 | Live SHT30 temperature and humidity with validity and fault reporting |
| 3.2 | Four buttons for coarse and fine adjustment and OLED page selection |
| 3.3 | Three-point temperature curve with validation, interpolation and sensor-failure fallback |
| 3.4 | Closed-loop RPM control with exclusive modes, anti-windup, fault handling and recovery |
| 3.5 | Setup hotspot, connection feedback, NVS persistence and retries |
| 3.6 | Multi-device Hub outside this release. Verification would require at least two independent physical controllers. The optional server URL is stored only. |

The firmware runs without external W25Qxx flash or an SD card. The course caps advanced-feature marks. The contribution statement, summary PDF, slides and demo video are separate course deliverables.

## Documentation and tests

- [Firmware operation and API](SmartFan_Advanced/README.md)
- [Wiring and pin assignments](SmartFan_Advanced/WIRING.md)
- [Wi-Fi setup and storage](SmartFan_Advanced/PROVISIONING.md)
- [PID settings, measurements and limits](SmartFan_Advanced/PID.md)
- [Acceptance checklist](TEST_PLAN.md) and [historical test evidence](SmartFan_Advanced/TEST_STATUS.md)

Run `python3 scripts/run_tests.py` from this directory. The runner requires a C++17 compiler, Node.js and the arduino-sht source. Use `--sdk`, `--node` or `--sht-dir` to select local dependencies. It builds in a temporary directory, reports missing dependencies as failures and runs without a board. See the [host test instructions](SmartFan_Advanced/tests/README.md).

The release contains the final sketch, tests, setup and wiring documentation, browser previews and measured PID logs. Private network credentials, lecture materials, personal photos, historical sketches, archives and build products are excluded. PID tuning and brief operation were observed on hardware. Temperature rise and long-run stability of the idle-4 build still require measurement.
